import * as THREE from './vendor/three.module.js';
import {createGarment} from './garment.js';
import {createGarmentMaterial} from './shaders.js';
import {DURATION,beats,clamp,lerp,p,w,stateAt,cubic} from './motion.js';

const $=s=>document.querySelector(s), canvas=$('#stage'),status=$('#status');
const params=new URLSearchParams(location.search);let fixed=params.has('t')?clamp(Number(params.get('t'))||0,0,72):null;
let autoplay=params.get('autoplay')==='1'&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:true});}
catch(e){status.textContent='WebGL을 시작하지 못했습니다. 하드웨어 가속을 지원하는 브라우저에서 열어주세요.';throw e;}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setClearColor(0x030912,1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;
const scene=new THREE.Scene();
const camera=new THREE.OrthographicCamera(-3.5,3.5,2.25,-2.25,.1,30);camera.position.set(0,.05,8);camera.lookAt(0,.05,0);
const material=createGarmentMaterial(THREE), garment=createGarment(THREE,material);scene.add(garment.group);
const hardwareMaterial=createGarmentMaterial(THREE,{hardware:true});garment.hardwareMesh.material=hardwareMaterial;
const U=material.uniforms;
const set=(m,key,value)=>{if(!m.uniforms?.[key])return;const v=m.uniforms[key].value;if(v?.isColor)v.set(value);else m.uniforms[key].value=value;};
const clones=[];
for(let i=0;i<2;i++){const m=createGarmentMaterial(THREE);const g=createGarment(THREE,m);scene.add(g.group);clones.push({m,g,side:i?1:-1});}
// A few complete-garment echoes are used only on the fast convergence arc.
const echoes=[];
for(let k=0;k<2;k++)for(let j=0;j<2;j++){const m=createGarmentMaterial(THREE);const g=garment.group.clone(true);g.traverse(o=>{if(o.isMesh)o.material=m;});scene.add(g);echoes.push({m,g,side:k?1:-1,delay:(j+1)*.11});}

scene.add(new THREE.HemisphereLight(0xbfdfff,0x152136,2));
const keyLight=new THREE.DirectionalLight(0xe3f4ff,4.2);keyLight.position.set(-3,5,5);scene.add(keyLight);
const rimLight=new THREE.DirectionalLight(0x5ebdff,2.8);rimLight.position.set(3,2,-3);scene.add(rimLight);

const lineColor=new THREE.Color('#75cfff');
const lineMaterial=new THREE.MeshBasicMaterial({color:lineColor,transparent:true,opacity:1,depthTest:true});
const line=new THREE.Mesh(new THREE.BufferGeometry(),lineMaterial);scene.add(line);
const lineGlowMaterial=new THREE.MeshBasicMaterial({color:'#2988c5',transparent:true,opacity:.075,depthWrite:false,blending:THREE.AdditiveBlending});
const lineGlow=new THREE.Mesh(new THREE.BufferGeometry(),lineGlowMaterial);scene.add(lineGlow);
let outline=[];
// Use the actual base geometry to recover a continuous garment contour. No bitmap tracing.
const samples=[];garment.group.updateMatrixWorld(true);garment.group.traverse(o=>{if(o.isMesh&&o.geometry?.attributes?.position){const a=o.geometry.attributes.position;for(let i=0;i<a.count;i+=2){const v=new THREE.Vector3().fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld);samples.push(v);}}});
const box=new THREE.Box3().setFromObject(garment.group);const minY=box.min.y,maxY=box.max.y;
const rows=[];for(let j=0;j<100;j++){const y=lerp(minY+.025,maxY-.025,j/99),near=samples.filter(v=>Math.abs(v.y-y)<.035);if(near.length){let a=near.reduce((x,v)=>v.x<x.x?v:x),b=near.reduce((x,v)=>v.x>x.x?v:x);rows.push([new THREE.Vector3(a.x,y,a.z+.015),new THREE.Vector3(b.x,y,b.z+.015)]);}}
outline=[...rows.map(v=>v[0]),...rows.toReversed().map(v=>v[1])];outline.push(outline[0].clone());
const contour=new THREE.CatmullRomCurve3(outline,true,'centripetal',.25).getPoints(320);
function drawIdea(t,s){if(t>13.1){line.visible=false;lineGlow.visible=false;return;}line.visible=lineGlow.visible=true;const morph=p(t,1.8,7.2),pts=[];
 for(let i=0;i<321;i++){const u=i/320,theta=u*Math.PI*2;const r=1.05+.18*Math.sin(theta*2+t*.32);const initial=new THREE.Vector3(Math.cos(theta*1.11+t*.22)*r,Math.sin(theta*1.42+t*.17)*1.28,Math.sin(theta*1.8-t*.21)*.42);const dest=contour[i];pts.push(initial.lerp(dest,morph));}
 const curve=new THREE.CatmullRomCurve3(pts,false,'centripetal',.3),geometry=new THREE.TubeGeometry(curve,320,.0048,6,false);const halo=new THREE.TubeGeometry(curve,320,.013,5,false);line.geometry.dispose();lineGlow.geometry.dispose();line.geometry=geometry;lineGlow.geometry=halo;line.rotation.copy(garment.group.rotation);lineGlow.rotation.copy(line.rotation);line.position.copy(garment.group.position);lineGlow.position.copy(line.position);line.scale.copy(garment.group.scale);lineGlow.scale.copy(line.scale);lineMaterial.opacity=s.line;lineGlowMaterial.opacity=.075*s.line;
}

const scanGroup=new THREE.Group();scene.add(scanGroup);
const scanMaterial=new THREE.MeshBasicMaterial({color:'#66caff',transparent:true,opacity:.08,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending});
const scanPlane=new THREE.Mesh(new THREE.PlaneGeometry(3.7,1.5),scanMaterial);scanPlane.rotation.x=-Math.PI/2;scanGroup.add(scanPlane);
const scanEdge=new THREE.LineSegments(new THREE.EdgesGeometry(scanPlane.geometry),new THREE.LineBasicMaterial({color:'#83d9ff',transparent:true,opacity:.3}));scanEdge.rotation.x=-Math.PI/2;scanGroup.add(scanEdge);
const scanBeam=new THREE.Mesh(new THREE.CylinderGeometry(.004,.004,3.8,8),new THREE.MeshBasicMaterial({color:'#a4e6ff',transparent:true,opacity:.85}));scanBeam.rotation.z=Math.PI/2;scanBeam.position.z=.64;scanGroup.add(scanBeam);

const strokeMaterial=new THREE.MeshBasicMaterial({color:'#9ce9ff',transparent:true,opacity:1});
const stroke=new THREE.Mesh(new THREE.CylinderGeometry(.013,.013,3.9,10),strokeMaterial);stroke.position.z=.7;scene.add(stroke);
const strokeHalo=new THREE.Mesh(new THREE.CylinderGeometry(.034,.034,3.9,10),new THREE.MeshBasicMaterial({color:'#41c4ff',transparent:true,opacity:.10,depthWrite:false,blending:THREE.AdditiveBlending}));scene.add(strokeHalo);

const annotations=$('#annotations');const labels=[];
function addLabel(name){const el=document.createElement('div');el.className='callout';el.textContent=name;annotations.append(el);labels.push(el);return el;}
const fitLabel=addLabel('핏 · 레이어드할 여유'),lengthLabel=addLabel('기장 · 조금 더 짧게'),sleeveLabel=addLabel('소매 · 손목에 맞게'),detailLabel=addLabel('디테일 · 포켓의 깊이');
const leaders=[fitLabel,lengthLabel,sleeveLabel,detailLabel].map(()=>{const mesh=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:'#76c7ef',transparent:true,opacity:0}));scene.add(mesh);return mesh;});
const dimNames=['어깨 48 cm','가슴둘레 114 cm','소매 60 cm','총장 78 cm'];const dimEls=dimNames.map(addLabel);
const dimLines=dimNames.map(()=>{const g=new THREE.BufferGeometry().setFromPoints(Array.from({length:6},()=>new THREE.Vector3()));const m=new THREE.LineBasicMaterial({color:'#8cdbff',transparent:true,opacity:0});const l=new THREE.LineSegments(g,m);scene.add(l);return l;});
const note=document.createElement('p');note.className='measurement-note';note.textContent='기본 셔츠 100호 참고 치수 · 셔켓 확정 규격 아님';annotations.append(note);
function project(x,y,z=.6){const v=new THREE.Vector3(x,y,z).applyMatrix4(garment.group.matrixWorld).project(camera);return [(v.x*.5+.5)*canvas.clientWidth,(-v.y*.5+.5)*canvas.clientHeight];}
function put(el,x,y,z,a,align='center'){const xy=project(x,y,z);el.style.left=xy[0]+'px';el.style.top=xy[1]+'px';el.style.opacity=clamp(a);el.style.visibility=a>.015?'visible':'hidden';el.style.transform=`translate(${align==='left'?'0':align==='right'?'-100%':'-50%'},-50%)`;}
function callout(el,i,anchor,target,a,align){put(el,...target,a,align);const coords=[anchor.clone(),new THREE.Vector3(...target)];leaders[i].geometry.setFromPoints(coords.map(v=>v.applyMatrix4(garment.group.matrixWorld)));leaders[i].material.opacity=a*.6;}
function dimensions(t,s){const a=s.measurement;const vals=[[-.8,1.06,.8,1.06,0,1.26],[-.78,.17,.78,.17,0,.34],[1.35,.75,1.47,-1.18,1.75,-.26],[-1.19,1.08,-1.19,-1.36,-1.51,-.17]];
 vals.forEach((v,i)=>{const scanY=lerp(1.5,-1.45,p(t,33,38.3)),targetY=i<2?v[1]:v[3];const alpha=t<40?a*p(scanY,targetY+.07,targetY-.07):s.draft*p(s.strokeX,Math.max(v[0],v[2]),Math.max(v[0],v[2])+.1);let pts=[new THREE.Vector3(v[0],v[1],.68),new THREE.Vector3(v[2],v[3],.68)];const delta=i<2?new THREE.Vector3(0,.045,0):new THREE.Vector3(.045,0,0);for(const q of [...pts])pts.push(q.clone().add(delta),q.clone().sub(delta));pts=pts.map(q=>q.applyMatrix4(garment.group.matrixWorld));dimLines[i].geometry.setFromPoints(pts);dimLines[i].material.opacity=alpha;put(dimEls[i],v[4],v[5],.68,alpha);});note.style.opacity=Math.max(a,s.draft);note.style.visibility=Math.max(a,s.draft)>.01?'visible':'hidden';
}

function hologram(m,s,alpha=1){set(m,'uTime',s.t);set(m,'uReveal',1);set(m,'uStateAlpha',alpha);set(m,'uWireStrength',1);set(m,'uMaterialMix',0);set(m,'uCad',0);set(m,'uStrokeX',10);set(m,'uScan',-2);}
function echoPosition(g,side,t,delay=0){const q=clamp((t-26.3-delay-(side>0?.35:0))/5);const acc=q*q*(3-2*q);const x=cubic(side*2.22,side*2.6,side*.85,0,acc),y=cubic(.10,.58,.6,.10,acc);g.position.set(x,y,lerp(-.16,0,acc));g.scale.setScalar(lerp(.72,1,acc));g.rotation.set(0,lerp(side*.15,-.26,acc),0);return q;}
function renderAt(time){const s=stateAt(time),t=s.t;
 const aspect=canvas.clientWidth/canvas.clientHeight,baseHalf=Math.max(2.02,1.82/aspect),half=lerp(baseHalf,Math.max(baseHalf,3.55/aspect),w(t,22.5,25,29,33));camera.left=-half*aspect;camera.right=half*aspect;camera.top=half;camera.bottom=-half;camera.updateProjectionMatrix();
 garment.update({fit:s.fit,length:s.length,sleeve:s.sleeve,flat:s.flat,detail:s.detail,time:0});garment.group.scale.setScalar(s.mainScale);garment.group.rotation.y=lerp(-.26,0,s.flat);garment.group.position.set(0,.10,0);garment.group.updateMatrixWorld(true);
 set(material,'uTime',t);set(material,'uReveal',s.reveal);set(material,'uStateAlpha',t<6?.01:lerp(.62,1,1-w(t,23,25,29,33)));set(material,'uWireStrength',1-s.settle);set(material,'uMaterialMix',s.fabric);set(material,'uScan',s.fabric);set(material,'uCad',s.cad);set(material,'uStrokeX',t<40?-2.4:t>49?10:s.strokeX);
 const brown=new THREE.Color('#87715a'),charcoal=new THREE.Color('#464c52'),khaki=new THREE.Color('#747765');brown.lerp(charcoal,p(t,63.2,64.5));brown.lerp(khaki,p(t,65,67));set(material,'uColor',brown);garment.group.visible=t>5.6;
 for(const [name,uniform]of Object.entries(material.uniforms))if(name!=='uHardware'&&hardwareMaterial.uniforms[name])hardwareMaterial.uniforms[name].value=uniform.value;
 clones.forEach(({m,g,side},i)=>{const start=p(t,23+i*.27,25+i*.2),alpha=t<26.3?start*.36:(1-p(t,30.7+i*.28,32.7+i*.15))*.36;g.group.visible=alpha>.003;const settle=p(t,27.2+i*.35,31.3+i*.35);g.update({fit:lerp(side*.38,s.fit,settle),length:lerp(side*.25,s.length,settle),sleeve:lerp(side*.1,s.sleeve,settle),flat:0,detail:1,time:0});hologram(m,s,alpha);if(t<26.3){g.group.position.set(side*2.22*start,.10,-.16);g.group.scale.setScalar(lerp(.80,.72,start));g.group.rotation.y=side*.15;}else echoPosition(g.group,side,t);});
 echoes.forEach(({m,g,side,delay})=>{const alpha=w(t,26.8,27.5,30.9,32.9)*.05;g.visible=alpha>.002;hologram(m,s,alpha);echoPosition(g,side,t,delay);});
 drawIdea(t,s);
 const scanActive=w(t,7,7.4,12,12.8)+s.measurement+w(t,58.2,58.5,62.8,63.5);scanGroup.visible=scanActive>.01;let scanY=t<14?lerp(1.7,-1.65,p(t,6.4,12.2)):t<40?lerp(1.5,-1.45,p(t,33,38.3)):lerp(1.7,-1.65,s.fabric);scanGroup.position.set(0,scanY+.10,0);scanMaterial.opacity=.07*clamp(scanActive);scanBeam.material.opacity=.75*clamp(scanActive);
 const strokeA=w(t,39.5,40,46.9,47.5);stroke.visible=strokeHalo.visible=strokeA>.001;stroke.position.x=s.strokeX;strokeHalo.position.copy(stroke.position);strokeMaterial.opacity=strokeA;strokeHalo.material.opacity=.08*strokeA;
 callout(fitLabel,0,garment.anchors.chestLeft,[-1.40,.37,.7],w(t,14.2,14.8,16.8,17.3),'right');callout(lengthLabel,1,garment.anchors.length,[-1.25,-1.23,.7],w(t,17.1,17.7,19,19.5),'right');callout(sleeveLabel,2,garment.anchors.sleeve,[1.5,-.78,.7],w(t,19.3,19.8,21,21.5),'left');callout(detailLabel,3,garment.anchors.detail,[-1.32,.70,.7],w(t,21,21.5,22.4,23),'right');dimensions(t,s);
 const index=t>=72?7:s.index,beat=beats[index];$('#eyebrow').textContent=beat[2];$('#caption').textContent=t>=69?'Kustom your week.':beat[3];$('#phase').textContent=String(index+1).padStart(2,'0')+' / 08';$('#progress').style.transform=`scaleX(${t/72})`;canvas.dataset.time=t.toFixed(3);canvas.dataset.phase=beat[2];canvas.dataset.vertices=String(garment.mainMesh.geometry.attributes.position.count);renderer.render(scene,camera);
}
function resize(){const vp=$('#viewport');const ww=vp.clientWidth,hh=vp.clientHeight;renderer.setSize(ww,hh,false);const aspect=ww/hh;const vertical=aspect<.85?2.6:2.02;camera.left=-vertical*aspect;camera.right=vertical*aspect;camera.top=vertical;camera.bottom=-vertical;camera.updateProjectionMatrix();}
function scrollTime(){const story=$('#story'),span=story.offsetHeight-innerHeight;return clamp(-story.getBoundingClientRect().top/Math.max(1,span))*72;}
let last=-1,start=performance.now(),raf=0;
function tick(now){const t=fixed??(autoplay?clamp((now-start)/1000,0,72):scrollTime());if(Math.abs(last-t)>.0001){renderAt(t);last=t;}if(autoplay&&t<72)raf=requestAnimationFrame(tick);}
function schedule(){cancelAnimationFrame(raf);raf=requestAnimationFrame(tick)}
addEventListener('scroll',()=>{if(fixed!==null)return;autoplay=false;schedule()},{passive:true});addEventListener('resize',()=>{resize();last=-1;schedule()});
addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf)}else{start=performance.now()-Math.max(0,last)*1000;schedule()}});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();status.textContent='그래픽 연결이 중단되었습니다. 페이지를 새로고침해 주세요.'});
resize();renderAt(fixed??0);status.textContent='';document.body.dataset.ready='true';start=performance.now();schedule();

