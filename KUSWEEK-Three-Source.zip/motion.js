export const DURATION=72;
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const smooth=x=>{x=clamp(x);return x*x*(3-2*x)};
export const p=(t,a,b)=>smooth((t-a)/(b-a));
export const w=(t,a,b,c,d)=>p(t,a,b)*(1-p(t,c,d));
export const beats=[
 [0,7,'IDEA','아직 이름 없는 생각. 하나의 선에서.'],
 [7,14,'INTERPRET','AI가 아이디어를 읽고, 옷의 구조로.'],
 [14,23,'REFINE','고객의 요구가, 같은 옷의 형태를 바꿉니다.'],
 [23,33,'CONVERGE','여러 가능성이 하나의 기준으로 정렬됩니다.'],
 [33,40,'MEASURE','취향을 치수와 제작의 조건으로.'],
 [40,49,'DRAFT','굵은 선이 지나간 자리, 정밀한 설계선.'],
 [49,58,'PROJECT','평면의 설계가 깊이를 얻습니다.'],
 [58,72,'MATERIALISE','선에서 원단으로. 하나의 샘플이 되다.']
];
export function stateAt(t){t=clamp(Number.isFinite(t)?t:0,0,72);const flat=p(t,38.6,40)*(1-p(t,49.3,56.5));const shapeFade=1;return {t,index:Math.min(7,Math.max(0,beats.findIndex(b=>t>=b[0]&&t<b[1]))),flat,fit:(p(t,14.4,17)*.7-p(t,20.7,22.8)*.2)*shapeFade,length:-.42*p(t,17,19.2)*shapeFade,sleeve:-.5*p(t,19.3,21)*shapeFade,detail:.35+.65*p(t,21,22.8),mainScale:lerp(1,.79,w(t,22.5,25,29,33)),reveal:p(t,6.4,12.2),line:1-p(t,10.2,13),cad:p(t,39,40)*(1-p(t,49,56)),strokeX:lerp(-2.4,2.4,p(t,40,47)),fabric:p(t,58.3,63),color:p(t,64.3,66.8),settle:p(t,67.5,70),annotation:w(t,14,14.4,22,23),measurement:w(t,33.3,34,38.6,40),draft:w(t,40.5,42,48,49.5)};}
export function cubic(a,b,c,d,t){return a*(1-t)**3+3*b*(1-t)**2*t+3*c*(1-t)*t*t+d*t*t*t;}

