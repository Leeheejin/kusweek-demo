/**
 * Continuous, texture-free garment shading. Geometry and UVs are shared by
 * the wireframe, the flat CAD state and the woven fabric reveal.
 * uReveal / uScan: 0 = no reveal; 1 = reached the bottom. Both travel top to bottom.
 * uMaterialMix is the material activation envelope (0 off, >= .08 fully active).
 * uCad: 0 solid garment shading, 1 fine lines only on the drafting plane.
 * uStrokeX uses mesh-local X: CAD remains invisible strictly ahead of this edge.
 */
export function createGarmentMaterial(THREE, opts = {}) {
  const material = new THREE.ShaderMaterial({
    name: 'KUSWEEK continuous wire-to-cotton surface',
    uniforms: {
      uTime: { value: 0 },
      uScan: { value: 0 },
      uMaterialMix: { value: 0 },
      uColor: { value: new THREE.Color(opts.color ?? '#87715a') },
      uWireColor: { value: new THREE.Color(opts.wireColor ?? '#82d9ef') },
      uStateAlpha: { value: 1 },
      uWireStrength: { value: 1 },
      uReveal: { value: 1 },
      uCad: { value: 0 },
      uStrokeX: { value: 100 },
      // UVs are in physical model units; the grid therefore stays equally dense.
      uGrid: { value: opts.grid ?? 21 },
      uTop: { value: opts.top ?? 1.7 },
      uBottom: { value: opts.bottom ?? -1.65 },
      uHardware: { value: opts.hardware ? 1 : 0 },
    },
    vertexShader: /* glsl */`
      varying vec2 vUv;
      varying vec3 vLocalPosition;
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      void main() {
        vUv = uv;
        vLocalPosition = position;
        vec4 viewPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -viewPosition.xyz;
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * viewPosition;
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float uTime;
      uniform float uScan;
      uniform float uMaterialMix;
      uniform vec3 uColor;
      uniform vec3 uWireColor;
      uniform float uStateAlpha;
      uniform float uWireStrength;
      uniform float uReveal;
      uniform float uCad;
      uniform float uStrokeX;
      uniform float uGrid;
      uniform float uTop;
      uniform float uBottom;
      uniform float uHardware;
      varying vec2 vUv;
      varying vec3 vLocalPosition;
      varying vec3 vNormal;
      varying vec3 vViewPosition;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p);
        f = f*f*(3.0-2.0*f);
        return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x),
                   mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0)),f.x),f.y);
      }
      float quadGrid(vec2 uv, float density, float halfWidth) {
        vec2 q = uv * density;
        vec2 aa = max(fwidth(q), vec2(0.00001));
        vec2 d = abs(fract(q - 0.5) - 0.5) / aa;
        return 1.0 - smoothstep(halfWidth, halfWidth + 0.85, min(d.x, d.y));
      }
      vec3 wovenNormal(vec3 normal, float height) {
        // Surface-gradient bump mapping is valid without tangent attributes.
        // Both partial derivatives are taken on the same continuously deformed
        // geometry, so the cotton never slips when its silhouette changes.
        vec3 dx = dFdx(-vViewPosition);
        vec3 dy = dFdy(-vViewPosition);
        vec3 r1 = cross(dy,normal), r2 = cross(normal,dx);
        float determinant = dot(dx,r1);
        vec3 gradient = sign(determinant) *
          (dFdx(height)*r1+dFdy(height)*r2);
        return normalize(max(abs(determinant),0.000000001)*normal-gradient);
      }
      void main() {
        float height = clamp((uTop-vLocalPosition.y)/(uTop-uBottom),0.0,1.0);
        float heightAA = max(fwidth(height)*1.2,0.002);
        float reveal = 1.0 - smoothstep(uReveal-heightAA,uReveal+heightAA,height);
        if (uReveal >= 0.9999) reveal = 1.0;
        if (uReveal <= 0.00001 || reveal*uStateAlpha < 0.003) discard;

        // The CAD leading edge is exactly the same local X as the visible stroke.
        // No screen-space clip, second bitmap, panel masks or particle dissolve.
        float cadClip = vLocalPosition.x <= uStrokeX ? 1.0 : 0.0;
        float cad = clamp(uCad,0.0,1.0);

        vec3 N = normalize(vNormal) * (gl_FrontFacing ? 1.0 : -1.0);
        vec3 V = normalize(vViewPosition);
        vec3 L = normalize(vec3(-0.45,0.75,0.95));
        vec3 R = normalize(vec3(0.7,0.25,-0.6));
        float keyLight = max(dot(N,L),0.0);
        float rimLight = max(dot(N,R),0.0);
        float facing = max(dot(N,V),0.0);
        float fresnel = pow(1.0-facing,2.8);

        float grid = quadGrid(vUv,uGrid,0.34);
        float major = quadGrid(vUv,uGrid*0.2,0.50);
        float wire = max(grid*0.66,major*0.86);
        // Opaque shaded navy body makes the silhouette readable, without seeing
        // an incoherent stack of backfaces through the front of the garment.
        vec3 digitalBody = vec3(0.012,0.036,0.060)*(0.62+keyLight*1.55);
        digitalBody += uWireColor * fresnel * 0.055;
        vec3 digital = digitalBody + uWireColor*wire*(0.43+0.20*keyLight);

        float scanWidth = max(heightAA,0.004);
        float scanMask = 1.0-smoothstep(uScan-scanWidth,uScan+scanWidth,height);
        if (uScan <= 0.00001) scanMask=0.0;
        if (uScan >= 0.9999) scanMask=1.0;
        float fabric = scanMask*smoothstep(0.0,0.08,uMaterialMix)*(1.0-cad);

        // Procedural woven cotton: alternating thread crossings and restrained
        // irregular yarn widths. Derivative attenuation prevents distant moire.
        vec2 yarn = vUv*145.0;
        vec2 yarnCell = floor(yarn);
        float parity = mod(yarnCell.x+yarnCell.y,2.0);
        vec2 f = fract(yarn);
        float warp = exp(-pow((f.x-0.5)*3.6,2.0));
        float weft = exp(-pow((f.y-0.5)*3.6,2.0));
        float weave = mix(warp,weft,parity)-0.64;
        float weaveAA = 1.0-smoothstep(0.48,1.65,max(fwidth(yarn.x),fwidth(yarn.y)));
        weave *= weaveAA;
        float yarnVariation = noise(vUv*90.0)-0.5;
        float wash = noise(vUv*5.0)-0.5;
        vec3 clothN = wovenNormal(N,(weave*.00045+yarnVariation*.000075)*(1.0-uHardware));
        vec3 clothKey = normalize(vec3(-.85,.80,.72));
        vec3 clothFill = normalize(vec3(.82,-.14,.30));
        vec3 clothBack = normalize(vec3(.38,.74,-.65));
        float clothDiffuse = max(dot(clothN,clothKey),0.0);
        float clothFillLight = max(dot(clothN,clothFill),0.0);
        float clothBackLight = max(dot(clothN,clothBack),0.0);
        // A large warm key and much weaker fill preserve the depth of collar,
        // cuffs and seams. Low ambient avoids the evenly lit plastic appearance.
        vec3 light = vec3(.17,.185,.21)
          + vec3(1.0,.965,.90)*clothDiffuse*1.06
          + vec3(.70,.80,.92)*clothFillLight*.12
          + vec3(.77,.84,.90)*clothBackLight*.085;
        vec3 baseColor = mix(uColor,vec3(.048,.038,.029),uHardware);
        vec3 cloth = baseColor*light;
        cloth *= 1.0+(weave*.15+yarnVariation*.040+wash*.055)*(1.0-uHardware);
        vec3 H = normalize(clothKey+V);
        float softSpecular = pow(max(dot(clothN,H),0.0),mix(9.0,42.0,uHardware))
          *mix(.014,.11,uHardware)*clothDiffuse;
        float clothFacing = max(dot(clothN,V),0.0);
        float cottonSheen = pow(1.0-clothFacing,4.0)*(.008+clothDiffuse*.016);
        cottonSheen *= 1.0-uHardware;
        cloth += vec3(.94,.90,.83)*(softSpecular+cottonSheen);

        vec3 color = mix(digital,cloth,fabric);
        // Grid retreats at the scan boundary rather than fading the whole object.
        color += uWireColor*wire*clamp(uWireStrength,0.0,1.0)*fabric*(1.0-fabric)*0.025;
        float frontier = exp(-pow((height-uScan)/0.0045,2.0));
        frontier *= step(0.001,uScan)*(1.0-step(0.999,uScan));
        color += uWireColor*frontier*0.10*(1.0-cad);

        // On the drafting plane only precise UV curves remain. The plane itself
        // is not filled, and the stroke leaves these same curves in its wake.
        vec3 cadColor = uWireColor*(0.58+major*0.24);
        // A dim retained contour prevents a blank reset during the hand-off.
        // Only the bright, finished draft exists behind the exact stroke edge.
        // The depth projection must never superimpose the back torso UVs onto
        // the front draft. Use the unflipped geometric normal, not the shaded
        // DoubleSide normal, to retain only the forward-facing drafting surface.
        float frontDraft = smoothstep(0.0,0.075,vNormal.z);
        float cadAlpha = max(grid*0.15,major*0.85)*frontDraft*mix(0.035,1.0,cadClip);
        color = mix(color,cadColor,cad);
        float alpha = mix(1.0,cadAlpha,cad)*reveal*clamp(uStateAlpha,0.0,1.0);
        if(alpha < 0.004) discard;
        gl_FragColor = vec4(color,alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: true,
    depthTest: true,
    toneMapped: true,
  });
  return material;
}
