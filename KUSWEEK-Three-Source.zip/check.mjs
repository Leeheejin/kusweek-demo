import assert from 'node:assert/strict';
import * as THREE from './vendor/three.module.js';
import {createGarment} from './garment.js';
import {createGarmentMaterial} from './shaders.js';
import {stateAt,beats} from './motion.js';
const m=createGarmentMaterial(THREE),g=createGarment(THREE,m);
assert(g.group.isGroup);assert(g.mainMesh.isMesh);
let total=0;
g.group.traverse(o=>{if(!o.isMesh)return;const a=o.geometry.attributes;assert(a.position&&a.normal&&a.uv);assert(!m.map,'No raster map');for(const name of ['position','normal','uv'])for(const v of a[name].array)assert(Number.isFinite(v),`${o.name} ${name} NaN`);total+=a.position.count;});
assert(total>20000,'Smooth garment needs substantial geometry');
for(const t of [0,6,12,16,18,20,22,25,28,33,38,40,44,49,53,57,60,66,72]){const s=stateAt(t);g.update({fit:s.fit,length:s.length,sleeve:s.sleeve,flat:s.flat,detail:s.detail,time:0});g.group.traverse(o=>{if(o.isMesh)for(const v of o.geometry.attributes.position.array)assert(Number.isFinite(v),`Invalid deformation at ${t}`);});}
for(let t=0;t<=72;t+=.025){const s=stateAt(t);for(const [k,v]of Object.entries(s))assert(Number.isFinite(v),`Timeline ${k}`);assert(s.flat>=0&&s.flat<=1);assert(s.fabric>=0&&s.fabric<=1);assert(s.reveal>=0&&s.reveal<=1);}
assert.equal(stateAt(47).flat,1);assert.equal(stateAt(57).flat,0);assert.equal(stateAt(64).fabric,1);assert.equal(beats.length,8);
for(const name of ['uReveal','uStateAlpha','uMaterialMix','uScan','uCad','uStrokeX','uWireStrength'])assert(m.uniforms[name],`Missing shader contract ${name}`);
console.log(`PASS ${total.toLocaleString()} garment vertices, all 8 states finite, continuous deformation, no raster maps. GPU compilation / visual inspection must pass in browser.`);
