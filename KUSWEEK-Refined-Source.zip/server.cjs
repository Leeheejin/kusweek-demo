const http=require('http');
const fs=require('fs');
const path=require('path');
http.createServer((req,res)=>{
 const file=path.resolve(__dirname,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
 if(!file.startsWith(__dirname+path.sep)){res.writeHead(403);res.end();return;}
 fs.readFile(file,(e,data)=>{if(e){res.writeHead(404);res.end('Not found');return;}res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream','Cache-Control':'no-store'});res.end(data);});
}).listen(4318,'127.0.0.1',()=>console.log('Ready: http://127.0.0.1:4318/rebuild-review.html'));
