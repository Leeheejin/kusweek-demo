/**
 * Original SVG apparel drafting artwork, viewBox="0 0 1200 900".
 * A visual design study, not validated CAD or a production cutting file.
 * Known size-100 measurements below are finished-garment reference values.
 */
export function cadMarkup(){
  const fmt=n=>Number(n.toFixed(2));
  const p=(d,extra='')=>`<path d="${d}" pathLength="1" ${extra}/>`;
  const text=(x,y,value,extra='')=>`<text x="${x}" y="${y}" ${extra}>${value}</text>`;
  const dot=(x,y,r=2)=>p(`M${x-r} ${y}a${r} ${r} 0 1 0 ${r*2} 0a${r} ${r} 0 1 0 ${-r*2} 0`);
  const drill=(x,y)=>dot(x,y,2.4)+p(`M${x-5} ${y}L${x+5} ${y}M${x} ${y-5}L${x} ${y+5}`);
  // Bake stitch dashes into the path itself. The complete compound path can
  // then use stroke-dasharray:1 for drawing without losing the stitch rhythm.
  function stitches(source,dash=4,gap=4){
    const tokens=source.match(/[MLQCZ]|-?\d*\.?\d+/g)||[];
    let i=0,at=[0,0],first=[0,0],points=[];
    const add=q=>{points.push(q);at=q;};
    while(i<tokens.length){
      const command=tokens[i++];
      if(command==='M'){at=[+tokens[i++],+tokens[i++]];first=at.slice();points.push(at);}
      if(command==='L'){const end=[+tokens[i++],+tokens[i++]];const a=at.slice();for(let k=1;k<=16;k++){const t=k/16;add([a[0]+(end[0]-a[0])*t,a[1]+(end[1]-a[1])*t]);}}
      if(command==='Q'){
        const a=at.slice(),b=[+tokens[i++],+tokens[i++]],c=[+tokens[i++],+tokens[i++]];
        for(let k=1;k<=64;k++){const t=k/64,u=1-t;add([u*u*a[0]+2*u*t*b[0]+t*t*c[0],u*u*a[1]+2*u*t*b[1]+t*t*c[1]]);}
      }
      if(command==='C'){
        const a=at.slice(),b=[+tokens[i++],+tokens[i++]],c=[+tokens[i++],+tokens[i++]],d=[+tokens[i++],+tokens[i++]];
        for(let k=1;k<=80;k++){const t=k/80,u=1-t;add([u*u*u*a[0]+3*u*u*t*b[0]+3*u*t*t*c[0]+t*t*t*d[0],u*u*u*a[1]+3*u*u*t*b[1]+3*u*t*t*c[1]+t*t*t*d[1]]);}
      }
      if(command==='Z')add(first.slice());
    }
    let result='',distance=0,previous=points[0];
    const period=dash+gap;
    for(const next of points.slice(1)){
      const length=Math.hypot(next[0]-previous[0],next[1]-previous[1]);
      if(length<1e-8){previous=next;continue;}
      let cursor=0;
      while(cursor<length-1e-7){
        const phase=(distance+cursor)%period;
        const drawing=phase<dash;
        const remaining=(drawing?dash:period)-phase;
        const end=Math.min(length,cursor+Math.max(remaining,.00001));
        if(drawing){
          const a=cursor/length,b=end/length;
          result+=`M${fmt(previous[0]+(next[0]-previous[0])*a)} ${fmt(previous[1]+(next[1]-previous[1])*a)}L${fmt(previous[0]+(next[0]-previous[0])*b)} ${fmt(previous[1]+(next[1]-previous[1])*b)}`;
        }
        cursor=end;
      }
      distance+=length;previous=next;
    }
    return p(result);
  }
  const front='M122 235 C148 231 169 202 170 157 L281 194 C272 231 285 278 331 309 C326 359 318 429 321 484 C320 565 328 645 340 714 Q237 754 122 736 Z';
  const frontAllowance='M111 234 C141 225 159 195 159 144 L294 187 C282 225 295 274 342 303 C337 361 329 430 332 484 C331 566 338 645 352 720 Q238 768 111 745 Z';
  const frontSew='M132 244 C157 237 177 213 180 170 L269 200 C264 241 281 285 321 316 C316 367 308 430 311 484 C310 568 318 643 329 707 Q234 741 132 726 Z';
  const back='M449 173 Q480 173 490 151 L606 190 C601 234 616 280 656 310 C650 366 639 430 641 484 C642 566 650 649 662 716 Q566 749 449 736 Z';
  const backAllowance='M439 162 Q470 164 484 138 L618 183 C612 230 627 274 667 304 C661 368 650 432 652 484 C653 568 660 649 674 722 Q564 763 439 745 Z';
  const backSew='M459 182 Q486 183 496 165 L595 197 C592 243 610 289 646 317 C639 376 629 430 631 484 C632 567 640 645 651 709 Q560 736 459 726 Z';
  const sleeve='M811 322 C818 247 860 179 927 165 C994 152 1047 228 1071 322 C1058 434 1037 552 1018 645 Q934 663 843 646 C829 541 816 427 811 322 Z';
  const sleeveSew='M822 324 C829 251 868 190 929 176 C989 166 1035 235 1060 323 C1047 436 1028 550 1008 636 Q934 651 853 637 C841 534 828 425 822 324 Z';
  const sleeveAllowance='M800 322 C807 242 852 169 925 154 C1000 141 1057 221 1082 321 C1069 436 1047 556 1028 654 Q934 675 833 655 C818 542 805 429 800 322 Z';
  const collar='M797 704 L817 687 C903 699 1026 699 1108 687 L1130 704 L1092 740 C1009 724 908 724 834 740 Z';
  const collarSew='M810 705 L821 696 C907 707 1024 707 1104 697 L1117 705 L1089 730 C1007 715 910 715 839 730 Z';
  const stand='M813 784 Q813 774 827 772 C914 760 1022 760 1107 772 Q1119 774 1119 784 L1119 796 Q1119 804 1107 803 C1017 791 915 791 825 803 Q813 804 813 794 Z';
  const standSew='M821 785 Q821 780 831 779 C917 768 1020 768 1103 779 Q1111 780 1111 786 L1111 794 C1017 782 915 782 821 795 Z';
  const cuff='M813 831 L1080 831 Q1092 831 1092 841 L1092 861 Q1092 873 1080 873 L813 873 Z';
  const cuffSew='M821 839 L1077 839 Q1084 839 1084 846 L1084 858 Q1084 865 1077 865 L821 865 Z';
  const pockets='M184 354 L275 350 L279 445 Q279 464 260 468 L201 469 Q185 469 184 451 Z';
  // The front must remain the first outline: the Three.js / CAD optical bridge
  // derives its silhouette directly from this path.
  const outlines=[front,back,sleeve,collar,stand,cuff];
  const frontGradeSmall='M122 235 C148 231 168 206 169 161 L274 197 C266 233 278 277 322 307 C317 357 310 428 312 484 C311 561 318 638 329 705 Q232 746 122 726 Z';
  const frontGradeLarge='M122 235 C148 231 171 198 172 153 L288 191 C279 230 292 279 340 311 C334 361 326 430 329 484 C329 571 339 652 351 724 Q240 764 122 746 Z';
  const backGradeSmall='M449 173 Q479 173 489 155 L598 193 C594 235 607 279 647 308 C641 363 631 430 633 484 C634 562 641 641 651 707 Q560 741 449 726 Z';
  const backGradeLarge='M449 173 Q482 173 492 147 L614 187 C608 233 623 281 665 312 C659 370 647 431 650 484 C651 570 662 657 674 727 Q570 759 449 746 Z';
  const sleeveGradeSmall='M819 322 C826 252 865 186 927 173 C988 161 1038 233 1063 322 C1050 431 1029 548 1010 637 Q934 654 851 638 C837 535 824 425 819 322 Z';
  const sleeveGradeLarge='M803 322 C810 242 855 172 927 157 C1000 143 1056 223 1079 322 C1066 437 1045 556 1026 653 Q934 672 835 654 C821 547 808 429 803 322 Z';
  const patternLabels=[
    text(124,119,'FRONT / 01','class="piece-title"'),text(124,136,'CUT 2 · MIRRORED'),
    text(449,112,'BACK / 02','class="piece-title"'),text(449,129,'CUT 1 ON FOLD'),
    text(832,115,'SLEEVE / 03','class="piece-title"'),text(832,132,'CUT 2 · MIRRORED'),
    text(797,678,'COLLAR / 04','class="piece-title"'),text(1130,678,'CUT 2','text-anchor="end" class="tiny"'),
    text(813,759,'COLLAR STAND / 05','class="piece-title small-title"'),text(1119,759,'CUT 2','text-anchor="end" class="tiny"'),
    text(813,820,'CUFF / 06','class="piece-title small-title"'),text(1092,820,'CUT 2 PAIRS','text-anchor="end" class="tiny"'),
  ].join('');
  const buttons=[284,351,418,485,552,619,686].map(y=>dot(143,y,2.25)+p(`M138 ${y}L148 ${y}`)).join('');
  const frontNotches=p('M330 329L322 332L330 335M126 486L134 486M321 481L314 486L321 491M177 159L179 168L184 162');
  const backNotches=p('M653 329L645 332L652 335M652 339L644 342L651 345M641 481L634 486L642 491M449 486L457 486M497 153L499 162L505 156');
  const sleeveNotches=p('M922 167L927 176L932 164M826 260L835 265L823 270M1036 255L1028 261L1041 266M1041 266L1033 272L1045 276M869 650L874 641L879 651M975 652L980 642L985 651');
  return `<defs>
    <marker id="cad-arrow" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M1 1L7 4L1 7" pathLength="1" fill="none" stroke="#8db8f4" stroke-width=".9"/></marker>
    <marker id="cad-grain" viewBox="0 0 8 10" refX="4" refY="5" markerWidth="6" markerHeight="8" orient="auto-start-reverse"><path d="M1 2L4 8L7 2" pathLength="1" fill="none" stroke="#9ebed4" stroke-width=".8"/></marker>
    <style>
      .cad-plate{--cad-brand:#1d479c;--cad-frame:#1e469d;font-family:'IBM Plex Mono',ui-monospace,SFMono-Regular,Consolas,monospace;font-size:10.5px;letter-spacing:1px;fill:#99b1c8}
      .cad-plate path{vector-effect:non-scaling-stroke;stroke-linecap:round;stroke-linejoin:round}
      #cad .cad-plate text{font-family:'IBM Plex Mono',ui-monospace,SFMono-Regular,Consolas,monospace;fill:#9eb8ca}
      #cad .cad-plate .plate-title{font-size:21px;font-weight:500;letter-spacing:2px;fill:#e2eff8}
      #cad .cad-plate .piece-title{font-size:16px;font-weight:500;letter-spacing:1.65px;fill:#dcebf5}
      #cad .cad-plate .small-title{font-size:14px;letter-spacing:1.4px}
      #cad .cad-plate .metric{font-size:20px;letter-spacing:-.4px;fill:#d7e8fc}
      #cad .cad-plate .tiny{font-size:9.5px;letter-spacing:.7px}
      #cad .cad-plate .ref{font-size:11px;letter-spacing:.7px;fill:#b6cee0}
      #cad .cad-plate .soft{fill:#7291ac}
      #cad .cad-plate [data-layer="construction"]{stroke:#7297b5;stroke-width:.5}
      #cad .cad-plate [data-layer="allowance"]{stroke:#4774bb;stroke-width:.65}
      #cad .cad-plate [data-layer="outline"]{stroke:#d4e9f7;stroke-width:1.25}
      #cad .cad-plate [data-layer="seam"]{stroke:#82b3dc;stroke-width:.8}
      #cad .cad-plate [data-layer="dimension"]{stroke:#729ee2;stroke-width:.7}
      #cad .cad-plate [data-layer="dimension"][stroke="none"]{stroke:none}
      #cad .cad-plate .grade-lines{stroke:#4d74bb;stroke-width:.55;opacity:.9}
      #cad .cad-plate .frame{stroke:var(--cad-frame);stroke-width:1.5}
      #cad .cad-plate .drill-points{stroke:#bbd9ee;stroke-width:.75}
      #cad .cad-plate .construction-note{fill:#6c90ae;font-size:9.5px;letter-spacing:.8px}
    </style>
  </defs>
  <g class="cad-plate">
    <g data-layer="construction" fill="none" stroke="#31576c" stroke-width=".55">
      ${p('M63 89L1164 89')}
      ${p('M63 78L63 35L89 35M1164 78L1164 35L1138 35','class="frame"')}
      <g class="grade-lines" data-role="grading-study">${[frontGradeSmall,frontGradeLarge,backGradeSmall,backGradeLarge,sleeveGradeSmall,sleeveGradeLarge].map(d=>p(d)).join('')}</g>
      ${p('M99 309L365 309M422 310L691 310M790 322L1102 322')}
      ${p('M102 484L363 484M422 484L695 484M805 461L1062 461')}
      ${p('M121 153L121 749M449 148L449 751M941 149L941 663')}
      ${p('M170 149L170 244M281 182L281 320M490 140L490 195M606 180L606 321')}
      ${p('M811 322L1071 322M843 646L1018 645M927 149L927 332')}
      ${p('M811 322L927 165L1071 322M823 237L1051 237M867 207L867 332M1002 207L1002 332')}
      ${p('M811 322L818 247M860 179L927 165M927 165L994 152M1047 228L1071 322','stroke="#699bc1"')}
      ${[ [818,247], [860,179], [994,152], [1047,228] ].map(([x,y])=>dot(x,y,2)).join('')}
      ${p('M449 257Q535 247 624 267M468 258L468 349M481 257L481 349')}
      ${p('M464 286L485 286M464 320L485 320')}
      ${p(pockets,'stroke="#568196" stroke-width=".7"')}
      ${p('M182 370L277 366M184 354L185 370M275 350L277 366')}
      ${p('M987 538L991 639M997 537L1000 637M987 538L997 537')}
      ${p('M865 831L865 873M1059 831L1059 873M813 852L1092 852')}
      ${p('M839 699Q960 716 1093 699M939 687L939 737')}
      ${p('M823 786Q965 765 1107 786M965 764L965 798')}
      ${buttons}
      ${p('M227 538L227 675','stroke="#9ebed4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M548 364L548 657','stroke="#9ebed4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M941 350L941 610','stroke="#9ebed4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M866 720L1067 720','stroke="#9ebed4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M885 852L1037 852','stroke="#9ebed4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
    </g>
    <g data-layer="allowance" fill="none" stroke="#347d9c" stroke-width=".65">
      ${[frontAllowance,backAllowance,sleeveAllowance].map(d=>p(d)).join('')}
      ${p('M805 824L1081 824Q1099 824 1099 841L1099 862Q1099 880 1081 880L805 880Z')}
      ${p('M790 705L812 681C906 693 1025 693 1112 681L1138 705L1094 747C1009 731 910 731 831 747Z')}
      ${p('M807 783Q807 768 826 766C914 754 1022 754 1108 766Q1125 768 1125 783L1125 798Q1125 811 1106 809C1017 798 915 798 826 809Q807 811 807 796Z')}
    </g>
    <g data-layer="outline" fill="none" stroke="#d1effa" stroke-width="1.05">
      ${outlines.map(d=>p(d)).join('')}
      ${frontNotches}${backNotches}${sleeveNotches}
      ${p('M934 695L939 702L944 695M959 764L965 772L971 764M891 766L895 774L900 765M1030 765L1035 773L1039 766M942 831L947 838L952 831')}
      <g class="drill-points">${drill(194,377)}${drill(268,373)}${drill(196,451)}${drill(269,447)}${drill(992,546)}${drill(475,343)}</g>
    </g>
    <g data-layer="seam" fill="none" stroke="#71c4e1" stroke-width=".65">
      ${[frontSew,backSew,sleeveSew,collarSew,standSew,cuffSew].map(d=>stitches(d,4,3.8)).join('')}
      ${stitches('M459 263Q536 254 620 273',3.6,3.2)}
      ${stitches('M180 360L268 357L272 443Q273 458 256 461L202 462Q192 462 191 449L190 375',3.2,3.0)}
      ${stitches('M156 257L156 718',4,4)}
      ${stitches('M122 719Q232 737 333 700',4,3.8)}
      ${stitches('M449 719Q564 732 655 702',4,3.8)}
      ${stitches('M980 549L984 637',3.4,3)}
      ${stitches('M1005 550L1009 635',3.4,3)}
      ${p('M844 852L853 852M1050 852L1068 852M1050 848L1050 856M1068 848L1068 856')}
      ${dot(848,852,2.5)}
      ${dot(828,788,2.2)}${p('M1093 788L1107 788M1093 785L1093 791M1107 785L1107 791')}
    </g>
    <g data-layer="dimension" fill="none" stroke="#78bbd2" stroke-width=".65">
      ${p('M448 173L401 173M448 736L401 736M409 181L409 728','marker-start="url(#cad-arrow)" marker-end="url(#cad-arrow)"')}
      ${p('M934 164L1164 164M1019 646L1164 646M1155 172L1155 638','marker-start="url(#cad-arrow)" marker-end="url(#cad-arrow)"')}
      ${p('M132 788L330 788M132 782L132 794M330 782L330 794')}
      ${p('M464 788L649 788M464 782L464 794M649 782L649 794')}
      ${p('M342 606L369 606L379 618M331 606L342 606','stroke="#417e97"')}
      ${p('M933 178L966 148L1032 148','stroke="#6084b4"')}
      ${p('M995 572L1066 569L1103 552','stroke="#417e97"')}
      ${p('M127 257L89 274L89 316','stroke="#417e97"')}
      ${p('M607 190L675 174L727 174','stroke="#6084b4"')}
      ${p('M268 373L293 361L313 361M475 343L500 325L537 325','stroke="#6084b4"')}
      ${p('M865 842L879 829M1059 842L1073 829','stroke="#6084b4"')}
      ${p('M63 844L88 844','stroke="#d4e9f7" stroke-width="1.25"')}
      ${stitches('M217 844L244 844',4,3.5)}
      ${p('M373 844L399 844','stroke="#4774bb" stroke-width=".65"')}
      ${p('M565 841L591 841M565 847L591 847','stroke="#4d74bb" stroke-width=".55"')}
    </g>
    <g data-layer="dimension" stroke="none">
      ${text(82,53,'KUSWEEK / PATTERN STUDY','class="plate-title"')}
      ${text(82,73,'SHIRT JACKET · PROPOSED DRAFT / SPECIALIST REVIEW','class="tiny soft"')}
      ${text(1144,53,'100 / REGULAR FIT','text-anchor="end" class="piece-title"')}
      ${text(1144,73,'SCALE NTS · REFERENCE cm / DETAIL mm','text-anchor="end" class="tiny"')}
      ${patternLabels}
      ${text(236,596,'GRAIN','class="tiny" transform="rotate(-90 236 596)"')}
      ${text(558,493,'GRAIN / LENGTHWISE','class="tiny" transform="rotate(-90 558 493)"')}
      ${text(951,459,'GRAIN / LENGTHWISE','class="tiny" transform="rotate(-90 951 459)"')}
      ${text(395,454,'78 cm','text-anchor="middle" class="metric" transform="rotate(-90 395 454)"')}
      ${text(377,454,'CENTRE BACK · GARMENT REF.','text-anchor="middle" class="tiny" transform="rotate(-90 377 454)"')}
      ${text(1178,406,'60 cm','text-anchor="middle" class="metric" transform="rotate(-90 1178 406)"')}
      ${text(1193,406,'SLEEVE · GARMENT REF.','text-anchor="middle" class="tiny" transform="rotate(-90 1193 406)"')}
      ${text(122,777,'CENTRE FRONT + BUTTON STAND','class="tiny"')}
      ${text(449,777,'CENTRE BACK / FOLD LINE','class="tiny"')}
      ${text(122,817,'114 cm','class="metric"')}${text(205,816,'CHEST / FULL GIRTH','class="tiny"')}
      ${text(449,817,'48 cm','class="metric"')}${text(522,816,'SHOULDER / FULL WIDTH','class="tiny"')}
      ${text(353,630,'SA 10 mm','class="tiny"')}
      ${text(353,643,'PROPOSED','class="tiny soft"')}
      ${text(1039,151,'CAP / EASE','class="tiny"')}
      ${text(1098,542,'PLACKET OPENING','class="tiny" text-anchor="end"')}
      ${text(80,321,'CF','class="tiny"')}
      ${text(674,165,'SHOULDER','class="tiny"')}
      ${text(800,473,'ELBOW LINE','class="tiny" text-anchor="end"')}
      ${text(691,305,'CHEST','class="tiny"')}
      ${text(695,479,'WAIST','class="tiny"')}
      ${text(313,355,'DRILL','class="construction-note" text-anchor="end"')}
      ${text(502,318,'PLEAT END','class="construction-note"')}
      ${text(188,339,'POCKET POSITION','class="construction-note"')}
      ${text(469,239,'YOKE SEAM','class="construction-note"')}
      ${text(96,848,'CUT OUTLINE','class="tiny"')}${text(252,848,'STITCH LINE','class="tiny"')}
      ${text(407,848,'SEAM ALLOWANCE','class="tiny"')}${text(599,848,'GRADE STUDY','class="tiny"')}
      ${text(63,871,'SIZE 100 / REGULAR FIT · FINISHED-GARMENT REFERENCES','class="tiny soft"')}
      ${text(63,887,'ILLUSTRATIVE DRAFT · NOT A VALIDATED PATTERN OR CUTTING FILE','class="tiny soft"')}
    </g>
  </g>`;
}

