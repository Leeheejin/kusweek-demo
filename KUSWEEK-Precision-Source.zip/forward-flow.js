/**
 * The main leader's immutable screen-space route. Coordinates are NDC.
 * X never decreases; Y never increases. No garment, camera or clock is read.
 * Older tail points occupy the same route above/left of the current head.
 */
export function createForwardFlow(THREE,{mobile=false}={}) {
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,Number.isFinite(x)?x:0));
  const ease=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
  const V=(x,y)=>new THREE.Vector3(x,y,0);
  const trailLength=.18,trailSamples=100;
  const keys=[
    {t:0,p:mobile?V(-.45,.10):V(.08,.54)},
    {t:8,p:mobile?V(.35,.04):V(.54,.46)},
    {t:14.5,p:mobile?V(.58,-.16):V(.58,.28)},
    {t:30,p:V(.62,-.28)},
    {t:42,p:V(.67,-.40)},
    {t:50,p:V(.71,-.48)},
    {t:75,p:V(.78,-.64)},
    {t:84,p:V(.81,-.72)},
    {t:90,p:V(.84,-.78)},
  ];
  const directions=keys.map((key,i)=>{
    const before=keys[Math.max(0,i-1)].p,after=keys[Math.min(keys.length-1,i+1)].p;
    return after.clone().sub(before).normalize();
  });
  const segments=[];
  const preroll=new THREE.LineCurve3(keys[0].p.clone().addScaledVector(directions[0],-trailLength),keys[0].p);
  const definitions=[{name:'preroll',curve:preroll,timeStart:null,timeEnd:0,divisions:40}];
  for(let i=0;i<keys.length-1;i++){
    const a=keys[i].p,b=keys[i+1].p,delta=b.clone().sub(a),length=delta.length();
    const startDirection=directions[i],endDirection=directions[i+1];
    // Both controls consume at most 42% of each component's available span.
    // Their component ordering is therefore guaranteed, even where the route
    // turns from a broad horizontal sweep into a mostly downward movement.
    const boundedHandle=direction=>Math.min(length*.34,
      Math.abs(direction.x)>1e-9?Math.abs(delta.x)*.42/Math.abs(direction.x):Infinity,
      Math.abs(direction.y)>1e-9?Math.abs(delta.y)*.42/Math.abs(direction.y):Infinity);
    const c1=a.clone().addScaledVector(startDirection,boundedHandle(startDirection));
    const c2=b.clone().addScaledVector(endDirection,-boundedHandle(endDirection));
    const curve=new THREE.CubicBezierCurve3(a,c1,c2,b);
    curve.arcLengthDivisions=480;curve.updateArcLengths();
    definitions.push({name:`flow-${i}`,curve,timeStart:keys[i].t,timeEnd:keys[i+1].t,divisions:180,
      controls:[a.clone(),c1.clone(),c2.clone(),b.clone()]});
  }
  const points=[],lengths=[];
  let cumulative=0;
  for(const definition of definitions){
    const startDistance=cumulative;
    for(let i=0;i<=definition.divisions;i++){
      const p=definition.curve.getPointAt(i/definition.divisions);
      if(points.length&&p.distanceToSquared(points.at(-1))<1e-20)continue;
      if(points.length)cumulative+=p.distanceTo(points.at(-1));
      points.push(p);lengths.push(cumulative);
    }
    segments.push({...definition,startDistance,endDistance:cumulative,length:cumulative-startDistance});
  }
  const totalDistance=cumulative,duration=90;
  function pointAtDistance(distance){
    const d=clamp(distance,0,totalDistance);
    if(d===0)return points[0].clone();
    if(d===totalDistance)return points.at(-1).clone();
    let lo=1,hi=lengths.length-1;
    while(lo<hi){const mid=(lo+hi)>>1;if(lengths[mid]<d)lo=mid+1;else hi=mid;}
    const q=(d-lengths[lo-1])/Math.max(1e-12,lengths[lo]-lengths[lo-1]);
    return points[lo-1].clone().lerp(points[lo],q);
  }
  function phaseAt(time){
    const t=clamp(time,0,duration);
    let index=0;
    while(index<keys.length-2&&t>=keys[index+1].t)index++;
    return {t,index,segment:segments[index+1]};
  }
  function distanceAt(time){
    const {t,segment}=phaseAt(time);
    return segment.startDistance+segment.length*ease((t-segment.timeStart)/(segment.timeEnd-segment.timeStart));
  }
  function positionAt(time){return pointAtDistance(distanceAt(time));}
  function sample(time){
    const {t,index}=phaseAt(time),distance=distanceAt(t);
    const trailStartDistance=Math.max(0,distance-trailLength);
    const head=pointAtDistance(distance);
    const trail=Array.from({length:trailSamples},(_,i)=>pointAtDistance(
      trailStartDistance+(distance-trailStartDistance)*i/(trailSamples-1)));
    trail[trail.length-1].copy(head);
    return {head,trail,distance,trailStartDistance,trailEndDistance:distance,
      progress:t/duration,phaseIndex:index};
  }
  return {sample,positionAt,distanceAt,pointAtDistance,segments,keys,
    duration,totalDistance,trailLength,coordinateSpace:'NDC',mobile};
}
