import assert from 'node:assert/strict';
import * as THREE from './vendor/three.module.js';
import {createGarment} from './garment.js';
import {createGarmentMaterial} from './shaders.js';
import {createDraft} from './cad.js';
import {stateAt,drawingAt,DURATION} from './motion-v2.js';
const garment=createGarment(THREE,createGarmentMaterial(THREE));
const draft=createDraft(THREE,garment);
const counts=garment.meshes.map(m=>m.geometry.attributes.position.count);
for(const t of [0,8,15,20,28,35,42,49,53,58,62,66,71,73,76,84,85,100,105]){
 const s=stateAt(t);garment.update({fit:s.fit,length:s.length,sleeve:s.sleeve,detail:s.detail});
 assert.deepEqual(garment.meshes.map(m=>m.geometry.attributes.position.count),counts);
 for(const m of garment.meshes)assert(m.geometry.attributes.position.array.every(Number.isFinite));
 draft.update({drawingProgress:drawingAt(t),projection:Math.min(1,s.projection),fit:s.fit,length:s.length,sleeve:s.sleeve});
 assert(draft.geometry.attributes.position.array.every(Number.isFinite));
 assert(draft.penPosition.toArray().every(Number.isFinite));
 const contour=garment.sampleContour(300);assert(contour[0].distanceTo(contour.at(-1))<1e-4);
}
// Reversing the scroll restores the identical line coordinates, without any
// accumulated animation state or changed topology.
draft.update({drawingProgress:.63,projection:.42,fit:.52,length:-.42,sleeve:-.48});
const snapshot=draft.geometry.attributes.position.array.slice(),pen=draft.penPosition.clone();
draft.update({drawingProgress:1,projection:1,fit:.52,length:-.42,sleeve:-.48});
draft.update({drawingProgress:.63,projection:.42,fit:.52,length:-.42,sleeve:-.48});
assert.deepEqual(draft.geometry.attributes.position.array,snapshot);assert(draft.penPosition.distanceTo(pen)<1e-8);
let previous=0;for(let time=0;time<=DURATION;time+=.05){const current=drawingAt(time);assert(current>=previous);previous=current;}
console.log('Shared topology, finite geometry, closed carrier contour, reversible CAD drawing and pen trajectory passed.');
