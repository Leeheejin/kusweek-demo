/**
 * One immutable, arc-length-parameterized introduction route.
 * The head and its fixed physical tail are windows on the SAME authored path.
 * No prior frames, history durations, alternate outlines or elapsed-time walks.
 */
export function createIntroMotion(THREE, worldContour, scanRightTop, scanRightBottom, options={}) {
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,Number.isFinite(x)?x:0));
  const quintic=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
  const V=(x,y,z=0)=>new THREE.Vector3(x,y,z);
  const clone=p=>p?.isVector3?p.clone():new THREE.Vector3(...p);
  const tailLength=options.trailLength??.8;
  const trailSamples=Math.max(12,options.trailSamples??120);
  const times={outlineStart:4,outlineEnd:7.4,scanStart:8,scanEnd:14.5,...options.times};
  const top=clone(scanRightTop),bottom=clone(scanRightBottom);
  let source=worldContour.map(clone).filter((p,i,a)=>i===0||p.distanceToSquared(a[i-1])>1e-12);
  if(source.length>1&&source[0].distanceToSquared(source.at(-1))<1e-10)source.pop();
  if(source.length<8)throw new Error('Intro motion requires a closed garment contour with at least eight points.');
  // Start on the topmost collar crest. Its rightward tangent lets the arrival,
  // full clockwise outline and outward connector share a continuous heading.
  let first=0;
  for(let i=1;i<source.length;i++)if(source[i].y>source[first].y)first=i;
  let tangent=source[(first+1)%source.length].clone().sub(source[(first+source.length-1)%source.length]);
  const direction=tangent.x<0?-1:1;
  source=Array.from({length:source.length},(_,i)=>source[(first+direction*i+source.length*2)%source.length].clone());
  const outlineCurve=new THREE.CatmullRomCurve3(source,true,'centripetal',.5);
  outlineCurve.arcLengthDivisions=Math.max(2048,source.length*8);
  outlineCurve.updateArcLengths();
  const entry=outlineCurve.getPointAt(0);
  const entryTangent=outlineCurve.getTangentAt(0).normalize();
  if(entryTangent.x<.1)throw new Error('The collar entry must have a rightward tangent; check contour ordering.');
  // Start inside the lower-left garment area and rise into the collar. The
  // preroll also extends downwards here, rather than into the desktop copy or
  // the mobile headline above the garment.
  const start=options.start?clone(options.start):entry.clone()
    .add(V(-(options.approachSpan??.86),options.approachLift??-1.35,0));
  const startTangent=options.startTangent?clone(options.startTangent).normalize():V(.28,.96,0).normalize();
  const approachHandle=options.approachHandle??.70;
  const arrivalHandle=options.arrivalHandle??.42;
  const approach=new THREE.CubicBezierCurve3(start,
    start.clone().addScaledVector(startTangent,approachHandle),
    entry.clone().addScaledVector(entryTangent,-arrivalHandle),entry);
  const scanTangent=bottom.clone().sub(top).normalize();
  const exitHandle=Math.min(.63,Math.max(.22,(top.x-entry.x)*.42));
  const scanHandle=Math.min(.37,Math.max(.21,entry.distanceTo(top)*.25));
  const departure=new THREE.CubicBezierCurve3(entry,
    entry.clone().addScaledVector(entryTangent,exitHandle),
    top.clone().addScaledVector(scanTangent,-scanHandle),top);
  const scanning=new THREE.LineCurve3(top,bottom);
  // A short collinear preroll means the visible tail already has its requested
  // physical length at t=0, without inventing or later dropping earlier history.
  const preroll=new THREE.LineCurve3(start.clone().addScaledVector(startTangent,-tailLength),start);
  const definitions=[
    {name:'preroll',curve:preroll,divisions:40,timeStart:null,timeEnd:0},
    {name:'approach',curve:approach,divisions:420,timeStart:0,timeEnd:times.outlineStart},
    {name:'outline',curve:outlineCurve,divisions:2400,timeStart:times.outlineStart,timeEnd:times.outlineEnd},
    {name:'departure',curve:departure,divisions:480,timeStart:times.outlineEnd,timeEnd:times.scanStart},
    {name:'scan',curve:scanning,divisions:360,timeStart:times.scanStart,timeEnd:times.scanEnd},
  ];
  const points=[],lengths=[],segments=[];
  let cumulative=0;
  for(const definition of definitions){
    const startDistance=cumulative;
    for(let i=0;i<=definition.divisions;i++){
      const p=definition.curve.getPointAt(i/definition.divisions);
      if(points.length&&p.distanceToSquared(points.at(-1))<1e-18)continue;
      if(points.length)cumulative+=p.distanceTo(points.at(-1));
      points.push(p);lengths.push(cumulative);
    }
    segments.push({...definition,startDistance,endDistance:cumulative,length:cumulative-startDistance});
  }
  const [prefix,arrival,outline,exit,scan]=segments;
  const totalDistance=cumulative;
  const outlinePoints=outlineCurve.getSpacedPoints(options.outlineSamples??720);
  function pointAtDistance(distance){
    const d=clamp(distance,0,totalDistance);
    if(d===0)return points[0].clone();
    if(d===totalDistance)return points.at(-1).clone();
    let lo=1,hi=lengths.length-1;
    while(lo<hi){const mid=(lo+hi)>>1;if(lengths[mid]<d)lo=mid+1;else hi=mid;}
    const alpha=(d-lengths[lo-1])/Math.max(1e-12,lengths[lo]-lengths[lo-1]);
    return points[lo-1].clone().lerp(points[lo],alpha);
  }
  function progress(t,a,b){return quintic((t-a)/(b-a));}
  function distanceAt(t){
    t=clamp(t,0,times.scanEnd);
    if(t<times.outlineStart)return arrival.startDistance+arrival.length*progress(t,0,times.outlineStart);
    if(t<times.outlineEnd)return outline.startDistance+outline.length*progress(t,times.outlineStart,times.outlineEnd);
    if(t<times.scanStart)return exit.startDistance+exit.length*progress(t,times.outlineEnd,times.scanStart);
    return scan.startDistance+scan.length*progress(t,times.scanStart,times.scanEnd);
  }
  function positionAt(t){
    // Use the exact same quintic and endpoints as the horizontal scan beam.
    // Explicit interpolation avoids even arc-table interpolation roundoff here.
    if(t>=times.scanStart)return top.clone().lerp(bottom,progress(t,times.scanStart,times.scanEnd));
    return pointAtDistance(distanceAt(t));
  }
  function sample(t){
    const distance=distanceAt(t),trailStartDistance=Math.max(0,distance-tailLength);
    const head=positionAt(t);
    const trail=Array.from({length:trailSamples},(_,i)=>pointAtDistance(
      trailStartDistance+(distance-trailStartDistance)*i/(trailSamples-1)));
    trail[trail.length-1].copy(head);
    const tangent=pointAtDistance(Math.min(totalDistance,distance+.001))
      .sub(pointAtDistance(Math.max(0,distance-.001))).normalize();
    const outlineProgress=t<times.outlineStart?0:t>=times.outlineEnd?1:progress(t,times.outlineStart,times.outlineEnd);
    const phase=t<times.outlineStart?'approach':t<times.outlineEnd?'outline':t<times.scanStart?'departure':'scan';
    return {head,trail,distance,trailStartDistance,trailEndDistance:distance,tangent,
      outlinePoints,outlineProgress,phase,scanProgress:progress(t,times.scanStart,times.scanEnd)};
  }
  return{sample,positionAt,distanceAt,pointAtDistance,outlinePoints,totalDistance,segments,
    handoffs:[times.outlineStart,times.outlineEnd,times.scanStart,times.scanEnd],
    trailLength:tailLength,entry,entryTangent,scanTop:top,scanBottom:bottom,times,
  };
}
