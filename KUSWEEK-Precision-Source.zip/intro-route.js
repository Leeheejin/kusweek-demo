/**
 * One immutable, arc-length-parameterized introduction route.
 * The head and its fixed physical tail are windows on the SAME authored path.
 * No prior frames, history durations, alternate outlines or elapsed-time walks.
 */
export function createIntroMotion(THREE, worldContour, scanRightTop, scanRightBottom, options={}) {
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,Number.isFinite(x)?x:0));
  const quintic=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
  const V=(x,y,z=0)=>new THREE.Vector3(x,y,z);
  const clone=p=>p?.isVector3?p.clone():new THREE.Vector3(...p);
  const tailLength=options.trailLength??.8;
  const trailSamples=Math.max(12,options.trailSamples??120);
  const times={outlineStart:4,outlineEnd:8,scanStart:8,scanEnd:14.5,...options.times};
  const top=clone(scanRightTop),bottom=clone(scanRightBottom);
  let source=worldContour.map(clone).filter((p,i,a)=>i===0||p.distanceToSquared(a[i-1])>1e-12);
  if(source.length>1&&source[0].distanceToSquared(source.at(-1))<1e-10)source.pop();
  if(source.length<8)throw new Error('Intro motion requires a closed garment contour with at least eight points.');
  // The contour is visual data only. The moving head NEVER traverses this
  // closed outline: it reveals it with a shared, left-to-right world-X mask.
  const outlineCurve=new THREE.CatmullRomCurve3(source,true,'centripetal',.5);
  outlineCurve.arcLengthDivisions=Math.max(2048,source.length*8);
  outlineCurve.updateArcLengths();
  const minContourX=Math.min(...source.map(p=>p.x));
  const maxContourX=Math.max(...source.map(p=>p.x));
  const visualScale=(top.y-bottom.y)/3.45;
  const centreY=(top.y+bottom.y)*.5;
  const entry=V(minContourX,Math.min(top.y,centreY+1.05*visualScale),top.z);
  const span=top.x-entry.x;
  if(span<=.01)throw new Error('The scan origin must be to the right of the garment silhouette.');
  // Control-point ordering guarantees nondecreasing X and Y up to scanTop.
  // The open sweep passes above the shoulders/collar; it never comes back to
  // the entry or tours the left half of a closed loop.
  const sweepControl1=V(entry.x+span*.34,top.y,top.z);
  const sweepControl2=V(entry.x+span*.76,top.y,top.z);
  const sweepCurve=new THREE.CubicBezierCurve3(entry,sweepControl1,sweepControl2,top);
  const entryTangent=sweepControl1.clone().sub(entry).normalize();
  // The short approach rises within the upper-left garment area. Its preroll
  // goes downward, away from the mobile headline, not above the scan ceiling.
  const start=options.start?clone(options.start):entry.clone()
    .add(V(-(options.approachSpan??.22*visualScale),options.approachLift??-.44*visualScale,0));
  const startTangent=options.startTangent?clone(options.startTangent).normalize():V(.12,.993,0).normalize();
  const approachHandle=options.approachHandle??.19*visualScale;
  const arrivalHandle=options.arrivalHandle??.15*visualScale;
  const approach=new THREE.CubicBezierCurve3(start,
    start.clone().addScaledVector(startTangent,approachHandle),
    entry.clone().addScaledVector(entryTangent,-arrivalHandle),entry);
  const scanning=new THREE.LineCurve3(top,bottom);
  // A short collinear preroll means the visible tail already has its requested
  // physical length at t=0, without inventing or later dropping earlier history.
  const preroll=new THREE.LineCurve3(start.clone().addScaledVector(startTangent,-tailLength),start);
  const definitions=[
    {name:'preroll',curve:preroll,divisions:40,timeStart:null,timeEnd:0},
    {name:'approach',curve:approach,divisions:420,timeStart:0,timeEnd:times.outlineStart},
    {name:'sweep',curve:sweepCurve,divisions:960,timeStart:times.outlineStart,timeEnd:times.scanStart},
    {name:'scan',curve:scanning,divisions:360,timeStart:times.scanStart,timeEnd:times.scanEnd},
  ];
  const points=[],lengths=[],segments=[];
  let cumulative=0;
  for(const definition of definitions){
    const startDistance=cumulative;
    for(let i=0;i<=definition.divisions;i++){
      const p=definition.curve.getPointAt(i/definition.divisions);
      if(points.length&&p.distanceToSquared(points.at(-1))<1e-18)continue;
      if(points.length)cumulative+=p.distanceTo(points.at(-1));
      points.push(p);lengths.push(cumulative);
    }
    segments.push({...definition,startDistance,endDistance:cumulative,length:cumulative-startDistance});
  }
  const [prefix,arrival,sweep,scan]=segments;
  const totalDistance=cumulative;
  const outlinePoints=outlineCurve.getSpacedPoints(options.outlineSamples??720);
  function pointAtDistance(distance){
    const d=clamp(distance,0,totalDistance);
    if(d===0)return points[0].clone();
    if(d===totalDistance)return points.at(-1).clone();
    let lo=1,hi=lengths.length-1;
    while(lo<hi){const mid=(lo+hi)>>1;if(lengths[mid]<d)lo=mid+1;else hi=mid;}
    const alpha=(d-lengths[lo-1])/Math.max(1e-12,lengths[lo]-lengths[lo-1]);
    return points[lo-1].clone().lerp(points[lo],alpha);
  }
  function progress(t,a,b){return quintic((t-a)/(b-a));}
  function distanceAt(t){
    t=clamp(t,0,times.scanEnd);
    if(t<times.outlineStart)return arrival.startDistance+arrival.length*progress(t,0,times.outlineStart);
    if(t<times.scanStart)return sweep.startDistance+sweep.length*progress(t,times.outlineStart,times.scanStart);
    return scan.startDistance+scan.length*progress(t,times.scanStart,times.scanEnd);
  }
  function positionAt(t){
    // Use the exact same quintic and endpoints as the horizontal scan beam.
    // Explicit interpolation avoids even arc-table interpolation roundoff here.
    if(t>=times.scanStart)return top.clone().lerp(bottom,progress(t,times.scanStart,times.scanEnd));
    return pointAtDistance(distanceAt(t));
  }
  function sample(t){
    const distance=distanceAt(t),trailStartDistance=Math.max(0,distance-tailLength);
    const head=positionAt(t);
    const trail=Array.from({length:trailSamples},(_,i)=>pointAtDistance(
      trailStartDistance+(distance-trailStartDistance)*i/(trailSamples-1)));
    trail[trail.length-1].copy(head);
    const tangent=pointAtDistance(Math.min(totalDistance,distance+.001))
      .sub(pointAtDistance(Math.max(0,distance-.001))).normalize();
    const contourRevealX=head.x;
    const outlineProgress=clamp((contourRevealX-minContourX)/(maxContourX-minContourX));
    const phase=t<times.outlineStart?'approach':t<times.scanStart?'sweep':'scan';
    return {head,trail,distance,trailStartDistance,trailEndDistance:distance,tangent,
      outlinePoints,outlineProgress,contourRevealX,sweepX:head.x,phase,scanProgress:progress(t,times.scanStart,times.scanEnd)};
  }
  return{sample,positionAt,distanceAt,pointAtDistance,outlinePoints,totalDistance,segments,
    handoffs:[times.outlineStart,times.scanStart,times.scanEnd],
    trailLength:tailLength,entry,entryTangent,scanTop:top,scanBottom:bottom,times,
  };
}
