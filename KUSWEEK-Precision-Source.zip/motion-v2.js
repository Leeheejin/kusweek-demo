export const DURATION=105;
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const p=(t,a,b)=>{const x=clamp((t-a)/(b-a));return x*x*(3-2*x)};
export const w=(t,a,b,c,d)=>p(t,a,b)*(1-p(t,c,d));
export const beats=[
 [0,8,'IDEA','생각의 선이,\n옷이 되기까지.','아직 모호한 아이디어에서 시작합니다. AI와 제작의 경험이 가능성을 하나씩 구체화합니다.'],
 [8,17,'INTERPRET','아이디어에\n구조를 입히다.','AI가 의도를 읽고 실루엣을 정리합니다. 목둘레와 어깨, 소매의 연결이 하나의 의류로 드러납니다.'],
 [17,30,'REFINE','원하는 만큼,\n달라지는 형태.','가상 샘플을 함께 보며 핏·기장·소매·디테일을 구체적인 제작 조건으로 바꿉니다.'],
 [30,42,'CONVERGE','여러 가능성, 하나의 기준.','완성된 시안의 윤곽과 구조가 하나의 기준안으로 정렬됩니다.'],
 [42,50,'MEASURE','감각에,\n기준을 더하다.','선택한 형태에 치수를 연결합니다. 고객의 취향이 제작자와 공유할 수 있는 기준이 됩니다.'],
 [50,75,'DRAFT','빛의 궤적이, 설계의 선으로.','외곽선 → 봉제선 → 시접 → 치수. 제작자가 검토할 도면을 단계적으로 그립니다.'],
 [75,84,'PROJECT','설계가 다시 깊이를 얻다.','연결된 설계선이 같은 의류의 입체 형태로 돌아옵니다.'],
 [84,105,'MATERIALISE','보이는 제안이,\n선택이 되다.','원단의 질감과 색상을 비교합니다. 함께 검토할 한 벌의 샘플에서 실제 제작의 다음 단계로.']
];
export function stateAt(time){
 const t=clamp(time,0,DURATION), index=t===DURATION?7:beats.findIndex(b=>t>=b[0]&&t<b[1]);
 return {t,index,reveal:p(t,7.5,14.5),fit:.7*p(t,17.8,20.5)-.18*p(t,27,29),length:-.42*p(t,21,23.5),sleeve:-.48*p(t,24,26.2),detail:.4+.6*p(t,27,29),
 draft:w(t,49,51,77,78.3),projection:0,surface:1-w(t,49.5,51.8,78.3,83),strokeX:lerp(-3.5,3.5,p(t,52,72)),cadDetail:1,fabric:p(t,84.2,87.2),settle:p(t,99,102),
 layout:w(t,30,32,37,42),measure:w(t,42,42.5,49,50),linen:p(t,94,96),drape:p(t,94,96)};
}
export function drawingAt(t){
 const phases=[[52,58,0,.341094],[59,62.5,.341094,.609932],[63.3,66,.609932,.801072],[66.6,68.2,.801072,.891890],[68.8,71.2,.891890,.976728],[71.7,72.5,.976728,1]];
 let value=0;for(const [a,b,lo,hi]of phases){if(t<a)break;value=lerp(lo,hi,p(t,a,b));if(t<b)break;}return value;
}
export const cubic=(a,b,c,d,t)=>a*(1-t)**3+3*b*(1-t)**2*t+3*c*(1-t)*t*t+d*t*t*t;
