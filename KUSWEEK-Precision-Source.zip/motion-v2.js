export const DURATION=105;
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const p=(t,a,b)=>{const x=clamp((t-a)/(b-a));return x*x*(3-2*x)};
export const w=(t,a,b,c,d)=>p(t,a,b)*(1-p(t,c,d));
export const beats=[
 [0,8,'IDEA','아직 모호한 생각.','하나의 선이 가능성의 윤곽을 찾습니다.'],
 [8,17,'INTERPRET','생각이 구조를 얻다.','AI가 아이디어를 읽고, 연결된 의류의 형태로 정리합니다.'],
 [17,30,'REFINE','요구가 형태를 바꾸다.','핏·기장·소매·디테일. 취향을 구체적인 설계 조건으로.'],
 [30,42,'CONVERGE','여러 가능성, 하나의 기준.','완성된 시안의 윤곽과 구조가 하나의 기준안으로 정렬됩니다.'],
 [42,50,'MEASURE','감각을 제작의 언어로.','선택한 형태에 치수와 제작 조건을 연결합니다.'],
 [50,75,'DRAFT','한 줄의 흐름. 정밀한 설계.','외곽선에서 봉제선과 시접까지, 제작자가 검토할 도면으로.'],
 [75,84,'PROJECT','설계가 다시 깊이를 얻다.','연결된 설계선이 같은 의류의 입체 형태로 돌아옵니다.'],
 [84,105,'MATERIALISE','선에서, 눈앞의 샘플로.','원단의 질감과 색상을 보며, 다음 제작을 구체화합니다.']
];
export function stateAt(time){
 const t=clamp(time,0,DURATION), index=t===DURATION?7:beats.findIndex(b=>t>=b[0]&&t<b[1]);
 return {t,index,reveal:p(t,7.5,14.5),fit:.7*p(t,17.8,20.5)-.18*p(t,27,29),length:-.42*p(t,21,23.5),sleeve:-.48*p(t,24,26.2),detail:.4+.6*p(t,27,29),
 draft:w(t,49,51,77,78.3),projection:0,surface:1-w(t,50,54,78.3,83),strokeX:lerp(-3.5,3.5,p(t,52,72)),cadDetail:1,fabric:p(t,84.2,87.2),settle:p(t,99,102),
 layout:w(t,30,32,37,42),measure:w(t,42,42.5,49,50),linen:p(t,94,96),drape:p(t,94,96)};
}
export function drawingAt(t){
 const phases=[[52,58,0,.341094],[59,62.5,.341094,.609932],[63.3,66,.609932,.801072],[66.6,68.2,.801072,.891890],[68.8,71.2,.891890,.976728],[71.7,72.5,.976728,1]];
 let value=0;for(const [a,b,lo,hi]of phases){if(t<a)break;value=lerp(lo,hi,p(t,a,b));if(t<b)break;}return value;
}
export const cubic=(a,b,c,d,t)=>a*(1-t)**3+3*b*(1-t)**2*t+3*c*(1-t)*t*t+d*t*t*t;
