/**
 * A fixed spatial route, with a monotone time-to-distance score.
 *
 * createCarrierRoute(THREE, keys, options)
 * keys: [{t, position, tangent?, via?, inHandle?, outHandle?, width?, opacity?}]
 *   position/tangent are Vector3s or [x,y,z]. Tangent is a direction.
 *   via belongs to the segment ARRIVING at this key. Each via is a Vector3,
 *   [x,y,z], or {position,tangent?,inHandle?,outHandle?}.
 *   Repeating the previous position without via creates a true hold. Holds
 *   share one spatial node and therefore one incoming/outgoing tangent.
 * options: {tailLength:.8, trailSamples:120, prefixPoints?, initialTangent?}
 *   prefixPoints is the preceding carrier's trail, oldest point first. Its
 *   last point must equal keys[0].position. This preserves the handoff tail.
 *
 * All inputs are copied ONCE. sample(t) never reads live garment transforms.
 * Every returned trail is one distance window on this same fixed route;
 * it cannot reveal an older path merely because a timed segment slows down.
 * An open authored route is still required: monotone arc distance alone does
 * not make a closed loop, camera move, or backwards authored leg feel forward.
 */
export function createCarrierRoute(THREE, keys, options = {}) {
  const finite = (v, fallback) => Number.isFinite(v) ? v : fallback;
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, finite(v, a)));
  const quintic = v => { const u = clamp(v); return u * u * u * (u * (u * 6 - 15) + 10); };
  const vector = value => {
    const p = value?.isVector3 ? value.clone() : Array.isArray(value)
      ? new THREE.Vector3(value[0], value[1], value[2] ?? 0)
      : new THREE.Vector3(value?.x, value?.y, value?.z ?? 0);
    if (![p.x, p.y, p.z].every(Number.isFinite)) throw new TypeError('Carrier positions must be finite vectors.');
    return p;
  };
  const direction = value => {
    const v = vector(value);
    if (v.lengthSq() < 1e-16) throw new RangeError('Carrier tangent must be a nonzero direction.');
    return v.normalize();
  };
  const nodeFrom = input => {
    const value = input?.position ? input : {position: input};
    return {
      position: vector(value.position),
      tangent: value.tangent ? direction(value.tangent) : null,
      inHandle: finite(value.inHandle, null),
      outHandle: finite(value.outHandle, null),
    };
  };
  if (!Array.isArray(keys) || keys.length < 2) throw new TypeError('A carrier route requires at least two time keys.');
  const tailLength = Math.max(0, options.tailLength ?? options.trailLength ?? .8);
  const trailSamples = Math.max(2, Math.floor(options.trailSamples ?? options.samples ?? 120));
  const nodes = [], score = [];
  function addNode(value) {
    const node = nodeFrom(value), previous = nodes.at(-1);
    if (previous && node.position.distanceToSquared(previous.position) < 1e-16) {
      if (node.tangent) {
        if (previous.tangent && node.tangent.dot(previous.tangent) < .99999)
          throw new RangeError('A stationary carrier key cannot change its spatial tangent.');
        previous.tangent = node.tangent;
      }
      if (node.inHandle !== null) previous.inHandle = node.inHandle;
      if (node.outHandle !== null) previous.outHandle = node.outHandle;
      return nodes.length - 1;
    }
    nodes.push(node);
    return nodes.length - 1;
  }
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (!Number.isFinite(key.t) || (i && key.t <= keys[i - 1].t))
      throw new RangeError('Carrier key times must be finite and strictly increasing.');
    if (i) for (const via of key.via ?? []) addNode(via);
    const nodeIndex = addNode(key);
    score.push({t:key.t, nodeIndex, width:finite(key.width, .018), opacity:clamp(key.opacity ?? 1)});
  }
  if (nodes.length < 2) throw new RangeError('A carrier route requires at least two distinct spatial positions.');
  const prefix = (options.prefixPoints ?? []).map(vector);
  if (prefix.length && prefix.at(-1).distanceTo(nodes[0].position) > 1e-5)
    throw new RangeError('Carrier prefix must end exactly at the first timed position.');
  if (!nodes[0].tangent && options.initialTangent) nodes[0].tangent = direction(options.initialTangent);
  if (!nodes[0].tangent && prefix.length > 1) {
    for (let i = prefix.length - 2; i >= 0; i--) {
      const incoming = nodes[0].position.clone().sub(prefix[i]);
      if (incoming.lengthSq() > 1e-12) { nodes[0].tangent = incoming.normalize(); break; }
    }
  }
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    if (node.tangent) continue;
    const incoming = i ? node.position.clone().sub(nodes[i - 1].position).normalize() : null;
    const outgoing = i + 1 < nodes.length ? nodes[i + 1].position.clone().sub(node.position).normalize() : null;
    if (!incoming || !outgoing) node.tangent = (incoming ?? outgoing).clone();
    else {
      // A genuine hairpin needs a authored bypass. Choosing an arbitrary normal
      // here would hide a loop in the interpolation and recreate the old bug.
      if (incoming.dot(outgoing) < -.965)
        throw new RangeError(`Carrier node ${i} reverses its incoming direction. Add a curved via bypass.`);
      node.tangent = incoming.add(outgoing).normalize();
    }
  }
  const points = [], lengths = [], spatialSegments = [];
  let totalDistance = 0;
  function append(p) {
    if (points.length) {
      const distance = p.distanceTo(points.at(-1));
      if (distance < 1e-11) return;
      totalDistance += distance;
    }
    points.push(p.clone()); lengths.push(totalDistance);
  }
  if (prefix.length) prefix.forEach(append);
  else if (tailLength > 0) append(nodes[0].position.clone().addScaledVector(nodes[0].tangent, -tailLength));
  append(nodes[0].position);
  nodes[0].distance = totalDistance;
  for (let i = 0; i < nodes.length - 1; i++) {
    const a = nodes[i], b = nodes[i + 1], chord = a.position.distanceTo(b.position);
    const previousLength = i ? a.position.distanceTo(nodes[i - 1].position) : chord;
    const nextLength = i + 2 < nodes.length ? b.position.distanceTo(nodes[i + 2].position) : chord;
    const h0 = Math.max(.00001, a.outHandle ?? Math.min(chord, previousLength) * .32);
    const h1 = Math.max(.00001, b.inHandle ?? Math.min(chord, nextLength) * .32);
    const c0 = a.position.clone().addScaledVector(a.tangent, h0);
    const c1 = b.position.clone().addScaledVector(b.tangent, -h1);
    const curve = new THREE.CubicBezierCurve3(a.position, c0, c1, b.position);
    const divisions = Math.max(96, Math.min(1024, Math.ceil((chord + h0 + h1) * 200)));
    const startDistance = totalDistance;
    for (let j = 1; j <= divisions; j++) append(curve.getPoint(j / divisions));
    b.distance = totalDistance;
    spatialSegments.push({index:i,startDistance,endDistance:totalDistance,length:totalDistance-startDistance,
      start:a.position.clone(),end:b.position.clone(),tangentStart:a.tangent.clone(),tangentEnd:b.tangent.clone()});
  }
  for (const key of score) key.distance = nodes[key.nodeIndex].distance;
  const start = score[0].t, end = score.at(-1).t;
  function pointAtDistance(value) {
    const d = clamp(value, 0, totalDistance);
    if (d <= 0) return points[0].clone();
    if (d >= totalDistance) return points.at(-1).clone();
    let lo = 1, hi = lengths.length - 1;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (lengths[mid] < d) lo = mid + 1; else hi = mid; }
    return points[lo - 1].clone().lerp(points[lo], (d - lengths[lo - 1]) / (lengths[lo] - lengths[lo - 1]));
  }
  function atTime(time) {
    const t = clamp(time, start, end);
    let i = 0;
    while (i < score.length - 2 && t > score[i + 1].t) i++;
    const a = score[i], b = score[i + 1], progress = quintic((t - a.t) / (b.t - a.t));
    return {t,index:i,a,b,progress,distance:a.distance + (b.distance - a.distance) * progress};
  }
  const distanceAt = t => atTime(t).distance;
  const positionAt = t => pointAtDistance(distanceAt(t));
  function tangentAtDistance(distance) {
    const delta = .0003;
    return pointAtDistance(Math.min(totalDistance, distance + delta))
      .sub(pointAtDistance(Math.max(0, distance - delta))).normalize();
  }
  function sample(time) {
    const s = atTime(time), distance = s.distance;
    const trailStartDistance = Math.max(0, distance - tailLength);
    const trail = Array.from({length:trailSamples}, (_, i) => pointAtDistance(
      trailStartDistance + (distance - trailStartDistance) * i / (trailSamples - 1)));
    const head = trail.at(-1).clone();
    return {t:s.t,head,position:head.clone(),trail,points:trail,tangent:tangentAtDistance(distance),
      distance,trailStartDistance,trailEndDistance:distance,segment:s.index,progress:s.progress,
      width:s.a.width + (s.b.width - s.a.width) * s.progress,
      opacity:s.a.opacity + (s.b.opacity - s.a.opacity) * s.progress};
  }
  return {sample,positionAt,distanceAt,pointAtDistance,tangentAtDistance,start,end,totalDistance,
    trailLength:tailLength,tailLength,trailSamples,segments:spatialSegments,
    keys:score.map(k => ({...k,position:nodes[k.nodeIndex].position.clone()})),
    handoffs:score.map(k => k.t)};
}
