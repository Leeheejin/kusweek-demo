import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import * as THREE from './vendor/three.module.js';
import {createPhotoGarment} from './photo-garment.js';
import {createDraft} from './cad.js';
import {createLightRibbon} from './light-ribbon.js';
import {sampleArc,createRoute} from './continuity.js';
import {photoAssets} from './assets.js';
import {DURATION,beats,clamp,lerp,p,w,drawingAt,stateAt} from './motion-v2.js';

// Actual runtime/geometry code, with browser and GPU boundaries stubbed.
// This checks image identity/metadata, not pixel decoding or shader compilation.
const digest=a=>createHash('sha256').update(Buffer.from(a.buffer,a.byteOffset,a.byteLength)).digest('hex');
const finite=v=>v.toArray().every(Number.isFinite);
function webpMetadata(source){
  assert(source.startsWith('data:image/webp;base64,'),'Images must be embedded');
  const bytes=Buffer.from(source.slice(source.indexOf(',')+1),'base64');
  assert.equal(bytes.toString('ascii',0,4),'RIFF');assert.equal(bytes.toString('ascii',8,12),'WEBP');
  assert.equal(bytes.toString('ascii',12,16),'VP8X');
  const result={width:bytes.readUIntLE(24,3)+1,height:bytes.readUIntLE(27,3)+1,alpha:!!(bytes[20]&16)};
  assert(result.alpha,'Cutout transparency is required');return result;
}
for(const name of ['hero','charcoal','khaki'])assert.deepEqual(webpMetadata(photoAssets[name]),{width:1024,height:1536,alpha:true});
let textureLoads=0;
class MetadataTextureLoader{
  load(source,onLoad,_progress,onError){try{
    const d=webpMetadata(source),texture=new THREE.Texture({width:d.width,height:d.height});
    texture.userData.source=source;textureLoads++;queueMicrotask(()=>onLoad(texture));return texture;
  }catch(error){queueMicrotask(()=>onError?.(error));}}
}
class StateOnlyRenderer{
  constructor({canvas}){this.canvas=canvas;this.ratio=1;}
  setPixelRatio(v){this.ratio=v;}getPixelRatio(){return this.ratio;}setClearColor(){}
  setSize(w,h){this.canvas.width=w*this.ratio;this.canvas.height=h*this.ratio;}
  getDrawingBufferSize(v){return v.set(this.canvas.width,this.canvas.height);}
  render(scene,camera){scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);scene.traverseVisible(o=>{if(o.isMesh)o.onBeforeRender?.(this,scene,camera,o.geometry,o.material,null);});}
}
const TestTHREE={...THREE,TextureLoader:MetadataTextureLoader,WebGLRenderer:StateOnlyRenderer};
const garment=createPhotoGarment(TestTHREE,photoAssets);await garment.ready;
assert.equal(garment.group.children.length,1);assert.equal(garment.vertexCount,241*361);
const geometry=garment.mesh.geometry,material=garment.mesh.material,uv=geometry.attributes.uv;
const originalPosition=digest(geometry.attributes.position.array),originalUV=digest(uv.array);
assert.equal(uv.count,garment.vertexCount);assert(uv.array.every(v=>Number.isFinite(v)&&v>=0&&v<=1));
garment.update({fit:.52,length:-.42,sleeve:-.48,photo:0,reveal:1,depth:1});
const anchors=()=>Object.fromEntries(Object.entries(garment.anchors).map(([k,v])=>[k,v.toArray()]));
const initialAnchors=anchors();
for(const photo of [0,.1,.4,.7,1,.4,0,1]){
  garment.update({photo,colorProgress:.75});
  assert.strictEqual(garment.mesh.geometry,geometry);assert.strictEqual(garment.mesh.material,material);
  assert.equal(digest(geometry.attributes.position.array),originalPosition,'Photo frontier replaced geometry');
  assert.equal(digest(uv.array),originalUV,'Photo and wire UV registration changed');assert.deepEqual(anchors(),initialAnchors);
  assert.equal(garment.uniforms.uColorProgress.value,photo>.9999?.75:0);
}
const fragment=material.fragmentShader;
assert.match(fragment,/float formation=scanMask\(uReveal,sourceHeight,revealAA\)/);
assert.match(fragment,/float photograph=scanMask\(uPhoto,sourceHeight,revealAA\)/);
assert.match(fragment,/mix\(digital,originalPhoto,photograph\)/);
assert.match(fragment,/uWorldRevealX-worldAA,uWorldRevealX\+worldAA,vWorldPoint\.x/);
const maskBody=fragment.match(/float scanMask\(float head,float coordinate,float aa\)\s*\{([\s\S]*?)\}/)?.[1];
assert(maskBody);const scanMask=new Function('head','coordinate','aa','smoothstep',maskBody);
const smoothstep=(a,b,x)=>{const q=Math.max(0,Math.min(1,(x-a)/(b-a)));return q*q*(3-2*q);};
for(const y of [0,.001,.1,.35,.5,.71,.999,1]){
  let previous=0;for(let i=0;i<=100;i++){const value=scanMask(i/100,y,.001,smoothstep);assert(value>=previous-1e-12&&value>=0&&value<=1);assert(Math.abs(value+(1-value)-1)<1e-12);previous=value;}
  assert.equal(scanMask(0,y,.001,smoothstep),0);assert.equal(scanMask(1,y,.001,smoothstep),1);
}

// Compare the actual pen with the timestamps on the actual drawing geometry.
const draft=createDraft(THREE,null),order=draft.drawingOrder,times=draft.geometry.attributes.aDrawAt;
assert.equal(order.length,67);assert.equal(times.count,21918);
const inkCount=t=>times.array.reduce((n,value)=>n+(value<=t),0);
let maxPenError=0,maxTransferJump=0,maxTrailJump=0,transferChecks=0;
function penSnapshot(progress,projection=0){
  draft.update({drawingProgress:progress,projection,detailProgress:1});assert(finite(draft.penPosition)&&finite(draft.penTangent));assert(draft.penTrail.every(finite));
  return{pen:draft.penPosition.clone(),trail:draft.penTrail.map(v=>v.clone())};
}
for(const path of order){
  const at=(path.start+path.end)/2;penSnapshot(at);assert(draft.penDrawing&&draft.penActive);
  let found=false;const pos=draft.geometry.attributes.position;
  for(let i=0;i<times.count;i+=2)if(times.getX(i)<=at&&times.getX(i+1)>=at){
    const f=(at-times.getX(i))/(times.getX(i+1)-times.getX(i)||1),expected=new THREE.Vector3().fromBufferAttribute(pos,i).lerp(new THREE.Vector3().fromBufferAttribute(pos,i+1),f);
    maxPenError=Math.max(maxPenError,expected.distanceTo(draft.penPosition));found=true;break;
  }assert(found,'Missing current drawing segment');
}
for(let i=1;i<order.length;i++){
  const lo=order[i-1].end,hi=order[i].start,span=hi-lo;
  assert.equal(inkCount(lo+span*.1),inkCount(lo+span*.9),'Pen-up travel left premature ink');
  penSnapshot((lo+hi)/2);assert(draft.penActive&&!draft.penDrawing);assert(Math.abs(draft.penOpacity-.28)<1e-8);
  for(const projection of [0,.5,1])for(const boundary of [lo,hi]){
    const a=penSnapshot(boundary-1e-9,projection),b=penSnapshot(boundary+1e-9,projection);
    maxTransferJump=Math.max(maxTransferJump,a.pen.distanceTo(b.pen));maxTrailJump=Math.max(maxTrailJump,...a.trail.map((v,j)=>v.distanceTo(b.trail[j])));transferChecks++;
  }
}
assert(maxPenError<1e-5&&maxTransferJump<1e-5&&maxTrailJump<1e-5);
let remaining=Infinity;
for(const exitScan of [0,.1,.25,.5,.75,.9,1]){
  draft.update({drawingProgress:1,exitScan,projection:0});assert(Math.abs(draft.scanX-(-3.27+6.44*exitScan))<1e-12);
  const count=draft.geometry.attributes.aDraftX.array.reduce((n,x)=>n+(x>draft.scanX),0);assert(count<=remaining);remaining=count;
  if(exitScan===0)assert.equal(count,times.count);
}assert.equal(remaining,0);assert.equal(draft.group.visible,false);

// Execute the real entry point rather than duplicating its scene transitions.
function element(width,height){return{clientWidth:width,clientHeight:height,width,height,offsetHeight:height*16,dataset:{},children:[],className:'',textContent:'',
  style:{setProperty(k,v){this[k]=v;}},append(v){this.children.push(v);},addEventListener(){},getBoundingClientRect(){return{top:0,width,height};}};}
function documentStub(width,height){const elements=new Map();return{hidden:false,body:element(width,height),addEventListener(){},
  querySelector(s){if(!elements.has(s))elements.set(s,element(width,height));return elements.get(s);},createElement(){return element(width,height);}};}
const entry=await fs.readFile(new URL('./app-continuous.js',import.meta.url),'utf8'),executable=entry.replace(/^import .+;\r?\n/gm,'');assert(!/^import\b/m.test(executable));
async function runtime(width,height){
  const document=documentStub(width,height),bindings={THREE:TestTHREE,createPhotoGarment,createDraft,createLightRibbon,sampleArc,createRoute,photoAssets,DURATION,beats,clamp,lerp,p,w,drawingAt,stateAt,
    document,location:{search:'?t=0'},matchMedia:()=>({matches:false}),devicePixelRatio:1.5,innerHeight:height,addEventListener(){},requestAnimationFrame:()=>1,cancelAnimationFrame(){},performance};
  const factory=new Function(...Object.keys(bindings),executable+'\nreturn {renderAt,garment,variants,draft,camera,scene,line,scanLine,contourLine,halo,getView:()=>view};');
  const r=factory(...Object.values(bindings));await Promise.all([r.garment.ready,...r.variants.map(v=>v.g.ready)]);await Promise.resolve();return r;
}
const scalarUniforms=us=>Object.fromEntries(Object.entries(us).filter(([,u])=>typeof u.value==='number').map(([k,u])=>[k,u.value]));
function snapshot(r,t){
  r.renderAt(t);const group=g=>({position:g.position.toArray(),scale:g.scale.toArray(),rotation:[g.rotation.x,g.rotation.y,g.rotation.z],visible:g.visible});
  return{camera:{position:r.camera.position.toArray(),left:r.camera.left,right:r.camera.right,top:r.camera.top,bottom:r.camera.bottom},
    garment:group(r.garment.group),uniforms:scalarUniforms(r.garment.uniforms),anchors:Object.fromEntries(Object.entries(r.garment.anchors).map(([k,v])=>[k,v.toArray()])),
    variants:r.variants.map(({g})=>g.group.visible?{group:group(g.group),uniforms:scalarUniforms(g.uniforms)}:{visible:false}),
    draft:{group:group(r.draft.group),pen:r.draft.penPosition.toArray(),trail:r.draft.penTrail.map(v=>v.toArray()),scanX:r.draft.scanX,penActive:r.draft.penActive,penDrawing:r.draft.penDrawing},
    light:r.halo.visible?{visible:true,position:r.halo.position.toArray()}:{visible:false}};
}
let runtimeChecks=0,maskChecks=0,maxHeadJump=0;const cpuSamples=[];
for(const width of [500,837,1265]){
  const r=await runtime(width,900),g=r.garment;assert.strictEqual(g.uniforms.uBrown.value,garment.uniforms.uBrown.value);
  const uvHash=digest(g.mesh.geometry.attributes.uv.array),mesh=g.mesh;
  for(const t of [0,6,8,15.5,19,23,27.5,34,39,46,51.5,52,53,58,60,65,70,73,75,77,78,79.5,81,82.2,84,86.2,88.5,93,96,105]){
    const before=snapshot(r,t);snapshot(r,t<54?100:12);const after=snapshot(r,t);
    assert.deepEqual(after,before,`Reverse scroll changed visible state: ${width}px at ${t}s`);
    assert.strictEqual(g.mesh,mesh);assert.equal(digest(g.mesh.geometry.attributes.uv.array),uvHash);assert(finite(r.draft.penPosition));runtimeChecks++;
  }
  for(const t of [77.5,78.5,79.5,80.5,81.5]){
    r.renderAt(t);const boundary=new THREE.Vector3(r.draft.scanX,0,0).applyMatrix4(r.draft.group.matrixWorld).x;
    const min=new THREE.Vector3(r.draft.bounds.min.x,0,0).applyMatrix4(r.draft.group.matrixWorld).x;
    const max=new THREE.Vector3(r.draft.bounds.max.x,0,0).applyMatrix4(r.draft.group.matrixWorld).x;
    const visibleBoundary=Math.max(min,Math.min(max,g.uniforms.uWorldRevealX.value));
    assert(Math.abs(boundary-visibleBoundary)<1e-8,`CAD erase and garment entry use different world X: ${width}px at ${t}s`);maskChecks++;
  }
  for(const t of [84,84.5,86,88.5]){
    r.renderAt(t);const view=r.getView();assert.equal(g.uniforms.uWorldScanTop.value,view.y+1.725*view.scale);assert.equal(g.uniforms.uWorldScanBottom.value,view.y-1.725*view.scale);assert.strictEqual(g.mesh,mesh);
  }
  for(const boundary of [4,7.4,8,14.5,17.2,20.3,21.1,23.6,24.1,26.3,27.1,29.7,32,40,42,48,49,52,75,76,77,82.2,83.1,84,88.5]){
    r.renderAt(boundary-1e-7);const before=r.halo.position.clone();r.renderAt(boundary+1e-7);const jump=before.distanceTo(r.halo.position);maxHeadJump=Math.max(maxHeadJump,jump);
    assert(jump<.0001,`Light head jumps at ${boundary}s (${width}px): ${jump}`);
  }
  if(process.argv.includes('--profile'))for(const t of [0,2.5,4,6,7.4,8,12,19,27,35,49,52,59,66,75,80,84,87,93]){
    const start=performance.now();r.renderAt(t);cpuSamples.push(performance.now()-start);
  }
  r.garment.dispose();r.variants.forEach(v=>v.g.dispose());r.draft.dispose();r.line.dispose();r.scanLine.dispose();r.contourLine.dispose();
}
assert.equal(textureLoads,3);let previous=0;for(let t=0;t<=DURATION;t+=.025){const current=drawingAt(t);assert(current>=previous-1e-12);previous=current;}
draft.dispose();garment.dispose();
cpuSamples.sort((a,b)=>a-b);
console.log(JSON.stringify({passed:true,source:'app-continuous.js',photoVertices:241*361,sharedTextures:textureLoads,cadPaths:order.length,
  transferBoundaryChecks:transferChecks,maxPenError,maxTransferJump,maxTrailJump,reversibleRuntimeStates:runtimeChecks,sharedWorldMaskChecks:maskChecks,maxRuntimeLightHeadJump:maxHeadJump,
  viewports:[500,837,1265],cpuStateOnlyProfile:cpuSamples.length?{frames:cpuSamples.length,medianMs:cpuSamples[Math.floor(cpuSamples.length*.5)],p95Ms:cpuSamples[Math.floor(cpuSamples.length*.95)]}:undefined,
  notCovered:'GPU compilation, raster output and image quality require browser review.'},null,2));
