/**
 * A finite history of one moving head. No whole-path interpolation, modulo head
 * resets, contour-to-beam collapse, or mutation of the input vectors.
 *
 * createRoute(keys,{autoTangents=false})
 *   keys = [{t,position:Vector3,tangent?:Vector3,width?,opacity?}]
 *   tangent = velocity in world units/second; omitted = a smooth zero-speed hold.
 *   Optional autoTangents creates bounded continuous through-velocities.
 *   Position uses a quintic Hermite segment, with zero acceleration at every key.
 *   Returns {sample(t),positionAt(t),sampleTail(t,seconds,count=200),start,end}.
 *
 * sampleArc(points,progress) returns a Vector3 at normalized physical arc length.
 * routeTrail(from,tangentFrom,to,tangentTo,progress,tail=.35,count=200)
 *   makes a cubic connector; tangent arguments are directions (not velocities).
 *
 * createContinuity(THREE).sample(t,context) returns ribbon input
 * {points,width,opacity,head:1,position,tangent,phase}. Supply context.route to
 * use any authored createRoute result; otherwise the 0–52s reference route is
 * built from context.anchors, context.penStart and context.penTangent.
 */
const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,Number.isFinite(v)?v:a));
const quintic=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
const mix=(a,b,p)=>a+(b-a)*p;

function arcTable(points){
  if(!points?.length)throw new TypeError('A route requires at least one point.');
  const lengths=new Float64Array(points.length);
  for(let i=1;i<points.length;i++)lengths[i]=lengths[i-1]+points[i].distanceTo(points[i-1]);
  const total=lengths[lengths.length-1];
  const at=p=>{
    const distance=clamp(p)*total;
    if(total<1e-12||distance<=0)return points[0].clone();
    if(distance>=total)return points.at(-1).clone();
    let low=0,high=lengths.length-1;
    while(high-low>1){const middle=(low+high)>>1;if(lengths[middle]<distance)low=middle;else high=middle;}
    const f=(distance-lengths[low])/Math.max(1e-12,lengths[high]-lengths[low]);
    return points[low].clone().lerp(points[high],f);
  };
  return{at,total};
}

export function sampleArc(points,progress){return arcTable(points).at(progress);}

export function routeTrail(from,tangentFrom,to,tangentTo,progress,tail=.35,count=200){
  const distance=from.distanceTo(to),handle=distance*.38;
  const chord=to.clone().sub(from);
  const direction=v=>v?.lengthSq()>1e-12?v.clone().normalize():chord.clone().normalize();
  const c1=from.clone().addScaledVector(direction(tangentFrom),handle);
  const c2=to.clone().addScaledVector(direction(tangentTo),-handle);
  const path=Array.from({length:257},(_,i)=>{
    const u=i/256,v=1-u;
    return from.clone().multiplyScalar(v*v*v)
      .addScaledVector(c1,3*v*v*u).addScaledVector(c2,3*v*u*u).addScaledVector(to,u*u*u);
  });
  const arc=arcTable(path),end=clamp(progress),begin=Math.max(0,end-clamp(tail));
  count=Math.max(2,Math.floor(count));
  return Array.from({length:count},(_,i)=>arc.at(mix(begin,end,i/(count-1))));
}

export function createRoute(keys,{autoTangents=false}={}){
  if(!Array.isArray(keys)||keys.length<2)throw new TypeError('A route needs at least two time keys.');
  const nodes=keys.map(k=>({...k,position:k.position.clone(),tangent:k.tangent?.clone()}));
  for(let i=0;i<nodes.length;i++){
    const n=nodes[i];
    if(!Number.isFinite(n.t)||!Number.isFinite(n.position.x+n.position.y+n.position.z))throw new TypeError('Route time and position must be finite.');
    if(i&&n.t<=nodes[i-1].t)throw new RangeError('Route keys must have strictly increasing time.');
    n.width=Math.max(.0001,Number.isFinite(n.width)?n.width:.012);
    n.opacity=clamp(n.opacity??1);
  }
  for(let i=0;i<nodes.length;i++){
    const n=nodes[i];
    if(n.tangent)continue;
    n.tangent=n.position.clone().multiplyScalar(0);
    if(!autoTangents)continue;
    const prev=nodes[Math.max(0,i-1)],next=nodes[Math.min(nodes.length-1,i+1)];
    n.tangent.copy(next.position).sub(prev.position).multiplyScalar(.82/(next.t-prev.t));
    if(i&&i<nodes.length-1){
      const maxSpeed=Math.min(n.position.distanceTo(prev.position)/(n.t-prev.t),next.position.distanceTo(n.position)/(next.t-n.t))*1.65;
      if(n.tangent.length()>maxSpeed)n.tangent.setLength(maxSpeed);
    }else n.tangent.multiplyScalar(.55);
  }
  const start=nodes[0].t,end=nodes.at(-1).t;
  function sample(time){
    const t=clamp(time,start,end);
    let j=0;while(j<nodes.length-2&&t>nodes[j+1].t)j++;
    const a=nodes[j],b=nodes[j+1],duration=b.t-a.t,u=(t-a.t)/duration;
    const delta=b.position.clone().sub(a.position);
    const v0=a.tangent.clone().multiplyScalar(duration),v1=b.tangent.clone().multiplyScalar(duration);
    const c3=delta.clone().multiplyScalar(10).addScaledVector(v0,-6).addScaledVector(v1,-4);
    const c4=delta.clone().multiplyScalar(-15).addScaledVector(v0,8).addScaledVector(v1,7);
    const c5=delta.clone().multiplyScalar(6).addScaledVector(v0,-3).addScaledVector(v1,-3);
    const position=a.position.clone().addScaledVector(v0,u).addScaledVector(c3,u**3).addScaledVector(c4,u**4).addScaledVector(c5,u**5);
    const tangent=v0.clone().addScaledVector(c3,3*u*u).addScaledVector(c4,4*u**3).addScaledVector(c5,5*u**4).multiplyScalar(1/duration);
    const q=quintic(u);
    return{position,tangent,width:mix(a.width,b.width,q),opacity:mix(a.opacity,b.opacity,q),t};
  }
  function sampleTail(time,seconds=1.5,count=200){
    count=Math.max(2,Math.floor(count));
    const to=clamp(time,start,end),from=Math.max(start,to-Math.max(0,seconds));
    const history=Array.from({length:Math.max(65,count)},(_,i)=>sample(mix(from,to,i/(Math.max(65,count)-1))).position);
    const arc=arcTable(history);
    return Array.from({length:count},(_,i)=>arc.at(i/(count-1)));
  }
  return{sample,positionAt:t=>sample(t).position,sampleTail,start,end};
}

export function createContinuity(THREE){
  const V=(x,y,z=.82)=>new THREE.Vector3(x,y,z);
  let signature='',cachedRoute;
  function build(context){
    const source=context.anchors??{};
    const anchor=(key,fallback)=>(source[key]??fallback).clone();
    const collar=anchor('collar',V(1.35,1.4));
    const left=anchor('chestLeft',V(collar.x-.72,.20));
    const right=anchor('chestRight',V(collar.x+.72,.20));
    const chest=left.clone().lerp(right,.5);
    const hem=anchor('length',V(collar.x,-1.45));
    const sleeve=anchor('sleeve',V(collar.x+1.12,-.96));
    const detail=anchor('detail',V(collar.x-.38,.69));
    const pen=(context.penStart??context.draftPenStart??V(-2.85,1.28,.82)).clone();
    const penTangent=(context.penTangent??V(.65,0,0)).clone();
    const offset=(p,x,y,z=0)=>p.clone().add(V(x,y,z));
    const keys=[
      {t:0,position:offset(collar,-5.10,-1.95,.10),width:.022,opacity:.50},
      {t:2.3,position:offset(collar,-3.92,-.05,.13),width:.028,opacity:1},
      {t:5.1,position:offset(collar,-1.92,-2.18,.05),width:.023},
      {t:8,position:collar,width:.014,tangent:V(0,-.39,0)},
      {t:11.3,position:chest,width:.012,tangent:V(0,-.43,0)},
      {t:14.4,position:hem,width:.011,tangent:V(-.32,.0,0)},
      {t:17,position:left,width:.010,tangent:V(0,.12,0)},
      {t:19.1,position:offset(left,-.09,.045),width:.009},
      {t:22.5,position:hem,width:.010},
      {t:25.5,position:sleeve,width:.010},
      {t:28.7,position:detail,width:.009},
      {t:30.5,position:offset(detail,.05,.22),width:.008,opacity:.65},
      {t:33.3,position:offset(collar,1.36,-.12,.14),width:.011,opacity:.66},
      {t:36.7,position:offset(collar,1.20,.46,.17),width:.012,opacity:.62},
      {t:40.4,position:offset(collar,-.26,.22,.05),width:.011,opacity:.80},
      {t:42,position:collar,width:.012,tangent:V(0,-.34,0)},
      {t:45.4,position:chest,width:.013,tangent:V(0,-.44,0)},
      {t:49,position:hem,width:.017,tangent:V(-.15,-.20,0)},
      {t:52,position:pen,width:.018,tangent:penTangent},
    ];
    const next=keys.map(k=>[k.t,k.position.x,k.position.y,k.position.z,k.tangent?.x,k.tangent?.y,k.tangent?.z].join(',')).join(';');
    if(next!==signature){signature=next;cachedRoute=createRoute(keys,{autoTangents:true});}
    return cachedRoute;
  }
  function sample(t,context={}){
    const route=context.route??build(context),state=route.sample(t);
    const stage=t<8?'idea':t<17?'formation':t<30?'requirements':t<42?'convergence':t<49?'measurement':'cad-transfer';
    const tailSeconds=context.tailSeconds??mix(3.45,1.40,quintic((t-5)/9));
    const transferTail=mix(tailSeconds,.86,quintic((t-48.2)/3.5));
    return{points:route.sampleTail(t,transferTail,context.count??200),width:state.width,opacity:state.opacity,head:1,position:state.position,tangent:state.tangent,phase:stage};
  }
  return{sample};
}
