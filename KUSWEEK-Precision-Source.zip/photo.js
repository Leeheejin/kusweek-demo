/**
 * Fixed, photographed final sample. The image is never displaced or recolored.
 * progress 0..1 reveals from world Y +1.725 to -1.725. After the reveal,
 * colorProgress 0..1 blends actual brown -> charcoal -> khaki image variants.
 * assetDataURLs accepts { hero|brown, charcoal, khaki } data URLs or asset URLs.
 * Await `ready` before the first rendered frame that needs the photographed sample.
 */
export function createPhotoSample(THREE, assetDataURLs) {
  const clamp = value => Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));
  const hero = assetDataURLs.hero ?? assetDataURLs.brown;
  if (!hero) throw new Error('A brown or hero sample image is required.');
  const group = new THREE.Group();
  group.name = 'KUSWEEK photographed final sample — fixed anchor';
  const empty = new THREE.DataTexture(new Uint8Array([0,0,0,0]),1,1);
  empty.needsUpdate = true;
  const uniforms = {
    uBrown: { value: empty },
    uCharcoal: { value: empty },
    uKhaki: { value: empty },
    uProgress: { value: 0 },
    uColorProgress: { value: 0 },
    uOpacity: { value: 1 },
    uTop: { value: 1.725 },
    uBottom: { value: -1.725 },
  };
  const material = new THREE.ShaderMaterial({
    name: 'Original garment photograph with continuous scan frontier',
    uniforms,
    vertexShader: /* glsl */`
      varying vec2 vUv;
      varying float vWorldY;
      void main() {
        vUv=uv;
        vec4 world=modelMatrix*vec4(position,1.0);
        vWorldY=world.y;
        gl_Position=projectionMatrix*viewMatrix*world;
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform sampler2D uBrown;
      uniform sampler2D uCharcoal;
      uniform sampler2D uKhaki;
      uniform float uProgress;
      uniform float uColorProgress;
      uniform float uOpacity;
      uniform float uTop;
      uniform float uBottom;
      varying vec2 vUv;
      varying float vWorldY;
      void main() {
        if(uProgress<=0.00001 || uOpacity<=0.00001) discard;
        vec4 brown=texture2D(uBrown,vUv);
        vec4 charcoal=texture2D(uCharcoal,vUv);
        vec4 khaki=texture2D(uKhaki,vUv);
        // Blend in premultiplied space so semi-transparent cutout edges do not
        // darken or acquire a fringe when two genuine photographed colors mix.
        brown.rgb*=brown.a;
        charcoal.rgb*=charcoal.a;
        khaki.rgb*=khaki.a;
        vec4 sampleColor=mix(brown,charcoal,smoothstep(0.0,0.5,uColorProgress));
        sampleColor=mix(sampleColor,khaki,smoothstep(0.5,1.0,uColorProgress));
        if(sampleColor.a<0.002) discard;
        vec3 originalColor=sampleColor.rgb/max(sampleColor.a,0.00001);
        float height=clamp((uTop-vWorldY)/(uTop-uBottom),0.0,1.0);
        float feather=max(fwidth(height)*1.2,0.002);
        float revealed=1.0-smoothstep(uProgress-feather,uProgress+feather,height);
        if(uProgress>=0.9999) revealed=1.0;
        float scanActive=step(0.001,uProgress)*(1.0-step(0.999,uProgress));
        float head=exp(-pow((height-uProgress)/0.0018,2.0))*scanActive;
        // A narrow cool frontier carries the line motif. It disappears entirely
        // on the finished photograph, which retains its original color and light.
        vec3 rgb=mix(originalColor,vec3(.50,.80,.94),head*.16);
        rgb+=vec3(.08,.13,.15)*head*.20;
        float alpha=sampleColor.a*revealed*uOpacity;
        if(alpha<0.002) discard;
        gl_FragColor=vec4(rgb,alpha);
        #include <colorspace_fragment>
        #include <premultiplied_alpha_fragment>
      }
    `,
    transparent: true,
    premultipliedAlpha: true,
    depthWrite: false,
    depthTest: true,
    side: THREE.FrontSide,
    toneMapped: false,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2.3,3.45),material);
  mesh.name = 'Same-anchor brown / charcoal / khaki photographic sample';
  mesh.position.set(0,0,.8);
  mesh.renderOrder = 30;
  mesh.visible = false;
  group.add(mesh);

  const loader = new THREE.TextureLoader();
  const cache = new Map();
  let loaded=false, current={progress:0,colorProgress:0,opacity:1};
  function load(source) {
    if (!cache.has(source)) cache.set(source,new Promise((resolve,reject)=>{
      loader.load(source, texture=>{
        texture.colorSpace=THREE.SRGBColorSpace;
        texture.minFilter=THREE.LinearMipmapLinearFilter;
        texture.magFilter=THREE.LinearFilter;
        texture.generateMipmaps=true;
        texture.wrapS=texture.wrapT=THREE.ClampToEdgeWrapping;
        texture.needsUpdate=true;
        resolve(texture);
      },undefined,reject);
    }));
    return cache.get(source);
  }
  function update({progress=current.progress,colorProgress=current.colorProgress,opacity=current.opacity}={}) {
    current={progress:clamp(progress),colorProgress:clamp(colorProgress),opacity:clamp(opacity)};
    uniforms.uProgress.value=current.progress;
    // Finish construction first; color variation then uses real reference pixels.
    uniforms.uColorProgress.value=current.progress>=.9999?current.colorProgress:0;
    uniforms.uOpacity.value=current.opacity;
    mesh.visible=loaded&&current.progress>0&&current.opacity>0;
  }
  const ready=Promise.all([load(hero),load(assetDataURLs.charcoal??hero),load(assetDataURLs.khaki??hero)])
    .then(([brown,charcoal,khaki])=>{
      uniforms.uBrown.value=brown;
      uniforms.uCharcoal.value=charcoal;
      uniforms.uKhaki.value=khaki;
      loaded=true;
      empty.dispose();
      update();
      return group;
    });
  return {group,update,ready,material,mesh};
}
