import * as THREE from './vendor/three.module.js';
import {createGarment} from './garment.js';
import {createGarmentMaterial} from './shaders.js';
import {createDraft} from './cad.js';
import {createPhotoSample} from './photo.js';
import {DURATION,beats,clamp,lerp,p,w,stateAt,cubic,drawingAt} from './motion-v2.js';
import {photoAssets} from './assets.js';
import {createLightRibbon} from './light-ribbon.js';

const $=s=>document.querySelector(s),canvas=$('#stage'),status=$('#status');
const query=new URLSearchParams(location.search);
const keyTimes={wire:15.5,cad:65,photo:85.1};
let fixed=query.has('frame')?keyTimes[query.get('frame')]:query.has('t')?clamp(Number(query.get('t'))||0,0,DURATION):null;
let autoplay=query.get('autoplay')==='1'&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance',preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor('#02070f',0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-4,4,2.3,-2.3,.1,30);
camera.position.set(0,.05,9);camera.lookAt(0,.05,0);
const mat=createGarmentMaterial(THREE),garment=createGarment(THREE,mat);scene.add(garment.group);
const hardware=createGarmentMaterial(THREE,{hardware:true});garment.hardwareMesh.material=hardware;
const draft=createDraft(THREE,garment);scene.add(draft.group);
const photo=createPhotoSample(THREE,photoAssets);scene.add(photo.group);
const u=(m,k,v)=>{if(!m.uniforms[k])return;if(m.uniforms[k].value?.isColor)m.uniforms[k].value.set(v);else m.uniforms[k].value=v;};
const viewYaw=-.34;
const clones=[-1,1].map(side=>{const material=createGarmentMaterial(THREE);const g=createGarment(THREE,material);scene.add(g.group);return{side,material,g};});

// One visible carrier is re-shaped from an exploring contour into a measuring
// stroke, a plotting pen and the final image reveal. It is never a particle set.
const carrier=createLightRibbon(THREE);scene.add(carrier.group);
const carrierBase=createLightRibbon(THREE);scene.add(carrierBase.group);
const echoes=Array.from({length:5},()=>{const r=createLightRibbon(THREE);scene.add(r.group);return r;});
let lightClock=0,carrierPoints=[],carrierAlpha=0,carrierHead=1;
const headGlow=new THREE.Mesh(new THREE.PlaneGeometry(.48,.48),new THREE.ShaderMaterial({transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending,
 uniforms:{uOpacity:{value:0}},vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
 fragmentShader:`varying vec2 vUv;uniform float uOpacity;void main(){vec2 q=vUv-.5;float r=length(q);float a=exp(-r*r*60.)*.24+exp(-r*r*950.)*.80;gl_FragColor=vec4(.28,.78,1.,a*uOpacity);}`}));headGlow.renderOrder=73;scene.add(headGlow);
const penCursor=new THREE.Group();scene.add(penCursor);
const cursorRing=new THREE.Mesh(new THREE.RingGeometry(.039,.042,36),new THREE.MeshBasicMaterial({color:'#80e5ff',transparent:true,opacity:.60,depthTest:false,depthWrite:false}));penCursor.add(cursorRing);
const cursorCross=new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-.095,0,0),new THREE.Vector3(-.054,0,0),new THREE.Vector3(.054,0,0),new THREE.Vector3(.095,0,0),new THREE.Vector3(0,-.095,0),new THREE.Vector3(0,-.054,0),new THREE.Vector3(0,.054,0),new THREE.Vector3(0,.095,0)]),new THREE.LineBasicMaterial({color:'#46c3ed',transparent:true,opacity:.38,depthTest:false}));penCursor.add(cursorCross);
function setCarrier(points,width,alpha,head){
 carrierPoints=points;carrierAlpha=alpha;carrierHead=head;
 carrier.update({points,width:width*2,opacity:alpha,head,time:lightClock,flow:.9});
 carrierBase.update({points,width:width*.65,opacity:alpha*.20,head:1,time:lightClock,flow:0});
 headGlow.visible=alpha>.005;headGlow.material.uniforms.uOpacity.value=alpha;
 if(points.length){const distances=[0];for(let i=1;i<points.length;i++)distances[i]=distances[i-1]+points[i].distanceTo(points[i-1]);const target=distances.at(-1)*head;const at=Math.max(1,distances.findIndex(d=>d>=target));const f=(target-distances[at-1])/Math.max(.00001,distances[at]-distances[at-1]);headGlow.position.copy(points[at-1]).lerp(points[at],f).add(new THREE.Vector3(0,0,.01));}
}
const V=(x,y,z=0)=>new THREE.Vector3(x,y,z);
const world=v=>v.clone().applyMatrix4(garment.group.matrixWorld);
const straight=(a,b,n=50)=>Array.from({length:n},(_,i)=>a.clone().lerp(b,i/(n-1)));
function nearestConstruction(anchor,count=300){const paths=garment.sampleConstructionCurves();paths.sort((a,b)=>Math.min(...a.points.map(v=>v.distanceTo(anchor)))-Math.min(...b.points.map(v=>v.distanceTo(anchor))));return new THREE.CatmullRomCurve3(paths[0].points,false,'centripetal').getPoints(count-1).map(world);}
function carrierAt(t,s){
 penCursor.visible=t>=52&&t<72.6&&draft.penActive;
 if(penCursor.visible){penCursor.position.copy(draft.penPosition).applyMatrix4(draft.group.matrixWorld);penCursor.position.z=.7;}
 let pts=[],alpha=1,width=.012,head=(t*.24)%1;
 if(t<17){
  const contour=garment.sampleContour(300),morph=p(t,1.7,7.5),scan=p(t,8,14.5),blend=p(t,7.5,9);
  pts=contour.map((v,i)=>{const a=i/(contour.length-1),theta=a*Math.PI*2;
   const wave=V(lerp(-6,4.7,a),-1.12+Math.sin(a*Math.PI*2-.7)*1.7+.50*Math.sin(a*Math.PI*4),.40*Math.cos(theta));
   const shaped=world(wave.lerp(v,morph));
   const beam=V(lerp(-1.65,1.65,a)+garment.group.position.x,lerp(1.6,-1.5,scan)+garment.group.position.y,.72);
   return shaped.lerp(beam,blend);
  });
  if(t>14.4){const attached=nearestConstruction(garment.anchors.chestLeft,pts.length);pts=pts.map((v,i)=>v.lerp(attached[i],p(t,14.4,17)));}
  alpha=lerp(1,.80,p(t,14.4,17));width=lerp(.035,.011,p(t,2,10));head=t<8?(t*.20)%1:.65;
 }else if(t<42){
  const anchorName=t<21?'chestLeft':t<24?'length':t<27?'sleeve':'detail';
  const change=[[21,'chestLeft','length'],[24,'length','sleeve'],[27,'sleeve','detail']]
   .find(([at])=>t>=at-.30&&t<at+.30);
  if(change){
   // Carry the same 300 samples between the two attached seam paths. Both
   // position and velocity settle at the boundary; the light head never jumps.
   const [at,from,to]=change,blend=p(t,at-.30,at+.30);
   const outgoing=nearestConstruction(garment.anchors[from],300);
   const incoming=nearestConstruction(garment.anchors[to],300);
   pts=outgoing.map((v,i)=>v.lerp(incoming[i],blend));
  }else pts=nearestConstruction(garment.anchors[anchorName],300);
  alpha=.85; width=.008;head=((t-17)*.38)%1;
  if(t>=30){const contour=garment.sampleContour(300).map(world);pts=pts.map((v,i)=>v.lerp(contour[i],p(t,30,31.3)));alpha=lerp(.45,.24,p(t,30,31.3));head=((t-30)*.27)%1;
   if(t>40.5)pts=pts.map((v,i)=>v.lerp(V(lerp(-1.75,1.75,i/299)+garment.group.position.x,1.52+garment.group.position.y,.72),p(t,40.5,42)));
  }
 }else if(t<52){
  const scan=p(t,42.3,48),turn=p(t,49,52),y=lerp(1.52,-1.50,scan);
  const penStart=draft.penPosition.clone().applyMatrix4(draft.group.matrixWorld);
  pts=straight(V(-1.75+garment.group.position.x,y+garment.group.position.y,.72),V(1.75+garment.group.position.x,y+garment.group.position.y,.72)).map((v,i)=>v.lerp(penStart.clone().add(V(-.42*(1-i/49),.10*(1-i/49),.02)),turn));
  width=lerp(.012,.020,turn);head=.96;alpha=lerp(.60,1,p(t,42,42.35));
 }else if(t<75){
  pts=(draft.penTrail||[]).map(v=>v.clone().applyMatrix4(draft.group.matrixWorld));
  if(pts.length<2&&draft.penPosition)pts=[draft.penPosition.clone().add(V(-.03,0,.03)),draft.penPosition.clone()];
  width=.022;alpha=draft.penActive===false?.05:1;head=.96;
 }else if(t<84){
  const contour=garment.sampleContour(240).map(world),fold=p(t,75,78.2),open=p(t,78.1,81.5);
  const pen=draft.penPosition.clone().applyMatrix4(draft.group.matrixWorld);
  pts=contour.map((v,i)=>{const axis=V(0,lerp(1.5,-1.45,i/239),.72);const arriving=pen.clone().add(V(-.18*(1-i/239),0,.1)).lerp(axis,fold);return arriving.lerp(v,open);});
  alpha=w(t,75,75.3,83.3,84);head=(t*.4)%1;width=lerp(.009,.004,open);
 }else{
  const imageProgress=p(t,84,85),y=lerp(1.725,-1.725,imageProgress)*photo.group.scale.y+photo.group.position.y;
  pts=straight(V(-1.6+photo.group.position.x,y,1.2),V(1.6+photo.group.position.x,y,1.2));alpha=w(t,83.95,84.10,84.90,85.15);width=.018;head=.72;
 }
 head=t<7.5?lerp(.56,1,p(t,0,7.5)):1;
 setCarrier(pts,width,alpha,head);
 const echoAlpha=w(t,-1,0,6.5,9);
 echoes.forEach((r,i)=>r.update({points:pts.map((q,j)=>q.clone().add(V(0,(i+1)*.028*Math.sin(j/(pts.length-1)*Math.PI),-.03*(i+1)))),width:width*(.9-i*.11),opacity:echoAlpha*(.30-i*.035),head:head-.014*i,time:lightClock-i*.45,flow:1}));
}

const overlay=$('#annotations');
function label(text,cls='callout'){const el=document.createElement('div');el.className=cls;el.textContent=text;overlay.append(el);return el;}
const requests=[['핏','여유 있게',17.5,20.8,'chestLeft',[-1.70,.35,.55]],['기장','조금 더 짧게',21,23.8,'length',[-1.5,-1.12,.55]],['소매','손목에 맞게',24,26.5,'sleeve',[1.65,-.55,.55]],['디테일','포켓의 깊이',27,29.5,'detail',[-1.65,.84,.55]]].map(q=>({q,el:label(q[0]+'  /  '+q[1]),line:new THREE.Line(new THREE.BufferGeometry().setFromPoints([V(0,0),V(0,0)]),new THREE.LineBasicMaterial({color:'#5dc7f1',transparent:true,opacity:0}))}));
requests.forEach(o=>scene.add(o.line));
const dimensionDefs=[['어깨 48 cm','shoulderLeft','shoulderRight',1.47],['가슴둘레 114 cm','chestLeft','chestRight',.20],['총장 78 cm','collar','length',-1.75],['소매 60 cm','shoulderRight','sleeve',1.65]];
const dims=dimensionDefs.map(q=>({q,el:label(q[0]),line:new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(Array.from({length:6},()=>V(0,0))),new THREE.LineBasicMaterial({color:'#68c5ec',transparent:true,opacity:0}))}));dims.forEach(o=>scene.add(o.line));
const cadLabels=[];const refNote=label('기본 셔츠 100호 참고 치수 · 제작용 패턴은 전문가 검토 후 확정','measurement-note');
const colorNote=label('WASHED COTTON  /  EARTH BROWN','material-note');
function toScreen(v){const q=v.clone().project(camera);return[(q.x*.5+.5)*canvas.clientWidth,(-q.y*.5+.5)*canvas.clientHeight];}
function put(el,v,a,align='center'){const xy=toScreen(v);if(canvas.clientWidth<680&&el.className==='callout'){xy[0]=clamp(xy[0],68,canvas.clientWidth-68);align='center';}el.style.left=xy[0]+'px';el.style.top=xy[1]+'px';el.style.opacity=clamp(a);el.style.visibility=a>.015?'visible':'hidden';el.style.transform=`translate(${align==='left'?'0':align==='right'?'-100%':'-50%'},-50%)`;}
function annotate(t,s){
 for(const {q,el,line} of requests){const a=w(t,q[2],q[2]+.4,q[3]-.4,q[3]);const endpoint=world(V(...q[5]));const source=world(garment.anchors[q[4]]);line.geometry.setFromPoints([source,endpoint]);line.material.opacity=a*.72;put(el,endpoint,a,q[5][0]<0?'right':'left');}
 const scanY=lerp(1.52,-1.5,p(t,42.3,48));
 dims.forEach(({q,el,line},i)=>{const a=s.measure*p(scanY,[1.15,.16,-1.35,-.9][i]+.05,[1.15,.16,-1.35,-.9][i]-.05);let from=garment.anchors[q[1]].clone(),to=garment.anchors[q[2]].clone();
  if(i<2){from.y=to.y=q[3];from.z=to.z=.5;}else{from.x=to.x=q[3];from.z=to.z=.5;}
  const tick=i<2?V(0,.035):V(.035,0);const pts=[from,to,from.clone().sub(tick),from.clone().add(tick),to.clone().sub(tick),to.clone().add(tick)].map(world);line.geometry.setFromPoints(pts);line.material.opacity=a*.75;
  const centre=from.clone().lerp(to,.5);if(i<2)centre.y+=.12;else centre.x+=i===2?-.11:.11;put(el,world(centre),a,i<2?'center':i===2?'right':'left');
 });
 if(draft.labels){draft.labels.forEach((d,i)=>{if(!cadLabels[i])cadLabels[i]=label(d.text,'cad-label');const v=d.position.clone().applyMatrix4(draft.group.matrixWorld);const a=d.role==='reference'?0:(d.opacity??1)*s.draft*(1-clamp(s.projection));put(cadLabels[i],v,a);if(d.rotation)cadLabels[i].style.transform+=` rotate(${-d.rotation}rad)`;});}
 refNote.style.opacity=Math.max(s.measure,s.draft)*(1-p(t,78,81));refNote.style.visibility=t>42&&t<81?'visible':'hidden';
 colorNote.textContent=t<90?'WASHED COTTON  /  EARTH BROWN':t<94?'WASHED COTTON  /  CHARCOAL':'SOFT UTILITY  /  KHAKI';
 colorNote.style.opacity=w(t,87.4,88,98,100);colorNote.style.visibility=t>87?'visible':'hidden';
}
function setDigital(m,alpha=1){u(m,'uReveal',1);u(m,'uStateAlpha',alpha);u(m,'uMaterialMix',0);u(m,'uImageReveal',0);u(m,'uCad',0);u(m,'uSurfaceVisibility',1);}
function renderAt(time){const s=stateAt(time),t=s.t,aspect=canvas.clientWidth/canvas.clientHeight;
 const mobile=canvas.clientWidth<=900;
 const cadEnvelope=w(t,48.5,52,76,83),expand=Math.max(s.layout,cadEnvelope),baseHalf=mobile?Math.max(3.15,1.78/aspect):2.28;
 const drawProgress=drawingAt(t),cadPull=p(drawProgress,.045,.22);
 const half=lerp(baseHalf,Math.max(mobile?3.8:2.6,(mobile?3.60:3.55)/aspect),Math.max(s.layout,cadEnvelope*cadPull));
 const targetX=lerp(0,-2.45*(1-cadPull),cadEnvelope);
 const targetY=lerp(.05,mobile?.95:.58,cadEnvelope);
 camera.position.set(targetX,targetY,9);camera.lookAt(targetX,targetY,0);
 camera.left=-half*aspect;camera.right=half*aspect;camera.top=half;camera.bottom=-half;camera.updateProjectionMatrix();
 garment.update({fit:s.fit,length:s.length,sleeve:s.sleeve,detail:s.detail,flat:0,materialDrape:0});
 const subjectX=(mobile?0:1.38)*(1-p(t,29,32))+(mobile?0:1.38)*p(t,39,42)*(1-p(t,48.5,52))+(mobile?0:1.38)*p(t,80,84);
 const subjectY=mobile?-.72:lerp(.05,-.35,s.layout);
 garment.group.rotation.y=lerp(viewYaw-.12*p(t,10,17),0,p(t,81,84));garment.group.position.set(subjectX,subjectY,0);garment.group.scale.setScalar(lerp(1,.86,s.layout));garment.group.updateMatrixWorld(true);
 const imageProgress=p(t,84.35,84.90);u(mat,'uReveal',s.reveal);u(mat,'uStateAlpha',t<7?.0:1);u(mat,'uCad',0);u(mat,'uSurfaceVisibility',s.surface*(1-p(t,84,84.32)));u(mat,'uMaterialMix',0);u(mat,'uImageReveal',0);u(mat,'uWireColor','#80ddff');u(mat,'uTime',lightClock);
 garment.group.visible=t>7&&t<84.33&&s.surface>.03;
 for(const [name,uniform]of Object.entries(mat.uniforms))if(name!=='uHardware'&&hardware.uniforms[name])hardware.uniforms[name].value=uniform.value;
 clones.forEach(({side,material,g},i)=>{const spread=p(t,30+i*.30,32.3+i*.3),merge=p(t,35.3+i*.4,40.3+i*.4);const alpha=spread*(1-p(t,39.6+i*.35,41.3+i*.35))*.26;g.group.visible=alpha>.002;
  g.update({fit:lerp(side*.38,s.fit,merge),length:lerp(side*.26,s.length,merge),sleeve:lerp(side*.1,s.sleeve,merge),detail:s.detail});setDigital(material,alpha);
  const acceleration=merge*merge;g.group.position.set(cubic(side*2.45*spread,side*2.90,side*.60,subjectX,acceleration),cubic(subjectY,subjectY+.6,subjectY+.44,subjectY,acceleration),lerp(-.16,0,merge));g.group.scale.setScalar(lerp(.76,1,merge));g.group.rotation.y=lerp(side*.20,viewYaw,merge);u(material,'uTime',lightClock);
 });
 draft.group.position.set(0,-.10,0);draft.group.rotation.y=Math.PI*.5*p(t,75,78.2);
 draft.update({revealX:100,drawingProgress:drawProgress,projection:0,opacity:s.draft,detailProgress:1,fit:s.fit,length:s.length,sleeve:s.sleeve});draft.group.updateMatrixWorld(true);
 photo.update({progress:1,colorProgress:p(t,90,93)*.5+p(t,94,96)*.5,opacity:imageProgress});photo.group.visible=t>=84.35;photo.group.position.set(mobile?0:1.45,mobile?-.78:.05,0);photo.group.scale.setScalar(mobile?1:1.12);
 carrierAt(t,s);annotate(t,s);
 const beat=beats[s.index];$('#eyebrow').textContent=beat[2];$('#caption').textContent=t>100?'Kustom your week.':beat[3];$('#description').textContent=t>100?'고객의 생각에서, 함께 검토할 하나의 샘플까지.':beat[4];$('#phase').textContent=String(s.index+1).padStart(2,'0')+' / 08';$('#progress').style.transform=`scaleX(${t/DURATION})`;
 const enter=s.index===0?1:p(t,beat[0],beat[0]+.9),leave=s.index===7?1:1-p(t,beat[1]-.85,beat[1]);
 $('.narration').style.setProperty('--copy-opacity',Math.min(enter,leave));$('.narration').style.setProperty('--copy-shift',`${(1-enter)*20-(1-leave)*14}px`);
 $('.draft-ground').style.opacity=cadEnvelope*.75;
 $('#draft-operation').style.opacity=w(t,51,52,74.5,75);
 $('#draft-part').textContent=draft.activePath?.toUpperCase().replaceAll('-',' ')||'PATTERN ENGINEERING';
 const palette=$('#material-palette');palette.style.opacity=w(t,87,88,99,100);palette.dataset.color=t<91.5?'brown':t<95?'charcoal':'khaki';$('#material-caption').textContent=t<91.5?'EARTH BROWN':t<95?'CHARCOAL':'UTILITY KHAKI';
 $('#viewport').dataset.scene=beat[2].toLowerCase();$('#cad-steps').style.opacity=t>=52&&t<75?1:0;$('#cad-steps').dataset.step=drawProgress<.343685?'outline':drawProgress<.611176?'seam':drawProgress<.802315?'allowance':'dimension';
 canvas.dataset.time=t.toFixed(3);canvas.dataset.phase=beat[2];canvas.dataset.photo=imageProgress.toFixed(3);renderer.render(scene,camera);
}
function resize(){const v=$('#viewport');renderer.setSize(v.clientWidth,v.clientHeight,false);}
function scrollTime(){const story=$('#story');return clamp(-story.getBoundingClientRect().top/Math.max(1,story.offsetHeight-innerHeight))*DURATION;}
let last=-1,raf=0,start=performance.now(),lastNow=start,smoothed=fixed??scrollTime();
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function tick(now){const dt=Math.min(.06,(now-lastNow)/1000);lastNow=now;lightClock=reduced?0:now/1000;
 const target=fixed??(autoplay?clamp((now-start)/1000,0,DURATION):scrollTime());
 smoothed=fixed!==null||reduced?target:lerp(smoothed,target,1-Math.exp(-dt*10));if(Math.abs(smoothed-target)<.0005)smoothed=target;
 const t=smoothed;u(mat,'uTime',lightClock);u(hardware,'uTime',lightClock);clones.forEach(c=>u(c.material,'uTime',lightClock));carrier.update({time:lightClock});carrierBase.update({time:lightClock});echoes.forEach((r,i)=>r.update({time:lightClock-i*.45}));
 if(Math.abs(t-last)>.0001){renderAt(t);last=t;}else if(carrier.group.visible||garment.group.visible)renderer.render(scene,camera);if(!document.hidden)raf=requestAnimationFrame(tick);}
function schedule(){cancelAnimationFrame(raf);raf=requestAnimationFrame(tick)}
addEventListener('scroll',()=>{if(fixed!==null&&fixed!==undefined)return;autoplay=false;schedule()},{passive:true});
addEventListener('resize',()=>{resize();last=-1;schedule()});
document.addEventListener('visibilitychange',()=>{if(!document.hidden){lastNow=performance.now();schedule();}});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();status.textContent='그래픽 연결이 끊겼습니다. 페이지를 새로고침해주세요.';});
resize();
Promise.resolve(photo.ready).then(()=>{renderAt(fixed??0);status.textContent='';document.body.dataset.ready='true';start=performance.now();schedule();}).catch(e=>{status.textContent='샘플 이미지를 불러오지 못했습니다.';console.error(e);});
