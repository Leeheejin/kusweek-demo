/**
 * Continuous, texture-free garment shading. Geometry and UVs are shared by
 * the wireframe, the flat CAD state and the woven fabric reveal.
 * uReveal / uScan: 0 = no reveal; 1 = reached the bottom. Both travel top to bottom.
 * uMaterialMix is the material activation envelope (0 off, >= .08 fully active).
 * CAD is supplied by separate, precise drafting line geometry. uCad now fades
 * this garment surface (0 visible, 1 hidden), never makes a fake flat UV draft.
 * uSurfaceVisibility is an additional whole-surface visibility multiplier.
 * uMaterialKind: 0 cotton / 1 linen; intermediate values are continuous.
 * uRoughness and uFabricWeight affect reflection and fiber structure only.
 */
export function createGarmentMaterial(THREE, opts = {}) {
  const material = new THREE.ShaderMaterial({
    name: 'KUSWEEK continuous wire-to-cotton surface',
    uniforms: {
      uTime: { value: 0 },
      uScan: { value: 0 },
      uMaterialMix: { value: 0 },
      uColor: { value: new THREE.Color(opts.color ?? '#87715a') },
      uWireColor: { value: new THREE.Color(opts.wireColor ?? '#a2d8ec') },
      uStateAlpha: { value: 1 },
      uWireStrength: { value: 1 },
      uReveal: { value: 1 },
      uCad: { value: 0 },
      uStrokeX: { value: 100 },
      // UVs are in physical model units; the grid therefore stays equally dense.
      uGrid: { value: opts.grid ?? 25 },
      uTop: { value: opts.top ?? 1.7 },
      uBottom: { value: opts.bottom ?? -1.65 },
      uHardware: { value: opts.hardware ? 1 : 0 },
      uSurfaceVisibility: { value: opts.surfaceVisibility ?? 1 },
      uMaterialKind: { value: opts.materialKind ?? 0 },
      uRoughness: { value: opts.roughness ?? .88 },
      uFabricWeight: { value: opts.fabricWeight ?? .7 },
      uImageReveal: { value: 0 },
      uImageTop: { value: 1.725 },
      uImageBottom: { value: -1.725 },
    },
    vertexShader: /* glsl */`
      attribute float aInterior;
      varying vec2 vUv;
      varying vec3 vLocalPosition;
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      varying float vInterior;
      varying float vWorldY;
      void main() {
        vInterior = aInterior;
        vWorldY = (modelMatrix*vec4(position,1.0)).y;
        vUv = uv;
        vLocalPosition = position;
        vec4 viewPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -viewPosition.xyz;
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * viewPosition;
      }
    `,
    fragmentShader: /* glsl */`
      precision highp float;
      uniform float uTime;
      uniform float uScan;
      uniform float uMaterialMix;
      uniform vec3 uColor;
      uniform vec3 uWireColor;
      uniform float uStateAlpha;
      uniform float uWireStrength;
      uniform float uReveal;
      uniform float uCad;
      uniform float uStrokeX;
      uniform float uGrid;
      uniform float uTop;
      uniform float uBottom;
      uniform float uHardware;
      uniform float uSurfaceVisibility;
      uniform float uMaterialKind;
      uniform float uRoughness;
      uniform float uFabricWeight;
      uniform float uImageReveal;
      uniform float uImageTop;
      uniform float uImageBottom;
      varying vec2 vUv;
      varying vec3 vLocalPosition;
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      varying float vInterior;
      varying float vWorldY;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p);
        f = f*f*(3.0-2.0*f);
        return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x),
                   mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0)),f.x),f.y);
      }
      float quadGrid(vec2 uv, float density, float halfWidth) {
        vec2 q = uv * density;
        vec2 aa = max(fwidth(q), vec2(0.00001));
        vec2 d = abs(fract(q - 0.5) - 0.5) / aa;
        return 1.0 - smoothstep(halfWidth, halfWidth + 0.64, min(d.x, d.y));
      }
      vec3 wovenNormal(vec3 normal, float height) {
        // Surface-gradient bump mapping is valid without tangent attributes.
        // Both partial derivatives are taken on the same continuously deformed
        // geometry, so the cotton never slips when its silhouette changes.
        vec3 dx = dFdx(-vViewPosition);
        vec3 dy = dFdy(-vViewPosition);
        vec3 r1 = cross(dy,normal), r2 = cross(normal,dx);
        float determinant = dot(dx,r1);
        vec3 gradient = sign(determinant) *
          (dFdx(height)*r1+dFdy(height)*r2);
        return normalize(max(abs(determinant),0.000000001)*normal-gradient);
      }
      void main() {
        float height = clamp((uTop-vLocalPosition.y)/(uTop-uBottom),0.0,1.0);
        float heightAA = max(fwidth(height)*1.2,0.002);
        float reveal = 1.0 - smoothstep(uReveal-heightAA,uReveal+heightAA,height);
        if (uReveal >= 0.9999) reveal = 1.0;
        if (uReveal <= 0.00001 || reveal*uStateAlpha*uSurfaceVisibility < 0.003) discard;

        float cad = clamp(uCad,0.0,1.0);

        vec3 N = normalize(vNormal) * (gl_FrontFacing ? 1.0 : -1.0);
        vec3 V = normalize(vViewPosition);
        vec3 L = normalize(vec3(-0.92,0.78,0.62));
        vec3 R = normalize(vec3(0.75,0.30,-0.48));
        float keyLight = max(dot(N,L),0.0);
        float rimLight = max(dot(N,R),0.0);
        float facing = max(dot(N,V),0.0);
        float fresnel = pow(1.0-facing,3.6);

        float grid = quadGrid(vUv,uGrid,0.09);
        float major = quadGrid(vUv,uGrid/5.0,0.23);
        float wire = max(grid*0.18,major*0.47);
        // Opaque shaded navy body makes the silhouette readable, without seeing
        // an incoherent stack of backfaces through the front of the garment.
        vec3 digitalBody = vec3(0.007,0.016,0.027)*(0.24+keyLight*1.55);
        digitalBody += vec3(.004,.011,.019)*rimLight;
        // The edge response belongs to the curved surface, not a bloom halo.
        // A bright primary structure and quiet fine subdivisions leave depth
        // and construction readable instead of producing a uniform teal cage.
        float contour = fresnel*(.026+.10*rimLight+.035*keyLight);
        float interior = clamp(vInterior,0.0,1.0);
        vec3 digital = digitalBody + uWireColor*(wire*(.36+.35*keyLight)*clamp(uWireStrength,0.0,1.0)+contour);
        // A coherent current travels down the existing quad topology. It never
        // draws an extra horizontal scanline or introduces random particles.
        // Start and finish outside the body so the six-second loop cannot jump.
        float energyFront=fract(uTime/6.0)*1.36-0.18;
        float energyDistance=height-energyFront;
        float energyWake=exp(-pow((energyDistance+.035)/.12,2.0));
        float energyLead=exp(-pow(energyDistance/.015,2.0));
        float energyEnvelope=smoothstep(-.16,0.0,energyFront)
          *(1.0-smoothstep(1.0,1.16,energyFront));
        float energy=(energyWake*.085+energyLead*.28)*energyEnvelope;
        digital+=vec3(.40,.79,.96)*wire*energy*clamp(uWireStrength,0.0,1.0);
        digital *= mix(1.0,.16,interior);

        float scanWidth = max(heightAA,0.004);
        float scanMask = 1.0-smoothstep(uScan-scanWidth,uScan+scanWidth,height);
        if (uScan <= 0.00001) scanMask=0.0;
        if (uScan >= 0.9999) scanMask=1.0;
        float fabric = scanMask*smoothstep(0.0,0.08,uMaterialMix)*(1.0-cad);

        // Procedural woven cotton: alternating thread crossings and restrained
        // irregular yarn widths. Derivative attenuation prevents distant moire.
        float linen = clamp(uMaterialKind,0.0,1.0);
        float weight = clamp(uFabricWeight,0.0,1.0);
        float roughness = clamp(uRoughness,.35,.98);
        float yarnDensity = mix(168.0,112.0,linen)*mix(1.14,.91,weight);
        // Linen fibers are irregular along their length; cotton remains a
        // tighter, more even plain weave. Both stay anchored in garment UVs.
        vec2 irregularity = vec2(noise(vec2(vUv.y*11.0,4.0)),noise(vec2(vUv.x*13.0,9.0)))-.5;
        vec2 yarn = vUv*yarnDensity+irregularity*linen*.34;
        vec2 yarnCell = floor(yarn);
        float parity = mod(yarnCell.x+yarnCell.y,2.0);
        vec2 f = fract(yarn);
        float threadWidth = mix(3.8,3.15,linen);
        float warp = exp(-pow((f.x-0.5)*threadWidth,2.0));
        float weft = exp(-pow((f.y-0.5)*threadWidth,2.0));
        float weave = mix(warp,weft,parity)-0.64;
        float weaveAA = 1.0-smoothstep(0.48,1.65,max(fwidth(yarn.x),fwidth(yarn.y)));
        weave *= weaveAA;
        float yarnVariation = noise(vUv*76.0)-0.5;
        float wash = noise(vUv*5.0)-0.5;
        float slub = (noise(vUv*vec2(58.0,7.0))-.5)*linen;
        float fiberHeight = weave*mix(.00048,.00085,linen)*mix(.8,1.25,weight)
          + yarnVariation*.000075 + slub*.00013;
        vec3 clothN = wovenNormal(N,fiberHeight*(1.0-uHardware));
        vec3 clothKey = normalize(vec3(-.92,.78,.62));
        vec3 clothFill = normalize(vec3(.89,-.10,.36));
        vec3 clothBack = normalize(vec3(.65,.58,-.55));
        float clothDiffuse = max(dot(clothN,clothKey),0.0);
        float clothFillLight = max(dot(clothN,clothFill),0.0);
        float clothBackLight = max(dot(clothN,clothBack),0.0);
        // Large cool studio key, low fill and directional rim. This preserves
        // deep folds and sleeve curvature while keeping actual fabric color.
        // No emissive or cyan contribution is present on the completed textile.
        vec3 light = vec3(.086,.099,.119)
          + vec3(.91,.965,1.0)*clothDiffuse*1.30
          + vec3(.70,.80,.91)*clothFillLight*.105
          + vec3(.76,.85,.94)*clothBackLight*.14;
        vec3 baseColor = mix(uColor,vec3(.048,.038,.029),uHardware);
        vec3 cloth = baseColor*light;
        cloth *= 1.0+(weave*.17+yarnVariation*.037+wash*.044+slub*.047)*(1.0-uHardware);
        vec3 H = normalize(clothKey+V);
        float exponent = mix(mix(38.0,8.0,roughness),46.0,uHardware);
        float reflectionStrength = mix(mix(.024,.009,roughness),.095,uHardware);
        float softSpecular = pow(max(dot(clothN,H),0.0),exponent)
          *reflectionStrength*clothDiffuse;
        float clothFacing = max(dot(clothN,V),0.0);
        float cottonSheen = pow(1.0-clothFacing,4.0)*(.007+clothDiffuse*.019);
        cottonSheen *= mix(1.0,.70,linen)*mix(.78,1.12,weight);
        cottonSheen *= 1.0-uHardware;
        cloth += vec3(.89,.93,.98)*(softSpecular+cottonSheen);
        // Authored inside surfaces are truly inside the neck and cuffs. Their
        // darker light level supplies cavity depth without screen-space tricks.
        cloth *= mix(1.0,.24,interior);

        vec3 color = mix(digital,cloth,fabric);
        // Grid retreats at the scan boundary rather than fading the whole object.
        color += uWireColor*wire*clamp(uWireStrength,0.0,1.0)*fabric*(1.0-fabric)*0.025;
        float frontier = exp(-pow((height-uScan)/0.0045,2.0));
        frontier *= step(0.001,uScan)*(1.0-step(0.999,uScan));
        color += uWireColor*frontier*0.10*(1.0-cad);

        // Genuine CAD contours/dimensions are separate geometry. This surface
        // simply yields to that plane, with no projected back/front UV collage.
        float alpha = (1.0-cad)*reveal*clamp(uStateAlpha,0.0,1.0)
          *clamp(uSurfaceVisibility,0.0,1.0);
        // Exact world-space complement of the photographed sample's frontier.
        // A translated or scaled garment still meets the same horizontal scan.
        float imageHeight=clamp((uImageTop-vWorldY)/(uImageTop-uImageBottom),0.0,1.0);
        float imageFeather=max(fwidth(imageHeight)*1.2,0.002);
        float imageReveal=1.0-smoothstep(uImageReveal-imageFeather,uImageReveal+imageFeather,imageHeight);
        if(uImageReveal<=0.00001) imageReveal=0.0;
        if(uImageReveal>=0.9999) imageReveal=1.0;
        alpha*=1.0-imageReveal;
        if(alpha < 0.004) discard;
        gl_FragColor = vec4(color,alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: true,
    depthTest: true,
    toneMapped: true,
  });
  return material;
}
