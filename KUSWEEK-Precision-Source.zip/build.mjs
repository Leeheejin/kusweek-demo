import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
let esbuild;
try { esbuild=await import('esbuild'); }
catch { esbuild=await import('../qa/node_modules/esbuild/lib/main.js'); }
const {build}=esbuild;

const root=fileURLToPath(new URL('./',import.meta.url));
const args=process.argv.slice(2);
const flag=args.indexOf('--out');
if(flag>=0&&!args[flag+1])throw new Error('Pass an HTML destination after --out.');
// The default is a local QA artifact. Publishing and final-output promotion are separate actions.
const destination=flag>=0?path.resolve(args[flag+1]):path.join(root,'qa','review.html');
const photos={};
for(const name of ['hero','charcoal','khaki'])photos[name]='data:image/webp;base64,'+(await fs.readFile(path.join(root,'assets',name+'.webp'))).toString('base64');
await fs.writeFile(path.join(root,'assets.js'),'export const photoAssets='+JSON.stringify(photos)+';');
const [template,sourceCSS,font,license]=await Promise.all([
 fs.readFile(path.join(root,'index.html'),'utf8'),
 fs.readFile(path.join(root,'style.css'),'utf8'),
 fs.readFile(path.join(root,'PretendardVariable.woff2')),
 fs.readFile(path.join(root,'THREE-LICENSE.txt'),'utf8')
]);
const bundled=await build({entryPoints:[path.join(root,'app.js')],bundle:true,write:false,format:'iife',platform:'browser',target:['es2022'],minify:true,legalComments:'inline',charset:'utf8',logLevel:'silent'});
if(bundled.outputFiles.length!==1)throw new Error('Expected a single bundled script.');
const script=bundled.outputFiles[0].text;
if(/<\/script/i.test(script))throw new Error('Unexpected HTML closing script sequence in bundle.');
if(!template.includes('<!-- INLINE_STYLE -->')||!template.includes('<!-- APP_SCRIPT -->'))throw new Error('HTML build slots are missing.');
if(!sourceCSS.includes('__FONT_DATA_URL__'))throw new Error('CSS font build slot is missing.');
const css=sourceCSS.replace('__FONT_DATA_URL__',()=>`data:font/woff2;base64,${font.toString('base64')}`);
const safeLicense=license.replaceAll('--','—');
const html=template
 .replace('<!-- INLINE_STYLE -->',()=>`<style>${css}</style>`)
 .replace('<!-- APP_SCRIPT -->',()=>`<!-- THREE.js license\n${safeLicense}\n--><script>${script}</script>`);
for(const id of ['story','viewport','stage','caption','eyebrow','phase','progress','status','annotations']){
 if(!html.includes(`id="${id}"`))throw new Error(`Required runtime slot is missing: ${id}`);
}
if(/<(?:button|input|select|dialog|img|video|iframe)\b/i.test(template))throw new Error('Review shell must remain scroll-only and asset-free.');
await fs.mkdir(path.dirname(destination),{recursive:true});
await fs.writeFile(destination,html,'utf8');
console.log(`Built ${destination} (${(Buffer.byteLength(html)/1024/1024).toFixed(2)} MiB). Embedded Three.js, procedural scene, and local font; no remote dependencies.`);
