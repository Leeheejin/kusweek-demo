/* Illustrative apparel draft. The linework is authored for this motion study;
 * the dimensions cite the supplied regular-shirt 100 chart, not a validated
 * shacket cutting pattern. No image, planar UV grid, or filled panel is used.
 */
export function createDraft(THREE, garment) {
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const ease=x=>{x=clamp(x);return x*x*(3-2*x);};
  const quintic=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
  const TAU=Math.PI*2;
  const SCAN_LEFT=-3.27,SCAN_RIGHT=3.17;
  const scanXFor=progress=>lerp(SCAN_LEFT,SCAN_RIGHT,clamp(progress));
  const group=new THREE.Group();
  group.name='Apparel CAD — progressively authored construction lines';
  const labels=[],paths=[],stages={cut:[],sew:[],allowance:[],construction:[],dimension:[],notch:[]};
  const projected=new THREE.Vector3(),temp=new THREE.Vector3();
  const penPosition=new THREE.Vector3(),penTangent=new THREE.Vector3(1,0,0);
  const penTrail=Array.from({length:20},()=>new THREE.Vector3());
  let penActive=false,penDrawing=false,penOpacity=0,activePath=null,lastKey='',scanX=SCAN_LEFT;

  // Surface correspondence is sampled from the SAME authored garment mesh.
  // A small spatial index keeps the initial correspondence calculation cheap.
  const base=[];
  for(const mesh of [garment?.mainMesh,garment?.detailMesh]){
    if(!mesh)continue;
    const array=mesh.userData?.basePositions||mesh.geometry.getAttribute('position').array;
    for(let i=0;i<array.length;i+=6)base.push([array[i],array[i+1],array[i+2]]);
  }
  const makePool=filter=>{
    const points=base.filter(filter),cells=new Map(),cell=.085;
    for(const q of points){const key=q.map(v=>Math.floor(v/cell)).join(',');if(!cells.has(key))cells.set(key,[]);cells.get(key).push(q);}
    return {points,cells,cell};
  };
  const pools={
    front:makePool(q=>Math.abs(q[0])<.845&&q[2]>=-.002&&q[1]<1.40),
    back:makePool(q=>Math.abs(q[0])<.845&&q[2]<=.002&&q[1]<1.40),
    sleeve:makePool(q=>q[0]>.765&&q[1]<1.16),
    collar:makePool(q=>Math.abs(q[0])<.57&&q[1]>1.07),
    cuff:makePool(q=>q[0]>.97&&q[1]<-.91),
    pocket:makePool(q=>q[0]>.22&&q[0]<.59&&q[1]>.26&&q[1]<.89&&q[2]>.13)
  };
  function surface(pool,q){
    if(!pool.points.length)return q;
    const c=q.map(v=>Math.floor(v/pool.cell));let candidates=[];
    for(let radius=1;radius<=3&&!candidates.length;radius++){
      for(let x=-radius;x<=radius;x++)for(let y=-radius;y<=radius;y++)for(let z=-radius;z<=radius;z++){
        const bucket=pool.cells.get(`${c[0]+x},${c[1]+y},${c[2]+z}`);if(bucket)candidates.push(...bucket);
      }
    }
    if(!candidates.length)candidates=pool.points;
    const nearest=[];
    for(const v of candidates){const d=(v[0]-q[0])**2+(v[1]-q[1])**2+(v[2]-q[2])**2;if(nearest.length<4||d<nearest.at(-1).d){nearest.push({v,d});nearest.sort((a,b)=>a.d-b.d);if(nearest.length>4)nearest.pop();}}
    const out=[0,0,0];let total=0;
    for(const {v,d}of nearest){const weight=1/(d+.00003);total+=weight;for(let k=0;k<3;k++)out[k]+=v[k]*weight;}
    return out.map((v,k)=>v/total+(k===2?.006:0));
  }
  function shirtMap(local,back=false){
    const x=back?clamp(local[0]/.72,-1,1)*.815:clamp((local[0]+.32)/.73)*.815;
    const y=lerp(-1.448,1.37,clamp((local[1]+1.27)/2.56));
    let z=.265*Math.sqrt(Math.max(0,1-(x/.835)**2));
    if(y>.95)z*=lerp(1,.45,clamp((y-.95)/.42));
    return surface(back?pools.back:pools.front,[x,y,z*(back?-1:1)]);
  }
  function sleeveMap(q){
    let t=clamp((1.23-q[1])/2.47),half=.56-.30*t;
    for(let i=0;i<2;i++){
      const u=clamp(q[0]/half,-1,1),top=.45+.78*Math.sqrt(Math.max(0,1-u*u));
      t=clamp((top-q[1])/(top+1.24));half=.56-.30*t;
    }
    const a=(clamp(q[0]/half,-1,1)+1)*Math.PI+Math.PI;
    const orient=ease(t/.35)*1.35,cx=.815+.55*(1-Math.exp(-4*t))-.18*t,cy=.77-1.9*t;
    const r=lerp(.35,.151,Math.pow(t,.65)),depth=lerp(.245,.13,t);
    return surface(pools.sleeve,[cx+Math.sin(orient)*Math.cos(a)*r,cy+Math.cos(orient)*Math.cos(a)*r,Math.sin(a)*depth]);
  }
  function collarMap(q,stand=false){
    const u=clamp((q[0]+.73)/1.46),a=lerp(.09,TAU-.09,u),v=clamp((q[1]+.16)/.43);
    const n=[.255*Math.sin(a),1.36-.22*Math.max(Math.cos(a),0)-.02*Math.max(-Math.cos(a),0),.23*Math.cos(a)];
    const point=Math.pow(clamp(1-(Math.min(a,TAU-a)-.09)/.70),1.5);
    const target=stand?[n[0]*(1+v*.04),n[1]+v*.14,n[2]*(1+v*.04)]:[
      n[0]*(1-v)+(.36*Math.sin(a)+Math.sign(Math.sin(a))*.19*point)*v,
      n[1]+.135-v*(.10+.19*point),n[2]+.09*Math.cos(a)*v+.022*point*v];
    return surface(pools.collar,target);
  }
  function cuffMap(q){
    const a=clamp((q[0]+.62)/1.24)*TAU,t=lerp(.927,1.017,clamp((q[1]+.20)/.40));
    const cx=.815+.55*(1-Math.exp(-4*t))-.18*t,cy=.77-1.9*t,r=.155;
    return surface(pools.cuff,[cx+Math.sin(1.35)*Math.cos(a)*r,cy+Math.cos(1.35)*Math.cos(a)*r,.135*Math.sin(a)]);
  }
  function pocketMap(q){return surface(pools.pocket,[.397+q[0]*.68,.568+q[1]*.86,.284]);}

  // Draft coordinates are deliberately spacious and detached from the garment
  // UV layout: these are readable curves and construction marks on one sheet.
  function shape(commands){
    const s=new THREE.Shape();
    for(const [op,...q]of commands){
      if(op==='M')s.moveTo(...q);else if(op==='L')s.lineTo(...q);
      else if(op==='C')s.bezierCurveTo(...q);else if(op==='Q')s.quadraticCurveTo(...q);else if(op==='Z')s.closePath();
    }
    return s.getPoints(24).map(v=>[v.x,v.y]);
  }
  function resample(points,step=.014){
    const out=[points[0]];
    for(let j=1;j<points.length;j++){
      const a=points[j-1],b=points[j],n=Math.max(1,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/step));
      for(let k=1;k<=n;k++)out.push([lerp(a[0],b[0],k/n),lerp(a[1],b[1],k/n)]);
    }
    return out;
  }
  function offset(points,d){
    const p=points.slice(0,-1);let area=0;
    for(let i=0;i<p.length;i++){const n=p[(i+1)%p.length];area+=p[i][0]*n[1]-n[0]*p[i][1];}
    const sign=area>0?1:-1;
    const out=p.map((v,i)=>{
      const a=p[(i+p.length-1)%p.length],b=p[(i+1)%p.length],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1;
      return[v[0]+sign*d*dy/l,v[1]-sign*d*dx/l];
    });out.push(out[0]);return out;
  }
  const pieces=[
    {id:'front',name:'01 / 앞판',centre:[-2.61,0],map:q=>shirtMap(q),label:[-2.61,-1.48],outline:shape([
      ['M',-.32,1.005],['C',-.13,1.012,-.105,1.115,-.065,1.286],
      ['L',.354,1.078],['C',.290,.945,.260,.733,.336,.542],['C',.353,.496,.384,.451,.410,.411],
      ['C',.386,-.031,.371,-.681,.402,-1.111],['Q',.424,-1.239,.223,-1.248],
      ['C',.024,-1.290,-.145,-1.285,-.32,-1.251],['Z']])},
    {id:'back',name:'02 / 뒤판',centre:[-1.31,0],map:q=>shirtMap(q,true),label:[-1.31,-1.48],outline:shape([
      ['M',-.72,-1.147],['C',-.720,-.527,-.680,.080,-.714,.414],
      ['C',-.611,.539,-.497,.779,-.675,1.087],['L',-.226,1.286],
      ['C',-.118,1.180,.118,1.180,.226,1.286],['L',.675,1.087],
      ['C',.497,.779,.611,.539,.714,.414],['C',.680,.080,.720,-.527,.72,-1.147],
      ['C',.425,-1.297,-.425,-1.297,-.72,-1.147],['Z']])},
    {id:'sleeve',name:'03 / 소매',centre:[.59,0],map:sleeveMap,label:[.59,-1.48],outline:shape([
      ['M',-.257,-1.23],['L',-.553,.457],['C',-.431,.586,-.384,.898,-.219,1.135],
      ['C',-.120,1.279,.130,1.265,.255,1.084],['C',.391,.887,.445,.649,.555,.456],
      ['L',.257,-1.23],['Q',0,-1.264,-.257,-1.23],['Z']])},
    {id:'collar',name:'04 / 칼라',centre:[2.35,1.055],map:q=>collarMap(q),label:[2.35,1.48],outline:shape([
      ['M',-.731,-.129],['C',-.360,-.223,.310,-.223,.731,-.129],['L',.579,.217],
      ['C',.219,.294,-.219,.294,-.579,.217],['Z']])},
    {id:'stand',name:'칼라 스탠드',centre:[2.35,.50],map:q=>collarMap([q[0],q[1]*2.8],true),label:null,outline:shape([
      ['M',-.693,-.070],['C',-.269,-.141,.260,-.141,.693,-.070],['Q',.741,.027,.659,.088],
      ['C',.240,.024,-.240,.024,-.659,.088],['Q',-.741,.027,-.693,-.070],['Z']])},
    {id:'cuff',name:'05 / 커프스',centre:[2.35,-.14],map:cuffMap,label:[2.35,-.50],outline:shape([
      ['M',-.617,-.199],['L',.540,-.199],['Q',.617,-.199,.617,-.122],['L',.617,.122],
      ['Q',.617,.199,.540,.199],['L',-.617,.199],['Z']])},
    {id:'pocket',name:'06 / 포켓',centre:[2.35,-.943],map:pocketMap,label:[2.35,-1.48],outline:shape([
      ['M',-.251,.286],['L',.251,.286],['L',.251,-.199],['Q',.251,-.287,.164,-.298],
      ['L',-.164,-.298],['Q',-.251,-.287,-.251,-.199],['Z']])}
  ];
  const palette={
    cut:{alpha:.98,detail:-.2,keep:1,dash:0,gap:0,speed:1,weight:1.95,tone:[1.10,1.09,1.02]},
    sew:{alpha:.79,detail:.19,keep:.76,dash:.036,gap:.025,speed:1.25,weight:1.48,tone:[.60,1.01,1.03]},
    allowance:{alpha:.56,detail:.36,keep:.10,dash:.008,gap:.026,speed:1.6,weight:1.18,tone:[.78,.83,1.02]},
    construction:{alpha:.43,detail:.53,keep:0,dash:.081,gap:.035,speed:1.75,weight:1.13,tone:[.66,.88,.94]},
    dimension:{alpha:.78,detail:.66,keep:0,dash:0,gap:0,speed:1.5,weight:1.30,tone:[1.52,1.04,.92]},
    notch:{alpha:.93,detail:.81,keep:.2,dash:0,gap:0,speed:.8,weight:1.63,tone:[.88,1.13,1.07]}
  };
  function addPath(piece,points,kind,name,options={}){
    const sampled=resample(points,options.step||.014);let distance=0;
    const vertices=sampled.map((q,i)=>{
      if(i)distance+=Math.hypot(q[0]-sampled[i-1][0],q[1]-sampled[i-1][1]);
      const flat=[piece.centre[0]+q[0],piece.centre[1]+q[1],.0];
      const target=piece.map(q);
      return {flat,target,distance,local:q};
    });
    const path={name:name||piece.id+'-'+kind,kind,piece,vertices,length:distance,...options};
    paths.push(path);stages[kind].push(path);return path;
  }
  function label(text,position,role,path,extra={}){
    const q={text,position:new THREE.Vector3(...position),flatPosition:new THREE.Vector3(...position),role,
      revealX:position[0],detailAt:role==='dimension'?.66:0,opacity:0,drawAt:0,path,...extra};
    labels.push(q);return q;
  }
  for(const piece of pieces){
    const outer=resample(piece.outline,.022);
    const cut=addPath(piece,outer,'cut',piece.id+'-cut');
    addPath(piece,offset(outer,-.038),'sew',piece.id+'-stitch');
    if(piece.id!=='stand')addPath(piece,offset(outer,-.071),'allowance',piece.id+'-allowance');
    if(piece.label)label(piece.name,[...piece.label,0],'piece',cut);
  }
  const byId=id=>pieces.find(p=>p.id===id);
  const grain=(id,y0,y1,x=0)=>{
    const piece=byId(id),l=addPath(piece,[[x,y0],[x,y1]],'construction',id+'-grain');
    addPath(piece,[[x-.035,y1-.075],[x,y1],[x+.035,y1-.075]],'construction',id+'-grain-top');
    addPath(piece,[[x-.035,y0+.075],[x,y0],[x+.035,y0+.075]],'construction',id+'-grain-bottom');
    return l;
  };
  grain('front',-.86,.68,-.10);grain('back',-.83,.95);grain('sleeve',-.88,.91);
  grain('pocket',-.16,.18);
  addPath(byId('back'),[[-.636,.765],[.636,.765]],'construction','back-yoke');
  addPath(byId('front'),[[-.266,-1.15],[-.266,.96]],'construction','front-placket');
  addPath(byId('front'),[[-.23,.360],[.390,.360]],'construction','front-chest-reference');
  addPath(byId('sleeve'),[[-.490,.475],[.490,.475]],'construction','sleeve-bicep-reference');
  addPath(byId('pocket'),[[-.205,.216],[.205,.216]],'sew','pocket-topstitch');

  // Closed V-notches and matched double-notch pairs make the seam logic
  // legible without turning the diagram into a decorative grid.
  function notch(id,q,tangent=[0,1],double=false){
    const piece=byId(id),l=Math.hypot(...tangent),t=tangent.map(v=>v/l),n=[-t[1],t[0]];
    const one=(shift,index)=>addPath(piece,[
      [q[0]+t[0]*(shift-.023),q[1]+t[1]*(shift-.023)],
      [q[0]+t[0]*shift+n[0]*.033,q[1]+t[1]*shift+n[1]*.033],
      [q[0]+t[0]*(shift+.023),q[1]+t[1]*(shift+.023)]
    ],'notch',id+'-notch-'+paths.length+'-'+index);
    one(double?-.045:0,0);if(double)one(.045,1);
  }
  notch('front',[.313,.655],[.10,-.9]);notch('back',[-.594,.655],[-.10,-.9],true);
  notch('back',[.594,.655],[.10,.9],true);notch('sleeve',[-.385,.875],[.5,.8]);
  notch('sleeve',[.393,.85],[-.5,.8],true);notch('collar',[0,-.196],[1,0]);
  notch('cuff',[0,.199],[-1,0]);

  // Dimension graphics are actual independently drawn strokes. Only the
  // supplied chart's four reference values are stated as measurements.
  const page={id:'page',centre:[0,0],map:q=>surface(pools.front,[clamp(q[0],-.8,.8),clamp(q[1],-1.4,1.3),.24])};
  function dimension(name,a,b,text,at,rotation=0){
    const stem=addPath(page,[a,b],'dimension',name);
    const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),t=[dx/len,dy/len],n=[-t[1],t[0]];
    for(const [i,q]of [a,b].entries()){
      addPath(page,[[q[0]-n[0]*.051,q[1]-n[1]*.051],[q[0]+n[0]*.051,q[1]+n[1]*.051]],'dimension',name+'-tick-'+i);
      const inward=i?-1:1;
      addPath(page,[[q[0]+t[0]*.043*inward+n[0]*.02,q[1]+t[1]*.043*inward+n[1]*.02],q,[q[0]+t[0]*.043*inward-n[0]*.02,q[1]+t[1]*.043*inward-n[1]*.02]],'dimension',name+'-arrow-'+i);
    }
    label(text,[...at,0],'dimension',stem,{rotation});return stem;
  }
  dimension('shoulder',[-1.982,1.414],[-.638,1.414],'어깨 48 cm',[-1.31,1.565]);
  dimension('chest',[-1.94,.285],[-.68,.285],'가슴둘레 114 cm',[-1.31,.165]);
  dimension('length',[-3.09,1.272],[-3.09,-1.246],'총장 78 cm',[-3.185,.015],-Math.PI/2);
  dimension('sleeve-length',[1.248,1.25],[1.248,-1.232],'소매 60 cm',[1.362,.005],-Math.PI/2);
  const note=label('기본 셔츠 100호 참고 치수 · 제작용 확정 패턴 아님',[0,-1.70,0],'reference',null,{detailAt:.81});

  // Natural drawing order: long curves first, inner construction next, final
  // dimension ticks and notches last. A pause separates each pen-down stroke.
  const ordered=['cut','sew','allowance','construction','dimension','notch'].flatMap(k=>stages[k]);
  let clock=0;
  for(const path of ordered){
    const settings=palette[path.kind],duration=Math.max(.11,path.length/settings.speed);
    path.start=clock;path.end=clock+duration;
    clock=path.end+(path.kind==='cut'?.25:path.kind==='dimension'?.065:.12);
  }
  const total=clock-.12;
  for(const path of ordered){path.start/=total;path.end/=total;}
  for(const q of labels)q.drawAt=q.path?q.path.end:.97;
  // Pen-up transfers are part of the continuous pen itinerary, never part of
  // the ink geometry. The trail crosses stroke boundaries without resetting.
  const route=[],transfers=[];let routeDistance=0;
  for(let i=0;i<ordered.length;i++){
    const path=ordered[i],previous=ordered[i-1];
    if(previous&&path.start>previous.end){
      const transfer={kind:'travel',from:previous.vertices.at(-1),to:path.vertices[0],start:previous.end,end:path.start};
      let distance=0,last=new THREE.Vector3(),next=new THREE.Vector3();
      travelPoint(transfer,0,0,0,0,0,last);
      for(let j=1;j<=24;j++){travelPoint(transfer,j/24,0,0,0,0,next);distance+=next.distanceTo(last);last.copy(next);}
      transfer.length=Math.max(.000001,distance);transfer.routeStart=routeDistance;routeDistance+=transfer.length;transfer.routeEnd=routeDistance;
      route.push(transfer);transfers.push(transfer);
    }
    path.routeStart=routeDistance;routeDistance+=path.length;path.routeEnd=routeDistance;
    route.push({kind:'draw',path,length:path.length,routeStart:path.routeStart,routeEnd:path.routeEnd});
  }
  const attributes={position:[],draftX:[],drawAt:[],distance:[],alpha:[],detailAt:[],keep:[],dash:[],gap:[],weight:[],tone:[]};
  const vertexRecords=[];
  for(const path of ordered){
    const style=palette[path.kind];
    for(let i=1;i<path.vertices.length;i++)for(const v of [path.vertices[i-1],path.vertices[i]]){
      attributes.position.push(...v.flat);attributes.draftX.push(v.flat[0]);
      attributes.drawAt.push(lerp(path.start,path.end,v.distance/(path.length||1)));
      attributes.distance.push(v.distance);attributes.alpha.push(style.alpha);attributes.detailAt.push(style.detail);
      attributes.keep.push(style.keep);attributes.dash.push(style.dash);attributes.gap.push(style.gap);
      attributes.weight.push(style.weight);attributes.tone.push(...style.tone);
      vertexRecords.push(v);
    }
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(attributes.position,3).setUsage(THREE.DynamicDrawUsage));
  for(const name of ['draftX','drawAt','distance','alpha','detailAt','keep','dash','gap'])geometry.setAttribute('a'+name[0].toUpperCase()+name.slice(1),new THREE.Float32BufferAttribute(attributes[name],1));
  // Native WebGL line width is usually clamped to one pixel. Render the exact
  // same centreline as narrow screen-space ribbons, retaining the original
  // geometry below for pen correspondence and the public line-data contract.
  const inkGeometry=new THREE.BufferGeometry(),inkSource=[],inkSide=[];
  for(let i=0;i<vertexRecords.length;i+=2){inkSource.push(i,i,i+1,i,i+1,i+1);inkSide.push(-1,1,-1,1,1,-1);}
  const inkPosition=new Float32Array(inkSource.length*3),inkOther=new Float32Array(inkSource.length*3);
  inkGeometry.setAttribute('position',new THREE.BufferAttribute(inkPosition,3).setUsage(THREE.DynamicDrawUsage));
  inkGeometry.setAttribute('aOther',new THREE.BufferAttribute(inkOther,3).setUsage(THREE.DynamicDrawUsage));
  inkGeometry.setAttribute('aSide',new THREE.Float32BufferAttribute(inkSide,1));
  inkGeometry.setAttribute('aDirection',new THREE.Float32BufferAttribute(inkSource.map(i=>i%2?-1:1),1));
  for(const name of ['draftX','drawAt','distance','alpha','detailAt','keep','dash','gap','weight']){
    inkGeometry.setAttribute('a'+name[0].toUpperCase()+name.slice(1),new THREE.Float32BufferAttribute(inkSource.map(i=>attributes[name][i]),1));
  }
  inkGeometry.setAttribute('aTone',new THREE.Float32BufferAttribute(inkSource.flatMap(i=>attributes.tone.slice(i*3,i*3+3)),3));
  const material=new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,depthTest:true,blending:THREE.NormalBlending,side:THREE.DoubleSide,
    uniforms:{uColor:{value:new THREE.Color('#6edaff')},uRevealX:{value:10},uExitX:{value:SCAN_LEFT},uDrawingProgress:{value:0},uDetailProgress:{value:1},uProjection:{value:0},uOpacity:{value:1},uResolution:{value:new THREE.Vector2(1920,1080)},uPixelRatio:{value:1}},
    vertexShader:`
      attribute float aDraftX,aDrawAt,aDistance,aAlpha,aDetailAt,aKeep,aDash,aGap;
      attribute float aSide,aDirection,aWeight;attribute vec3 aOther,aTone;
      uniform vec2 uResolution;uniform float uPixelRatio;
      varying float vDraftX,vDrawAt,vDistance,vAlpha,vDetailAt,vKeep,vDash,vGap,vSide;
      varying vec3 vTone;
      void main(){
        vDraftX=aDraftX;vDrawAt=aDrawAt;vDistance=aDistance;vAlpha=aAlpha;vDetailAt=aDetailAt;vKeep=aKeep;vDash=aDash;vGap=aGap;vSide=aSide;vTone=aTone;
        vec4 point=projectionMatrix*modelViewMatrix*vec4(position,1.0);
        vec4 other=projectionMatrix*modelViewMatrix*vec4(aOther,1.0);
        vec2 delta=(other.xy/other.w-point.xy/point.w)*uResolution*aDirection;
        float segmentLength=max(length(delta),0.00001);vec2 normal=vec2(-delta.y,delta.x)/segmentLength;
        point.xy+=normal*aSide*aWeight*uPixelRatio/uResolution*point.w;
        gl_Position=point;
      }
    `,
    fragmentShader:`
      uniform vec3 uColor;uniform float uRevealX,uExitX,uDrawingProgress,uDetailProgress,uProjection,uOpacity;
      varying float vDraftX,vDrawAt,vDistance,vAlpha,vDetailAt,vKeep,vDash,vGap,vSide;
      varying vec3 vTone;
      void main(){
        if(vDraftX>uRevealX||vDraftX<=uExitX||vDrawAt>uDrawingProgress)discard;
        if(vDash>0.0&&mod(vDistance,vDash+vGap)>vDash)discard;
        float detail=smoothstep(vDetailAt,vDetailAt+0.16,uDetailProgress);
        float projection=mix(1.0,vKeep,smoothstep(0.05,0.82,uProjection));
        float edge=1.0-smoothstep(0.84,1.0,abs(vSide));
        float alpha=uOpacity*vAlpha*detail*projection*edge;if(alpha<0.002)discard;
        // A short luminous wake lives only on the precisely completed line.
        // Its energy settles before the held, fully drawn CAD frame.
        float age=max(0.0,uDrawingProgress-vDrawAt);
        float wake=(1.0-smoothstep(0.0,0.009,age))*(1.0-smoothstep(0.993,1.0,uDrawingProgress));
        vec3 ink=mix(uColor*vTone,vec3(0.66,1.25,1.42),wake*0.8);
        gl_FragColor=vec4(ink,alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `
  });
  const lines=new THREE.LineSegments(geometry,material);lines.visible=false;
  const inkLines=new THREE.Mesh(inkGeometry,material);inkLines.name='CAD pen — weighted precise ink';inkLines.frustumCulled=false;inkLines.renderOrder=4;group.add(inkLines);
  // This stays correct through root camera zooms and HiDPI resizes without a
  // second resize API or assumptions about CSS viewport size.
  inkLines.onBeforeRender=renderer=>{
    renderer.getDrawingBufferSize(material.uniforms.uResolution.value);
    material.uniforms.uPixelRatio.value=renderer.getPixelRatio();
    material.uniformsNeedUpdate=true;
  };

  function deform(q,fit,length,sleeve){
    const x=q[0],y=q[1],z=q[2],body=1-ease((Math.abs(x)-.68)/.57);
    const lower=ease((.35-y)/1.75),arm=ease((Math.abs(x)-.70)/.35)*ease((.65-y)/1.5);
    return[x*(1+fit*.075*(.48+.52*body)),y-length*.24*lower*body-sleeve*.27*arm,z*(1+fit*.055)];
  }
  function mixVertex(v,projection,fit,length,sleeve,result){
    const target=deform(v.target,fit,length,sleeve),localBend=Math.sin(v.local[1]*1.9+v.local[0]*.9);
    const amount=ease(clamp(projection+projection*(1-projection)*.14*localBend));
    result.set(lerp(v.flat[0],target[0],amount),lerp(v.flat[1],target[1],amount),
      lerp(v.flat[2],target[2],amount)+Math.sin(Math.PI*projection)*.105*Math.sin(v.local[1]*1.6));
    return result;
  }
  function atPath(path,u,projection,fit,length,sleeve,result){
    const distance=clamp(u)*path.length;let i=1;
    while(i<path.vertices.length-1&&path.vertices[i].distance<distance)i++;
    const a=path.vertices[i-1],b=path.vertices[i],part=clamp((distance-a.distance)/(b.distance-a.distance||1));
    mixVertex(a,projection,fit,length,sleeve,result);mixVertex(b,projection,fit,length,sleeve,temp);result.lerp(temp,part);return result;
  }
  function travelPoint(transfer,amount,projection,fit,length,sleeve,result){
    const from=mixVertex(transfer.from,projection,fit,length,sleeve,new THREE.Vector3());
    const to=mixVertex(transfer.to,projection,fit,length,sleeve,new THREE.Vector3());
    const dx=to.x-from.x,dy=to.y-from.y,planar=Math.hypot(dx,dy),arc=4*amount*(1-amount),bow=Math.min(.10,planar*.04);
    result.copy(from).lerp(to,amount);
    if(planar>.000001){result.x-=dy/planar*bow*arc;result.y+=dx/planar*bow*arc;}
    result.z+=.045*arc*(1-projection);
    return result;
  }
  function routePoint(distance,projection,fit,length,sleeve,result){
    const d=clamp(distance,0,routeDistance),item=route.find(q=>d<=q.routeEnd)||route.at(-1);
    const along=clamp((d-item.routeStart)/(item.length||1));
    return item.kind==='draw'?atPath(item.path,along,projection,fit,length,sleeve,result):travelPoint(item,along,projection,fit,length,sleeve,result);
  }
  function update({revealX=10,exitScan=0,projection=0,opacity=1,detailProgress=1,drawingProgress=1,pathProgress,fit=0,length=0,sleeve=0}={}){
    projection=clamp(projection);opacity=clamp(opacity);detailProgress=clamp(detailProgress);
    const draw=clamp(pathProgress??drawingProgress);
    const u=material.uniforms;u.uRevealX.value=Number.isFinite(revealX)?revealX:10;u.uProjection.value=projection;
    exitScan=clamp(exitScan);scanX=scanXFor(exitScan);u.uExitX.value=scanX;
    u.uOpacity.value=opacity;u.uDetailProgress.value=detailProgress;u.uDrawingProgress.value=draw;
    group.visible=opacity>.001&&exitScan<1;
    const key=[projection,fit,length,sleeve].map(v=>v.toFixed(6)).join('/');
    if(lastKey!==key){
      const position=geometry.getAttribute('position');
      for(let i=0;i<vertexRecords.length;i++){mixVertex(vertexRecords[i],projection,fit,length,sleeve,projected);position.setXYZ(i,projected.x,projected.y,projected.z);}
      for(let i=0;i<inkSource.length;i++){
        const a=inkSource[i]*3,b=(inkSource[i]^1)*3,j=i*3;
        inkPosition[j]=position.array[a];inkPosition[j+1]=position.array[a+1];inkPosition[j+2]=position.array[a+2];
        inkOther[j]=position.array[b];inkOther[j+1]=position.array[b+1];inkOther[j+2]=position.array[b+2];
      }
      inkGeometry.getAttribute('position').needsUpdate=true;inkGeometry.getAttribute('aOther').needsUpdate=true;
      position.needsUpdate=true;lastKey=key;
    }
    activePath=ordered.find(path=>draw>=path.start&&draw<=path.end)||null;
    const transfer=activePath?null:transfers.find(q=>draw>q.start&&draw<q.end)||null;
    const path=activePath||ordered.findLast(path=>draw>=path.end)||ordered[0];
    const along=activePath?clamp((draw-path.start)/(path.end-path.start)):1;
    let penDistance=path.routeStart+path.length*along,travelTime=0;
    if(transfer){
      travelTime=clamp((draw-transfer.start)/(transfer.end-transfer.start));
      penDistance=transfer.routeStart+transfer.length*quintic(travelTime);
    }
    penDrawing=!!activePath&&draw<1&&opacity>.001&&projection<.95&&exitScan<1;
    penActive=(penDrawing||!!transfer)&&opacity>.001&&projection<.95&&exitScan<1;
    penOpacity=penActive?(transfer ? .28+.72*Math.pow(Math.abs(travelTime*2-1),2) : 1):0;
    routePoint(penDistance,projection,fit,length,sleeve,penPosition);
    const lead=routePoint(penDistance+.0007,projection,fit,length,sleeve,new THREE.Vector3());
    const trail=routePoint(penDistance-.0007,projection,fit,length,sleeve,new THREE.Vector3());
    penTangent.copy(lead).sub(trail).normalize();
    for(let i=0;i<penTrail.length;i++)routePoint(penDistance-(1-i/(penTrail.length-1))*.45,projection,fit,length,sleeve,penTrail[i]);
    for(const q of labels){
      q.position.copy(q.flatPosition);q.opacity=opacity*ease((draw-q.drawAt+.001)/.012)*ease((detailProgress-q.detailAt+.04)/.18)*(1-ease(projection/.52));
      if(q.revealX>u.uRevealX.value||q.revealX<=scanX||exitScan>=1)q.opacity=0;
    }
    return {penPosition,penTangent,penTrail,penActive,penDrawing,penOpacity,scanX,path:activePath?.name||null,drawingProgress:draw};
  }
  const bounds=new THREE.Box3(new THREE.Vector3(-3.27,-1.75,-.1),new THREE.Vector3(3.17,1.65,.15));
  update({drawingProgress:0});
  return {group,lines,material,geometry,inkLines,inkGeometry,labels,bounds,penPosition,penTangent,penTrail,
    get penActive(){return penActive;},get penDrawing(){return penDrawing;},get penOpacity(){return penOpacity;},get scanX(){return scanX;},scanXFor,
    get activePath(){return activePath?.name||null;},
    drawingOrder:ordered.map(p=>({name:p.name,kind:p.kind,start:p.start,end:p.end,length:p.length})),
    update,dispose(){geometry.dispose();inkGeometry.dispose();material.dispose();group.clear();}
  };
}
