import * as THREE from './vendor/three.module.js';
import {createPhotoGarment} from './photo-garment.js';
import {createDraft} from './cad.js';
import {createLightRibbon} from './light-ribbon.js';
import {sampleArc} from './continuity.js';
import {createIntroMotion} from './intro-route.js';
import {createCarrierRoute} from './carrier-route.js';
import {photoAssets} from './assets.js';
import {DURATION,beats,clamp,lerp,p,w,drawingAt,stateAt} from './motion-v2.js';

const $=s=>document.querySelector(s),canvas=$('#stage'),status=$('#status');
const V=(x,y,z=.4)=>new THREE.Vector3(x,y,z);
const query=new URLSearchParams(location.search);
const keyTimes={wire:15.5,cad:65,photo:89.4};
const fixed=query.has('frame')?(keyTimes[query.get('frame')]??0):query.has('t')?clamp(Number(query.get('t'))||0,0,DURATION):null;
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
let autoplay=query.get('autoplay')==='1'&&!reduced;
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance',preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor('#02070f',0);renderer.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-4,4,2.3,-2.3,.1,30);
camera.position.set(0,0,9);camera.lookAt(0,0,0);
const garment=createPhotoGarment(THREE,photoAssets);scene.add(garment.group);
const variants=[-1,1].map(side=>{const g=createPhotoGarment(THREE,photoAssets);scene.add(g.group);return{side,g};});
const draft=createDraft(THREE,null);scene.add(draft.group);
const cadEntry=draft.penPosition.clone();
const line=createLightRibbon(THREE);scene.add(line.group);
const scanLine=createLightRibbon(THREE);scene.add(scanLine.group);
const contourLine=createLightRibbon(THREE);scene.add(contourLine.group);
const halo=new THREE.Mesh(new THREE.PlaneGeometry(.38,.38),new THREE.ShaderMaterial({transparent:true,depthTest:false,depthWrite:false,blending:THREE.AdditiveBlending,
 uniforms:{uAlpha:{value:1}},vertexShader:'varying vec2 v;void main(){v=uv-.5;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:'varying vec2 v;uniform float uAlpha;void main(){float r=dot(v,v);gl_FragColor=vec4(.3,.78,1.,uAlpha*(.25*exp(-r*65.)+.80*exp(-r*1700.)));}'}));halo.renderOrder=80;scene.add(halo);
let lightTime=0,view={mobile:false,x:1.35,y:0,scale:1.18},currentTime=0;
let introMotion=null,carrierMotion=null,exitMotion=null,routeSignature='';
const smooth=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
const ease=(t,a,b)=>smooth((t-a)/(b-a));
const world=(v,g=garment.group)=>v.clone().applyMatrix4(g.matrixWorld);
const linePoints=(a,b,n=64)=>Array.from({length:n},(_,i)=>a.clone().lerp(b,i/(n-1)));

function frameAt(t,width=canvas.clientWidth,height=canvas.clientHeight){
 const mobile=width<900,aspect=width/height,layout=w(t,29.5,33.2,38.5,42),cadView=w(t,49,52,82.2,84);
 const half=lerp(mobile?Math.max(3.45,1.70/aspect):2.50,Math.max(mobile?3.65:2.70,3.65/aspect),Math.max(layout,cadView));
 const focus=w(t,70,74,82.2,84);
 return{mobile,aspect,layout,cadView,half,cameraY:lerp(0,mobile?.8:.55,cadView),x:(mobile?0:1.35)*(1-layout)*(1-focus),y:mobile?-1.13:lerp(0,-.40,layout),scale:lerp(1.18,.98,layout)};
}
function screenPoint(point,t){const f=frameAt(t);return V(point.x/(f.half*f.aspect),(point.y-f.cameraY)/f.half,point.z);}
function screenWorld(point,t){const f=frameAt(t);return V(point.x*f.half*f.aspect,point.y*f.half+f.cameraY,point.z);}
function ensureMotionRoutes(){
 const signature=canvas.clientWidth+'x'+canvas.clientHeight;if(signature===routeSignature)return;
 const base=frameAt(0),right=base.x+1.33,top=base.y+1.725*base.scale,bottom=base.y-1.725*base.scale;
 const anchor=(t,name)=>{const s=stateAt(t),f=frameAt(t);garment.update({fit:s.fit,length:s.length,sleeve:s.sleeve,depth:1});return garment.anchors[name].clone().multiplyScalar(f.scale).add(V(f.x,f.y,0));};
 garment.update({fit:0,length:0,sleeve:0,depth:1});
 const contour=garment.sampleContour(400).map(q=>q.multiplyScalar(base.scale).add(V(base.x,base.y,0)));
 introMotion=createIntroMotion(THREE,contour,V(right,top),V(right,bottom));
 const endIntro=introMotion.sample(14.5),chest=anchor(17.2,'chestLeft'),hem=anchor(21.1,'length'),sleeve=anchor(24.1,'sleeve'),detail=anchor(27.1,'detail');
 const sp=(q,t)=>screenPoint(q,t),tangent=(x,y)=>V(x,y,0),node=(t,q,dir,extra={})=>({t,position:sp(q,t),tangent:dir,...extra});
 const chestPoint=sp(chest,17.2),hemPoint=sp(hem,21.1),sleevePoint=sp(sleeve,24.1),detailPoint=sp(detail,27.1);
 const left=base.x-1.32,below=bottom-.18;
 const firstPen=cadEntry.clone().multiplyScalar(.94).add(V(0,-.13,0));
 const keys=[
  node(14.5,V(right,bottom),tangent(0,-1)),
  {t:17.2,position:chestPoint,tangent:tangent(1,-.15),via:[
   {position:sp(V(right-.18,below),15),tangent:tangent(-1,-.2)},
   {position:sp(V(left,below),15.7),tangent:tangent(-1,.5)},
   {position:sp(V(left,chest.y-.23),16.4),tangent:tangent(0,1)}]},
  {t:20.3,position:chestPoint},
  {t:21.1,position:hemPoint,tangent:tangent(-1,-.15)},
  {t:23.6,position:hemPoint},
  {t:24.1,position:sleevePoint,tangent:tangent(0,1)},
  {t:26.3,position:sleevePoint},
  {t:27.1,position:detailPoint,tangent:tangent(1,1)},
  {t:29.7,position:detailPoint},
  // Stay to the right of the preceding point while the collection camera
  // widens. These are screen coordinates, never rebuilt from the live pose.
  {t:32,position:V(detailPoint.x+.035,.50,.4),tangent:tangent(.8,1)},
  {t:35,position:V(detailPoint.x+.09,.57,.4),tangent:tangent(1,0)},
  {t:38,position:V(detailPoint.x+.15,.58,.4),tangent:tangent(1,0)},
  node(42,V(right,top),tangent(0,-1),{via:[{position:sp(V(right-.20,top+.15),42),tangent:tangent(1,0)}]}),
  node(48,V(right,bottom),tangent(0,-1)),
  node(49,V(right,bottom),tangent(0,-1)),
  node(52,firstPen,tangent(1,0),{via:[
   {position:sp(V(right-.22,bottom-.16),49),tangent:tangent(-1,0)},
   {position:sp(V(-3.35,-1.4),51),tangent:tangent(0,1)},
   {position:sp(firstPen.clone().add(V(-.30,0,0)),52),tangent:tangent(1,0)}]})
 ];
 carrierMotion=createCarrierRoute(THREE,keys,{prefixPoints:endIntro.trail.map(q=>sp(q,14.5)),tailLength:.8/base.half,trailSamples:120});
 draft.update({drawingProgress:1,projection:0});
 const endPen=draft.penPosition.clone().multiplyScalar(.94).add(V(0,-.13,0));
 exitMotion=createCarrierRoute(THREE,[
  node(75,endPen,tangent(0,-1)),
  node(77,V(-3.4,-1.68),tangent(1,0),{via:[
   {position:sp(V(endPen.x,-2.00),75.6),tangent:tangent(-1,0)},
   {position:sp(V(-3.60,-1.95),76.5),tangent:tangent(0,1)}]}),
  node(82.2,V(3.4,-1.68),tangent(1,0)),
  node(84,V(right,top),tangent(0,-1),{via:[
   {position:sp(V(right,top),84).add(V(.10,.12,0)),tangent:tangent(-1,0)}]}),
  node(88.5,V(right,bottom),tangent(0,-1)),node(90,V(right,bottom),tangent(0,-1))
 ],{tailLength:.8/base.half,trailSamples:120});
 routeSignature=signature;
}

function setLight(points,opacity=1,width=.02){
 line.update({points,width,opacity,head:1,time:lightTime,flow:.85});
 halo.visible=opacity>.005;halo.material.uniforms.uAlpha.value=opacity;
 if(points.length)halo.position.copy(points.at(-1)).add(V(0,0,.01));
}

const labels=$('#annotations');
function makeLabel(text,cls='callout'){const el=document.createElement('div');el.textContent=text;el.className=cls;labels.append(el);return el;}
function toScreen(v){const pt=v.clone().project(camera);return[(pt.x*.5+.5)*canvas.clientWidth,(-pt.y*.5+.5)*canvas.clientHeight];}
function put(el,point,opacity,align='center'){
 const xy=toScreen(point);el.style.left=xy[0]+'px';el.style.top=xy[1]+'px';el.style.opacity=clamp(opacity);el.style.visibility=opacity>.01?'visible':'hidden';
 el.style.transform=`translate(${align==='left'?'0':align==='right'?'-100%':'-50%'},-50%)`;
}
const calls=[['핏 / 여유 있게','chestLeft',17.2,20.5,[-.28,.10]],['기장 / 조금 더 짧게','length',21.1,23.7,[-.30,-.15]],['소매 / 손목에 맞게','sleeve',24.1,26.5,[.22,.07]],['디테일 / 포켓의 깊이','detail',27.1,29.8,[-.38,.20]]].map(q=>{
 const l=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:'#8bdfff',transparent:true,opacity:0,depthTest:false}));scene.add(l);return{q,el:makeLabel(q[0]),line:l};
});
const measurements=[['어깨 48 cm','shoulderLeft','shoulderRight',0],['가슴둘레 114 cm','chestLeft','chestRight',1],['총장 78 cm','collar','length',2],['소매 60 cm','shoulderRight','sleeve',3]].map(q=>{
 const l=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:'#85d4f4',transparent:true,opacity:0,depthTest:false}));scene.add(l);return{q,el:makeLabel(q[0]),line:l};
});
const cadLabels=[];
const reference=makeLabel('기본 셔츠 100호 참고 치수 · 제작용 패턴은 전문가 검토 후 확정','measurement-note');
function annotate(t){
 calls.forEach(({q,el,line})=>{const alpha=w(t,q[2],q[2]+.4,q[3]-.4,q[3]),a=world(garment.anchors[q[1]]),b=a.clone().add(V(q[4][0],q[4][1],0));
  line.geometry.setFromPoints([a,b]);line.material.opacity=alpha*.65;put(el,b,alpha,q[4][0]<0?'right':'left');
 });
 measurements.forEach(({q,el,line},i)=>{
  const alpha=w(t,42.5+i*1.25,43+i*1.25,48.7,50.3),a=world(garment.anchors[q[1]]),b=world(garment.anchors[q[2]]);
  if(i===0){a.y=b.y=Math.max(a.y,b.y)+.23;}if(i===1){a.y=b.y=(a.y+b.y)/2;}
  if(i===2){a.x=b.x=view.x-1.4;}if(i===3){a.x=b.x=view.x+1.38;}
  const tick=i<2?V(0,.032,0):V(.032,0,0);line.geometry.setFromPoints([a,b,a.clone().sub(tick),a.clone().add(tick),b.clone().sub(tick),b.clone().add(tick)]);line.material.opacity=alpha*.65;
  const midpoint=a.clone().lerp(b,.5);if(i<2)midpoint.y+=.09;else midpoint.x+=i===2?-.10:.10;put(el,midpoint,alpha,i<2?'center':i===2?'right':'left');
 });
 draft.labels.forEach((q,i)=>{if(!cadLabels[i])cadLabels[i]=makeLabel(q.text,'cad-label');const alpha=q.role==='reference'?0:q.opacity*(1-ease(t,74.8,76.6));put(cadLabels[i],world(q.position,draft.group),alpha);if(q.rotation)cadLabels[i].style.transform+=` rotate(${-q.rotation}rad)`;});
 reference.style.opacity=w(t,42,43,74.5,76);reference.style.visibility=t>=42&&t<76?'visible':'hidden';
}

function renderAt(t){
 currentTime=t;const s=stateAt(t),mobile=canvas.clientWidth<900,aspect=canvas.clientWidth/canvas.clientHeight;
 const frame=frameAt(t),{layout,cadView,half}=frame;
 ensureMotionRoutes();
 camera.left=-half*aspect;camera.right=half*aspect;camera.top=half;camera.bottom=-half;camera.position.y=frame.cameraY;camera.lookAt(0,camera.position.y,0);camera.updateProjectionMatrix();
 view={mobile,x:frame.x,y:frame.y,scale:frame.scale};
 const materialise=ease(t,84,88.5),scanX=lerp(-3.4,3.4,ease(t,77,82.2));
 const wirePresence=t<75?1-ease(t,49.2,54):1;
 garment.group.position.set(view.x,view.y,0);garment.group.scale.setScalar(view.scale);garment.group.rotation.y=0;garment.group.updateMatrixWorld(true);
 garment.update({time:lightTime,opacity:wirePresence,reveal:ease(t,8,14.5),photo:materialise,worldRevealX:t>=75&&t<82.3?scanX:100,worldScanTop:view.y+1.725*view.scale,worldScanBottom:view.y-1.725*view.scale,colorProgress:p(t,90,93)*.5+p(t,94,96)*.5,fit:s.fit,length:s.length,sleeve:s.sleeve,depth:1,wireStrength:1});
 garment.group.visible=t>=8&&(wirePresence>.001||t>=75);
 variants.forEach(({side,g},i)=>{
  const out=ease(t,30+i*.3,33+i*.3),merge=ease(t,35.5+i*.45,40.8+i*.45),alpha=out*(1-ease(t,39.3+i*.35,41.2+i*.35))*.32;
  g.group.visible=alpha>.001;if(!g.group.visible)return;
  const r=merge*merge,x=side*2.42*out*(1-r)+view.x*r,y=view.y+.42*Math.sin(Math.PI*r);
  g.group.position.set(x,y,-.06);g.group.scale.setScalar(lerp(.92,view.scale,merge));g.group.rotation.y=0;
  g.update({time:lightTime,opacity:alpha,photo:0,reveal:1,worldRevealX:100,fit:lerp(side*.40,s.fit,merge),length:lerp(side*.22,s.length,merge),sleeve:lerp(side*.15,s.sleeve,merge)});
 });
 // The first CAD shoulder starts on the previous garment. The entire sheet
 // then travels as a single drafting surface into its working composition.
 const sheet=ease(t,49,52),sheetScale=lerp(1,.94,sheet),draftAlpha=w(t,50.8,51.6,82.25,82.7);
 draft.group.scale.setScalar(sheetScale);draft.group.rotation.set(0,0,0);draft.group.position.set(lerp((mobile?0:1.35)+2.88,0,sheet),lerp((mobile?-.70:0)+.20,-.13,sheet));draft.group.updateMatrixWorld(true);
 const exitLocal=(scanX-draft.group.position.x)/sheetScale;
 draft.update({drawingProgress:drawingAt(t),projection:0,opacity:draftAlpha,detailProgress:1,exitScan:t<77?0:clamp((exitLocal+3.27)/6.44),fit:s.fit,length:s.length,sleeve:s.sleeve});
 const right=view.x+1.33,top=view.y+1.725*view.scale,bottom=view.y-1.725*view.scale;
 scanLine.update({opacity:0});contourLine.update({opacity:0});
 if(t<52){
  let introduction=null,tail;
  if(t<=14.5){
   introduction=introMotion.sample(t);tail=introduction.trail;
  }else{
   const sample=carrierMotion.sample(t),trim=ease(t,49,52);
   tail=Array.from({length:120},(_,i)=>screenWorld(sampleArc(sample.trail,lerp(trim,1,i/119)),t));
  }
  setLight(tail,lerp(1,.38,w(t,31,33,39,41)),lerp(.038,.018,ease(t,6,10)));
  const scan=t<17?ease(t,8,14.5):ease(t,42,48),scanAlpha=t<17?w(t,7.8,8.4,14.8,16):w(t,41.8,42.4,48.2,49.1);
  if(scanAlpha>.001){const y=lerp(top,bottom,scan);scanLine.update({points:linePoints(V(view.x-1.30,y),V(right,y)),opacity:scanAlpha*.48,width:.011,head:1,time:lightTime,flow:0});}
  const contourAlpha=w(t,4,4.15,9,11)*.80;
  if(contourAlpha>.001&&introduction)contourLine.update({points:introduction.outlinePoints,opacity:contourAlpha,width:.011,head:1,revealX:introduction.contourRevealX,time:lightTime,flow:0});
 }else if(t<75){
  const trim=ease(t,73,75),points=Array.from({length:80},(_,i)=>world(sampleArc(draft.penTrail,lerp(trim,1,i/79)),draft.group));
  setLight(points,t>=72.5?1:(draft.penOpacity??1),.018);
 }else if(t<90){
  const sample=exitMotion.sample(t),start=Math.max(exitMotion.distanceAt(75),sample.trailStartDistance);
  const tail=Array.from({length:120},(_,i)=>screenWorld(exitMotion.pointAtDistance(lerp(start,sample.distance,i/119)),t));
  const alpha=1-ease(t,88.5,90);setLight(tail,alpha,.018);
  if(t>=77&&t<82.2)scanLine.update({points:linePoints(V(scanX,Math.max(1.60,top)),V(scanX,-1.68)),opacity:w(t,77,77.4,81.8,82.2)*.55,width:.014,head:1,time:lightTime,flow:0});
  if(t>=84){const y=lerp(top,bottom,materialise);scanLine.update({points:linePoints(V(view.x-1.3,y),V(right,y)),opacity:alpha*.55,width:.013,head:1,time:lightTime,flow:0});}
 }else setLight([],0,.01);
 annotate(t);
 const beat=beats[s.index],narration=$('.narration');
 $('#eyebrow').textContent=beat[2];$('#caption').textContent=t>100?'Kustom your week.':beat[3];$('#description').textContent=t>100?'고객의 생각에서, 함께 검토할 하나의 샘플까지.':beat[4];$('#phase').textContent=String(s.index+1).padStart(2,'0')+' / 08';
 const enter=s.index===0?1:ease(t,beat[0],beat[0]+.8),leave=s.index===7?1:1-ease(t,beat[1]-.7,beat[1]),closing=1-w(t,99.25,100,100,100.75);narration.style.setProperty('--copy-opacity',Math.min(enter,leave)*closing);narration.style.setProperty('--copy-shift',`${(1-enter)*10-(1-leave)*8}px`);
 $('#viewport').dataset.scene=beat[2].toLowerCase();$('.draft-ground').style.opacity=cadView*.55;
 $('#progress').style.transform=`scaleX(${t/DURATION})`;$('#cad-steps').style.opacity=w(t,52,53,74,75);$('#cad-steps').dataset.step=drawingAt(t)<.343685?'outline':drawingAt(t)<.611176?'seam':drawingAt(t)<.802315?'allowance':'dimension';
 $('#draft-operation').style.opacity=w(t,52,53,74,75);$('#draft-part').textContent=(draft.activePath??'PATTERN ENGINEERING').replaceAll('-',' ').toUpperCase();
 $('#material-palette').style.opacity=w(t,89,90,99,100);$('#material-palette').dataset.color=t<91.5?'brown':t<95?'charcoal':'khaki';$('#material-caption').textContent=t<91.5?'EARTH BROWN':t<95?'CHARCOAL':'UTILITY KHAKI';
 canvas.dataset.time=t.toFixed(3);canvas.dataset.phase=beat[2];canvas.dataset.photo=materialise.toFixed(3);renderer.render(scene,camera);
}
function resize(){renderer.setSize($('#viewport').clientWidth,$('#viewport').clientHeight,false);}
function scrollTime(){const section=$('#story');return clamp(-section.getBoundingClientRect().top/(section.offsetHeight-innerHeight))*DURATION;}
let raf,last=-1,lastNow=performance.now(),started=lastNow,smoothed=fixed??scrollTime();
function tick(now){const dt=Math.min(.06,(now-lastNow)/1000);lastNow=now;
 const target=fixed??(autoplay?clamp((now-started)/1000,0,DURATION):scrollTime());smoothed=fixed!==null||reduced?target:lerp(smoothed,target,1-Math.exp(-dt*11));if(Math.abs(smoothed-target)<.0003)smoothed=target;
 lightTime=smoothed;
 if(Math.abs(smoothed-last)>.0001){renderAt(smoothed);last=smoothed;}
 if(!document.hidden)raf=requestAnimationFrame(tick);
}
function schedule(){cancelAnimationFrame(raf);lastNow=performance.now();raf=requestAnimationFrame(tick);}
addEventListener('scroll',()=>{if(fixed!==null)return;autoplay=false;schedule();},{passive:true});
addEventListener('resize',()=>{resize();last=-1;schedule();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule();});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();status.textContent='화면을 새로고침해주세요.';});
resize();Promise.all([garment.ready,...variants.map(v=>v.g.ready)]).then(()=>{status.textContent='';document.body.dataset.ready='true';renderAt(fixed??0);started=performance.now();schedule();}).catch(e=>{status.textContent='의류 이미지를 불러오지 못했습니다.';console.error(e);});
