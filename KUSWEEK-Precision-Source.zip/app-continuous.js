import * as THREE from './vendor/three.module.js';
import {createPhotoGarment} from './photo-garment.js';
import {createDraft} from './cad.js';
import {createLightRibbon} from './light-ribbon.js';
import {sampleArc} from './continuity.js';
import {createIntroMotion} from './intro-route.js';
import {photoAssets} from './assets.js';
import {DURATION,beats,clamp,lerp,p,w,drawingAt,stateAt} from './motion-v2.js';

const $=s=>document.querySelector(s),canvas=$('#stage'),status=$('#status');
const V=(x,y,z=.4)=>new THREE.Vector3(x,y,z);
const query=new URLSearchParams(location.search);
const keyTimes={wire:15.5,cad:65,photo:89.4};
const fixed=query.has('frame')?(keyTimes[query.get('frame')]??0):query.has('t')?clamp(Number(query.get('t'))||0,0,DURATION):null;
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
let autoplay=query.get('autoplay')==='1'&&!reduced;
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance',preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor('#02070f',0);renderer.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-4,4,2.3,-2.3,.1,30);
camera.position.set(0,0,9);camera.lookAt(0,0,0);
const garment=createPhotoGarment(THREE,photoAssets);scene.add(garment.group);
const variants=[-1,1].map(side=>{const g=createPhotoGarment(THREE,photoAssets);scene.add(g.group);return{side,g};});
const draft=createDraft(THREE,null);scene.add(draft.group);
const cadEntry=draft.penPosition.clone();
const line=createLightRibbon(THREE);scene.add(line.group);
const scanLine=createLightRibbon(THREE);scene.add(scanLine.group);
const contourLine=createLightRibbon(THREE);scene.add(contourLine.group);
const halo=new THREE.Mesh(new THREE.PlaneGeometry(.38,.38),new THREE.ShaderMaterial({transparent:true,depthTest:false,depthWrite:false,blending:THREE.AdditiveBlending,
 uniforms:{uAlpha:{value:1}},vertexShader:'varying vec2 v;void main(){v=uv-.5;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:'varying vec2 v;uniform float uAlpha;void main(){float r=dot(v,v);gl_FragColor=vec4(.3,.78,1.,uAlpha*(.25*exp(-r*65.)+.80*exp(-r*1700.)));}'}));halo.renderOrder=80;scene.add(halo);
let lightTime=0,view={mobile:false,x:1.35,y:0,scale:1.18},currentTime=0;
let introMotion=null,introMobile=null;
const smooth=x=>{x=clamp(x);return x*x*x*(x*(x*6-15)+10);};
const ease=(t,a,b)=>smooth((t-a)/(b-a));
const world=(v,g=garment.group)=>v.clone().applyMatrix4(g.matrixWorld);
const linePoints=(a,b,n=64)=>Array.from({length:n},(_,i)=>a.clone().lerp(b,i/(n-1)));

// The moving light is a finite section of a continuous head trajectory. Its
// vertices are never paired with an unrelated closed outline or a new shape.
function routePoint(keys,t){
 if(t<=keys[0][0])return keys[0][1].clone();
 for(let i=1;i<keys.length;i++)if(t<=keys[i][0]){
  const [ta,a]=keys[i-1],[tb,b]=keys[i],q=ease(t,ta,tb),lift=keys[i][2]??0;
  const point=a.clone().lerp(b,q);point.y+=Math.sin(Math.PI*q)*lift;return point;
 }
 return keys.at(-1)[1].clone();
}
function distanceTail(sample,t,length=.8,count=100){
 const points=[sample(t)];let distance=0;
 // Fixed time knots describe the path, but only physical arc distance sets
 // the visible tail. Slowing down cannot reveal older sections behind it.
 for(let past=Math.floor((t-1e-9)/.025)*.025;past>=t-30;past-=.025){
  const next=sample(past),previous=points.at(-1),segment=next.distanceTo(previous);
  if(distance+segment>=length){points.push(previous.clone().lerp(next,(length-distance)/Math.max(segment,1e-12)));break;}
  if(segment>1e-10){distance+=segment;points.push(next);}
 }
 points.reverse();return Array.from({length:count},(_,i)=>sampleArc(points,i/(count-1)));
}
function trail(keys,t,length=.8,count=100){return distanceTail(at=>routePoint(keys,at),t,length,count);}
function setLight(points,opacity=1,width=.02){
 line.update({points,width,opacity,head:1,time:lightTime,flow:.85});
 halo.visible=opacity>.005;halo.material.uniforms.uAlpha.value=opacity;
 if(points.length)halo.position.copy(points.at(-1)).add(V(0,0,.01));
}

const labels=$('#annotations');
function makeLabel(text,cls='callout'){const el=document.createElement('div');el.textContent=text;el.className=cls;labels.append(el);return el;}
function toScreen(v){const pt=v.clone().project(camera);return[(pt.x*.5+.5)*canvas.clientWidth,(-pt.y*.5+.5)*canvas.clientHeight];}
function put(el,point,opacity,align='center'){
 const xy=toScreen(point);el.style.left=xy[0]+'px';el.style.top=xy[1]+'px';el.style.opacity=clamp(opacity);el.style.visibility=opacity>.01?'visible':'hidden';
 el.style.transform=`translate(${align==='left'?'0':align==='right'?'-100%':'-50%'},-50%)`;
}
const calls=[['핏 / 여유 있게','chestLeft',17.2,20.5,[-.28,.10]],['기장 / 조금 더 짧게','length',21.1,23.7,[-.30,-.15]],['소매 / 손목에 맞게','sleeve',24.1,26.5,[.22,.07]],['디테일 / 포켓의 깊이','detail',27.1,29.8,[-.38,.20]]].map(q=>{
 const l=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:'#8bdfff',transparent:true,opacity:0,depthTest:false}));scene.add(l);return{q,el:makeLabel(q[0]),line:l};
});
const measurements=[['어깨 48 cm','shoulderLeft','shoulderRight',0],['가슴둘레 114 cm','chestLeft','chestRight',1],['총장 78 cm','collar','length',2],['소매 60 cm','shoulderRight','sleeve',3]].map(q=>{
 const l=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:'#85d4f4',transparent:true,opacity:0,depthTest:false}));scene.add(l);return{q,el:makeLabel(q[0]),line:l};
});
const cadLabels=[];
const reference=makeLabel('기본 셔츠 100호 참고 치수 · 제작용 패턴은 전문가 검토 후 확정','measurement-note');
function annotate(t){
 calls.forEach(({q,el,line})=>{const alpha=w(t,q[2],q[2]+.4,q[3]-.4,q[3]),a=world(garment.anchors[q[1]]),b=a.clone().add(V(q[4][0],q[4][1],0));
  line.geometry.setFromPoints([a,b]);line.material.opacity=alpha*.65;put(el,b,alpha,q[4][0]<0?'right':'left');
 });
 measurements.forEach(({q,el,line},i)=>{
  const alpha=w(t,42.5+i*1.25,43+i*1.25,48.7,50.3),a=world(garment.anchors[q[1]]),b=world(garment.anchors[q[2]]);
  if(i===0){a.y=b.y=Math.max(a.y,b.y)+.23;}if(i===1){a.y=b.y=(a.y+b.y)/2;}
  if(i===2){a.x=b.x=view.x-1.4;}if(i===3){a.x=b.x=view.x+1.38;}
  const tick=i<2?V(0,.032,0):V(.032,0,0);line.geometry.setFromPoints([a,b,a.clone().sub(tick),a.clone().add(tick),b.clone().sub(tick),b.clone().add(tick)]);line.material.opacity=alpha*.65;
  const midpoint=a.clone().lerp(b,.5);if(i<2)midpoint.y+=.09;else midpoint.x+=i===2?-.10:.10;put(el,midpoint,alpha,i<2?'center':i===2?'right':'left');
 });
 draft.labels.forEach((q,i)=>{if(!cadLabels[i])cadLabels[i]=makeLabel(q.text,'cad-label');const alpha=q.role==='reference'?0:q.opacity*(1-ease(t,74.8,76.6));put(cadLabels[i],world(q.position,draft.group),alpha);if(q.rotation)cadLabels[i].style.transform+=` rotate(${-q.rotation}rad)`;});
 reference.style.opacity=w(t,42,43,74.5,76);reference.style.visibility=t>=42&&t<76?'visible':'hidden';
}

function renderAt(t){
 currentTime=t;const s=stateAt(t),mobile=canvas.clientWidth<900,aspect=canvas.clientWidth/canvas.clientHeight;
 const layout=w(t,29.5,33.2,38.5,42),cadView=w(t,49,58.5,82.2,84),wide=Math.max(layout,cadView);
 const half=lerp(mobile?Math.max(3.15,1.70/aspect):2.28,Math.max(mobile?3.65:2.70,3.65/aspect),wide);
 camera.left=-half*aspect;camera.right=half*aspect;camera.top=half;camera.bottom=-half;camera.position.y=lerp(0,mobile?.8:.55,cadView);camera.lookAt(0,camera.position.y,0);camera.updateProjectionMatrix();
 const projectionFocus=w(t,70,74,82.2,84);
 view={mobile,x:(mobile?0:1.35)*(1-layout)*(1-projectionFocus),y:mobile?-1.13:lerp(0,-.40,layout),scale:lerp(1.18,.98,layout)};
 const materialise=ease(t,84,88.5),scanX=lerp(-3.4,3.4,ease(t,77,82.2));
 const wirePresence=t<75?1-ease(t,49.2,54):1;
 garment.group.position.set(view.x,view.y,0);garment.group.scale.setScalar(view.scale);garment.group.rotation.y=0;garment.group.updateMatrixWorld(true);
 garment.update({time:lightTime,opacity:wirePresence,reveal:ease(t,8,14.5),photo:materialise,worldRevealX:t>=75&&t<82.3?scanX:100,worldScanTop:view.y+1.725*view.scale,worldScanBottom:view.y-1.725*view.scale,colorProgress:p(t,90,93)*.5+p(t,94,96)*.5,fit:s.fit,length:s.length,sleeve:s.sleeve,depth:1,wireStrength:1});
 garment.group.visible=t>=8&&(wirePresence>.001||t>=75);
 variants.forEach(({side,g},i)=>{
  const out=ease(t,30+i*.3,33+i*.3),merge=ease(t,35.5+i*.45,40.8+i*.45),alpha=out*(1-ease(t,39.3+i*.35,41.2+i*.35))*.32;
  g.group.visible=alpha>.001;if(!g.group.visible)return;
  const r=merge*merge,x=side*2.42*out*(1-r)+view.x*r,y=view.y+.42*Math.sin(Math.PI*r);
  g.group.position.set(x,y,-.06);g.group.scale.setScalar(lerp(.92,view.scale,merge));g.group.rotation.y=0;
  g.update({time:lightTime,opacity:alpha,photo:0,reveal:1,worldRevealX:100,fit:lerp(side*.40,s.fit,merge),length:lerp(side*.22,s.length,merge),sleeve:lerp(side*.15,s.sleeve,merge)});
 });
 // The first CAD shoulder starts on the previous garment. The entire sheet
 // then travels as a single drafting surface into its working composition.
 const sheet=ease(t,52.8,59.5),sheetScale=lerp(1,.94,sheet),draftAlpha=w(t,50.8,51.6,82.25,82.7);
 draft.group.scale.setScalar(sheetScale);draft.group.rotation.set(0,0,0);draft.group.position.set(lerp((mobile?0:1.35)+2.88,0,sheet),lerp((mobile?-.70:0)+.20,-.13,sheet));draft.group.updateMatrixWorld(true);
 const exitLocal=(scanX-draft.group.position.x)/sheetScale;
 draft.update({drawingProgress:drawingAt(t),projection:0,opacity:draftAlpha,detailProgress:1,exitScan:t<77?0:clamp((exitLocal+3.27)/6.44),fit:s.fit,length:s.length,sleeve:s.sleeve});
 const right=view.x+1.33,top=view.y+1.725*view.scale,bottom=view.y-1.725*view.scale;
 const chest=world(garment.anchors.chestLeft),hem=world(garment.anchors.length),sleeve=world(garment.anchors.sleeve),detail=world(garment.anchors.detail);
 const firstPen=world(cadEntry,draft.group);
 const keys=[[6,V(right,top)],[8,V(right,top)],[14.5,V(right,bottom)],[17.2,chest,.35],[20.3,chest],[21.1,hem,-.18],[23.6,hem],[24.1,sleeve,-.05],[26.3,sleeve],[27.1,detail,.3],[29.7,detail],[32,V(-2.40,1.20),.30],[35,V(-.7,1.70),.15],[38,V(1.8,1.58),.20],[42,V(right,top),.15],[48,V(right,bottom)],[49,V(right,bottom)],[52,firstPen,.45]];
 scanLine.update({opacity:0});contourLine.update({opacity:0});
 if(t<52){
  let introduction=null,tail;
  if(t<=14.5){
   if(!introMotion||introMobile!==mobile){
    introMotion=createIntroMotion(THREE,garment.sampleContour(400).map(q=>world(q)),V(right,top),V(right,bottom));
    introMobile=mobile;
   }
   introduction=introMotion.sample(t);tail=introduction.trail;
  }else tail=trail(keys,t,.8*(1-ease(t,49,52)),100);
  setLight(tail,lerp(1,.38,w(t,31,33,39,41)),lerp(.038,.018,ease(t,6,10)));
  const scan=t<17?ease(t,8,14.5):ease(t,42,48),scanAlpha=t<17?w(t,7.8,8.4,14.8,16):w(t,41.8,42.4,48.2,49.1);
  if(scanAlpha>.001){const y=lerp(top,bottom,scan);scanLine.update({points:linePoints(V(view.x-1.30,y),V(right,y)),opacity:scanAlpha*.48,width:.011,head:1,time:lightTime,flow:0});}
  const contourAlpha=w(t,4,4.15,9,11)*.80;
  if(contourAlpha>.001&&introduction)contourLine.update({points:introduction.outlinePoints,opacity:contourAlpha,width:.011,head:introduction.outlineProgress,time:lightTime,flow:0});
 }else if(t<75){
  const trim=ease(t,73,75),points=Array.from({length:80},(_,i)=>world(sampleArc(draft.penTrail,lerp(trim,1,i/79)),draft.group));
  setLight(points,t>=72.5?1:(draft.penOpacity??1),.018);
 }else if(t<90){
  const end=world(draft.penPosition,draft.group),exit=[[74,end],[75,end],[77,V(-3.4,-1.68),.65],[82.2,V(3.4,-1.68)],[84,V(right,top),.38],[88.5,V(right,bottom)],[90,V(right,bottom)]];
  const alpha=1-ease(t,88.5,90);setLight(trail(exit,t,1),alpha,.018);
  if(t>=77&&t<82.2)scanLine.update({points:linePoints(V(scanX,Math.max(1.60,top)),V(scanX,-1.68)),opacity:w(t,77,77.4,81.8,82.2)*.55,width:.014,head:1,time:lightTime,flow:0});
  if(t>=84){const y=lerp(top,bottom,materialise);scanLine.update({points:linePoints(V(view.x-1.3,y),V(right,y)),opacity:alpha*.55,width:.013,head:1,time:lightTime,flow:0});}
 }else setLight([],0,.01);
 annotate(t);
 const beat=beats[s.index],narration=$('.narration');
 $('#eyebrow').textContent=beat[2];$('#caption').textContent=t>100?'Kustom your week.':beat[3];$('#description').textContent=t>100?'고객의 생각에서, 함께 검토할 하나의 샘플까지.':beat[4];$('#phase').textContent=String(s.index+1).padStart(2,'0')+' / 08';
 const enter=s.index===0?1:ease(t,beat[0],beat[0]+.8),leave=s.index===7?1:1-ease(t,beat[1]-.7,beat[1]),closing=1-w(t,99.25,100,100,100.75);narration.style.setProperty('--copy-opacity',Math.min(enter,leave)*closing);narration.style.setProperty('--copy-shift',`${(1-enter)*10-(1-leave)*8}px`);
 $('#viewport').dataset.scene=beat[2].toLowerCase();$('.draft-ground').style.opacity=cadView*.55;
 $('#progress').style.transform=`scaleX(${t/DURATION})`;$('#cad-steps').style.opacity=w(t,52,53,74,75);$('#cad-steps').dataset.step=drawingAt(t)<.343685?'outline':drawingAt(t)<.611176?'seam':drawingAt(t)<.802315?'allowance':'dimension';
 $('#draft-operation').style.opacity=w(t,52,53,74,75);$('#draft-part').textContent=(draft.activePath??'PATTERN ENGINEERING').replaceAll('-',' ').toUpperCase();
 $('#material-palette').style.opacity=w(t,89,90,99,100);$('#material-palette').dataset.color=t<91.5?'brown':t<95?'charcoal':'khaki';$('#material-caption').textContent=t<91.5?'EARTH BROWN':t<95?'CHARCOAL':'UTILITY KHAKI';
 canvas.dataset.time=t.toFixed(3);canvas.dataset.phase=beat[2];canvas.dataset.photo=materialise.toFixed(3);renderer.render(scene,camera);
}
function resize(){renderer.setSize($('#viewport').clientWidth,$('#viewport').clientHeight,false);}
function scrollTime(){const section=$('#story');return clamp(-section.getBoundingClientRect().top/(section.offsetHeight-innerHeight))*DURATION;}
let raf,last=-1,lastNow=performance.now(),started=lastNow,smoothed=fixed??scrollTime();
function tick(now){const dt=Math.min(.06,(now-lastNow)/1000);lastNow=now;
 const target=fixed??(autoplay?clamp((now-started)/1000,0,DURATION):scrollTime());smoothed=fixed!==null||reduced?target:lerp(smoothed,target,1-Math.exp(-dt*11));if(Math.abs(smoothed-target)<.0003)smoothed=target;
 lightTime=smoothed;
 if(Math.abs(smoothed-last)>.0001){renderAt(smoothed);last=smoothed;}
 if(!document.hidden)raf=requestAnimationFrame(tick);
}
function schedule(){cancelAnimationFrame(raf);lastNow=performance.now();raf=requestAnimationFrame(tick);}
addEventListener('scroll',()=>{if(fixed!==null)return;autoplay=false;schedule();},{passive:true});
addEventListener('resize',()=>{resize();last=-1;schedule();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule();});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();status.textContent='화면을 새로고침해주세요.';});
resize();Promise.all([garment.ready,...variants.map(v=>v.g.ready)]).then(()=>{status.textContent='';document.body.dataset.ready='true';renderAt(fixed??0);started=performance.now();schedule();}).catch(e=>{status.textContent='의류 이미지를 불러오지 못했습니다.';console.error(e);});
