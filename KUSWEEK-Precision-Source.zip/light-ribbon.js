/**
 * Authored luminous ribbon. No textures, external libraries or postprocessing.
 *
 * Reference principles (original implementation, no source copied):
 * - Codrops Animated Mesh Lines: billboarded triangle strip; arc-length shader
 *   animation rather than rebuilding a tube for every moving highlight.
 *   https://tympanus.net/codrops/2019/01/08/animated-mesh-lines/
 * - Active Theory Neon: a leading light with a following tail, then separate
 *   core and glow composited into a richer luminous object.
 *   https://medium.com/active-theory/neon-a-webgl-installation-fdf540c42152
 *
 * API: createLightRibbon(THREE) -> {group, update, dispose}
 * update({points, width=.012, opacity=1, head=1, time=0, flow=1})
 * - points: Vector3[] in local space; fixed orthographic camera looking down Z.
 * - width: full core world width; halo is 8 times this width.
 * - head: normalized arc distance 0..1; the unreached path is invisible.
 * - flow: 0 clean drafting stroke; 1 bright head, tapered tail, moving energy.
 * - time: shared scroll score; retained for API compatibility.
 * Geometry buffers are reused. Call dispose() when the module is removed.
 */
export function createLightRibbon(THREE) {
  const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,Number.isFinite(v)?v:a));
  const group=new THREE.Group();
  group.name='One line — luminous ribbon';
  const shared={
    uWidth:{value:.012},uOpacity:{value:1},uHead:{value:1},
    uTime:{value:0},uFlow:{value:1},uRevealX:{value:10000},
  };
  const vertexShader=/* glsl */`
    attribute vec2 aMiter;
    attribute float aSide;
    uniform float uWidth;
    uniform float uHead;
    uniform float uFlow;
    uniform float uSpread;
    varying vec2 vRibbonUv;
    varying float vWorldX;
    void main(){
      vRibbonUv=uv;
      vWorldX=(modelMatrix*vec4(position,1.0)).x;
      float behind=uHead-uv.x;
      float tailTaper=clamp(1.0-behind/.52,0.0,1.0);
      float taper=mix(1.0,mix(.32,1.0,pow(tailTaper,.72)),uFlow);
      vec3 ribbonPosition=position;
      ribbonPosition.xy+=aMiter*aSide*uWidth*.5*uSpread*taper;
      gl_Position=projectionMatrix*modelViewMatrix*vec4(ribbonPosition,1.0);
    }
  `;
  const fragmentShader=/* glsl */`
    precision highp float;
    uniform float uOpacity;
    uniform float uHead;
    uniform float uTime;
    uniform float uFlow;
    uniform float uLayer;
    uniform float uRevealX;
    varying vec2 vRibbonUv;
    varying float vWorldX;
    void main(){
      float along=vRibbonUv.x;
      float across=vRibbonUv.y*2.0-1.0;
      float pathAA=max(fwidth(along),.00015);
      float reached=1.0-smoothstep(uHead-pathAA,uHead+pathAA,along);
      float startFade=smoothstep(0.0,max(.002,pathAA*2.0),along);
      if(uHead<=.00001 || reached*uOpacity<.0001)discard;
      float behind=max(0.0,uHead-along);
      float lead=exp(-pow(behind/.012,2.0));
      float longTail=exp(-behind/.165)*(1.0-smoothstep(.32,.58,behind));
      // One spatial leader only. A recycled wall-clock pulse on this trailing
      // path looked like a second pen moving backwards when the user paused.
      float flowing=.026+.60*longTail+.65*lead;
      float luminance=mix(.72,flowing,uFlow);
      float transverseAA=max(fwidth(across),.002);
      float edge=1.0-smoothstep(1.0-transverseAA,1.0,abs(across));
      float core=exp(-pow(abs(across)*1.58,3.0))*edge;
      float inner=exp(-across*across*5.0)*edge;
      float outer=exp(-across*across*4.7)*edge;
      float isInner=step(.5,uLayer)*(1.0-step(1.5,uLayer));
      float isOuter=step(1.5,uLayer);
      float isCore=1.0-step(.5,uLayer);
      float profile=core*isCore+inner*isInner+outer*isOuter;
      float gain=.87*isCore+.135*isInner+.035*isOuter;
      vec3 ice=vec3(.83,.95,1.0);
      vec3 cyan=vec3(.10,.61,.95);
      float whiteCore=exp(-across*across*7.5)*isCore;
      vec3 radiance=mix(cyan,ice,whiteCore);
      float revealAA=max(fwidth(vWorldX),.0001);
      float revealed=1.0-smoothstep(uRevealX-revealAA,uRevealX+revealAA,vWorldX);
      float alpha=profile*gain*luminance*reached*startFade*uOpacity*revealed;
      if(alpha<.00015)discard;
      gl_FragColor=vec4(radiance,alpha);
      #include <colorspace_fragment>
    }
  `;
  const layers=[
    {name:'Wide atmospheric falloff',spread:8,kind:2,order:70},
    {name:'Cyan penumbra',spread:3.2,kind:1,order:71},
    {name:'Ice-white luminous core',spread:1,kind:0,order:72},
  ].map(({name,spread,kind,order})=>{
    const material=new THREE.ShaderMaterial({
      name,uniforms:{...shared,uSpread:{value:spread},uLayer:{value:kind}},
      vertexShader,fragmentShader,transparent:true,blending:THREE.AdditiveBlending,
      depthTest:false,depthWrite:false,side:THREE.DoubleSide,toneMapped:false,
    });
    const mesh=new THREE.Mesh(new THREE.BufferGeometry(),material);
    mesh.name=name;mesh.renderOrder=order;mesh.frustumCulled=false;group.add(mesh);
    return mesh;
  });
  let geometry=null,capacity=0,count=0,positions,miters,uvs,sides,coordinates,distances;
  let destroyed=false;
  function allocate(required){
    if(required<=capacity)return;
    let next=32;while(next<required)next*=2;
    const previous=geometry;
    geometry=new THREE.BufferGeometry();capacity=next;
    positions=new Float32Array(capacity*6);
    miters=new Float32Array(capacity*4);
    uvs=new Float32Array(capacity*4);
    sides=new Float32Array(capacity*2);
    coordinates=new Float64Array(capacity*3);
    distances=new Float64Array(capacity);
    const indices=new Uint32Array((capacity-1)*6);
    for(let i=0;i<capacity;i++){
      sides[i*2]=-1;sides[i*2+1]=1;
      if(i<capacity-1){const a=i*2,k=i*6;indices.set([a,a+1,a+2,a+1,a+3,a+2],k);}
    }
    const attr=(name,data,itemSize)=>geometry.setAttribute(name,new THREE.BufferAttribute(data,itemSize).setUsage(THREE.DynamicDrawUsage));
    attr('position',positions,3);attr('aMiter',miters,2);attr('aSide',sides,1);attr('uv',uvs,2);
    geometry.setIndex(new THREE.BufferAttribute(indices,1));
    for(const mesh of layers){if(mesh.geometry!==previous)mesh.geometry.dispose();mesh.geometry=geometry;}
    previous?.dispose();
    count=0;
  }
  function setPoints(points){
    const n=points?.length??0;
    if(n<2){count=0;if(geometry)geometry.setDrawRange(0,0);return;}
    allocate(n);
    let changed=n!==count;
    for(let i=0;i<n;i++){
      const pt=points[i],x=pt.x??pt[0],y=pt.y??pt[1],z=pt.z??pt[2]??0;
      if(!Number.isFinite(x+y+z))throw new TypeError('Ribbon points must contain finite XYZ coordinates.');
      const k=i*3;
      if(coordinates[k]!==x||coordinates[k+1]!==y||coordinates[k+2]!==z)changed=true;
      coordinates[k]=x;coordinates[k+1]=y;coordinates[k+2]=z;
    }
    if(!changed)return;
    count=n;distances[0]=0;
    for(let i=1;i<n;i++){
      const k=i*3,j=k-3;
      distances[i]=distances[i-1]+Math.hypot(coordinates[k]-coordinates[j],coordinates[k+1]-coordinates[j+1],coordinates[k+2]-coordinates[j+2]);
    }
    const total=distances[n-1];
    if(total<1e-9){geometry.setDrawRange(0,0);return;}
    for(let i=0;i<n;i++){
      const k=i*3,lo=Math.max(0,i-1)*3,hi=Math.min(n-1,i+1)*3;
      let ax=coordinates[k]-coordinates[lo],ay=coordinates[k+1]-coordinates[lo+1];
      let bx=coordinates[hi]-coordinates[k],by=coordinates[hi+1]-coordinates[k+1];
      if(Math.hypot(ax,ay)<1e-9){ax=bx;ay=by;}
      if(Math.hypot(bx,by)<1e-9){bx=ax;by=ay;}
      const al=Math.hypot(ax,ay)||1,bl=Math.hypot(bx,by)||1;
      ax/=al;ay/=al;bx/=bl;by/=bl;
      let nx=-ay-by,ny=ax+bx;
      const nl=Math.hypot(nx,ny);
      if(nl<1e-6){nx=-by;ny=bx;}else{nx/=nl;ny/=nl;}
      if(Math.hypot(nx,ny)<1e-6){nx=1;ny=0;}
      const join=clamp(1/Math.max(.34,Math.abs(nx*(-by)+ny*bx)),1,2.3);
      nx*=join;ny*=join;
      const a=i*6,b=i*4,u=distances[i]/total;
      positions.set([coordinates[k],coordinates[k+1],coordinates[k+2],coordinates[k],coordinates[k+1],coordinates[k+2]],a);
      miters.set([nx,ny,nx,ny],b);uvs.set([u,0,u,1],b);
    }
    geometry.setDrawRange(0,(n-1)*6);
    for(const name of ['position','aMiter','uv'])geometry.getAttribute(name).needsUpdate=true;
  }
  function update({points,width,opacity,head,time,flow,revealX}={}){
    if(destroyed)return;
    if(points!==undefined)setPoints(points);
    if(width!==undefined)shared.uWidth.value=clamp(width,.0001,.5);
    if(opacity!==undefined)shared.uOpacity.value=clamp(opacity);
    if(head!==undefined)shared.uHead.value=clamp(head);
    if(time!==undefined)shared.uTime.value=Number.isFinite(time)?time:0;
    if(flow!==undefined)shared.uFlow.value=clamp(flow);
    if(revealX!==undefined)shared.uRevealX.value=Number.isFinite(revealX)?revealX:10000;
    group.visible=count>1&&shared.uOpacity.value>.0001&&shared.uHead.value>.0001;
  }
  function dispose(){
    if(destroyed)return;destroyed=true;
    if(geometry)geometry.dispose();else for(const mesh of layers)mesh.geometry.dispose();
    for(const mesh of layers)mesh.material.dispose();
    group.clear();group.removeFromParent();
  }
  group.visible=false;
  return {group,update,dispose};
}
