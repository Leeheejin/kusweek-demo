import sourceContour from './photo-contour.json' with {type:'json'};

/**
 * Photo-registered relief study, not a reconstructed 360-degree garment.
 * One subdivided surface, one UV field and one alpha silhouette are shared by
 * the digital quad mesh and the original photographic sample. Its deliberately
 * shallow relief supports small camera angles; the front view registers exactly.
 */
const textureLoads=new Map();

export function createPhotoGarment(THREE, photoAssets) {
  const width=2.3,height=3.45;
  const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,Number.isFinite(v)?v:0));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a));return t*t*(3-2*t);};
  const hero=photoAssets.hero??photoAssets.brown;
  if(!hero)throw new Error('Photo garment requires the original hero or brown cutout.');
  const group=new THREE.Group();
  group.name='KUSWEEK — photo-registered continuous digital garment';
  const empty=new THREE.DataTexture(new Uint8Array([0,0,0,0]),1,1);
  empty.needsUpdate=true;
  const uniforms={
    uBrown:{value:empty},uCharcoal:{value:empty},uKhaki:{value:empty},
    uTime:{value:0},uOpacity:{value:1},uReveal:{value:1},uPhoto:{value:0},
    uColorProgress:{value:0},uFit:{value:0},uLength:{value:0},uSleeve:{value:0},
    uFlat:{value:0},uDepth:{value:1},uGrid:{value:31},uWireStrength:{value:1},
    uWorldRevealX:{value:100},uWorldScanTop:{value:1.725},uWorldScanBottom:{value:-1.725},uLuminanceRelief:{value:.006},
    uTextureSize:{value:new THREE.Vector2(1024,1536)},
  };
  const material=new THREE.ShaderMaterial({
    name:'Same-surface cyan relief and photographic sample',uniforms,
    vertexShader:/* glsl */`
      precision highp float;
      uniform sampler2D uBrown;
      uniform float uFit,uLength,uSleeve,uFlat,uDepth,uLuminanceRelief;
      uniform vec2 uTextureSize;
      varying vec2 vUv;
      varying vec3 vViewPoint;
      varying vec3 vWorldPoint;
      varying float vRelief;
      float dome(float q){return sqrt(max(0.0,1.0-q*q));}
      float analyticRelief(vec2 q){
        float torso=.087*dome((q.x-.555)/.34)
          *smoothstep(.065,.22,q.y)*(1.0-smoothstep(.81,.95,q.y));
        float leftCentre=.17+.035*(1.0-q.y);
        float leftArm=.056*dome((q.x-leftCentre)/.135)
          *smoothstep(.13,.23,q.y)*(1.0-smoothstep(.73,.85,q.y));
        float rightCentre=.895-.020*q.y;
        float rightArm=.050*dome((q.x-rightCentre)/.104)
          *smoothstep(.10,.20,q.y)*(1.0-smoothstep(.73,.85,q.y));
        float shoulder=.037*exp(-pow((q.y-.79)/.075,2.0))
          *exp(-pow((q.x-.53)/.31,4.0));
        float collar=.031*exp(-pow((q.y-.856)/.073,2.0))
          *exp(-pow((q.x-.54)/.195,4.0));
        float neck=-.028*exp(-pow((q.x-.555)/.066,2.0))
          *exp(-pow((q.y-.857)/.066,2.0));
        return max(torso,max(leftArm,rightArm))+shoulder+collar+neck;
      }
      void main(){
        vUv=uv;
        vec3 p=position;
        float body=1.0-smoothstep(.60,1.01,abs(p.x-.10));
        float below=1.0-smoothstep(-1.35,.43,p.y);
        float arms=smoothstep(.49,.87,abs(p.x-.06))
          *(1.0-smoothstep(-.98,.65,p.y));
        p.x*=1.0+uFit*.045*(.45+.55*body);
        p.y-=uLength*.16*body*below+uSleeve*.13*arms;
        // Low-frequency luminance contributes at most a few millimetres. Five
        // widely separated samples reject individual yarns and jpeg/webp noise.
        vec2 tap=vec2(10.0)/uTextureSize;
        vec3 photoTone=texture2D(uBrown,uv).rgb*.36;
        photoTone+=texture2D(uBrown,uv+vec2(tap.x,0.0)).rgb*.16;
        photoTone+=texture2D(uBrown,uv-vec2(tap.x,0.0)).rgb*.16;
        photoTone+=texture2D(uBrown,uv+vec2(0.0,tap.y)).rgb*.16;
        photoTone+=texture2D(uBrown,uv-vec2(0.0,tap.y)).rgb*.16;
        float photoLuma=dot(photoTone,vec3(.2126,.7152,.0722));
        float tinyRelief=(photoLuma-.12)*uLuminanceRelief;
        vRelief=(analyticRelief(uv)+tinyRelief)*uDepth*(1.0-uFlat);
        p.z+=vRelief;
        vec4 world=modelMatrix*vec4(p,1.0);
        vec4 view=viewMatrix*world;
        vWorldPoint=world.xyz;vViewPoint=view.xyz;
        gl_Position=projectionMatrix*view;
      }
    `,
    fragmentShader:/* glsl */`
      precision highp float;
      uniform sampler2D uBrown,uCharcoal,uKhaki;
      uniform float uTime,uOpacity,uReveal,uPhoto,uColorProgress;
      uniform float uGrid,uWireStrength,uWorldRevealX,uWorldScanTop,uWorldScanBottom;
      uniform vec2 uTextureSize;
      varying vec2 vUv;
      varying vec3 vViewPoint,vWorldPoint;
      varying float vRelief;
      vec2 gridAxes(vec2 coords,float density,float core){
        vec2 q=coords*density,footprint=max(fwidth(q),vec2(.00001));
        vec2 distanceToLine=abs(fract(q-.5)-.5)/footprint;
        vec2 lines=1.0-smoothstep(vec2(core),vec2(core+.60),distanceToLine);
        return lines*(1.0-smoothstep(vec2(.64),vec2(1.20),footprint));
      }
      float scanMask(float head,float coordinate,float aa){
        if(head<=.00001)return 0.0;
        if(head>=.99999)return 1.0;
        return 1.0-smoothstep(head-aa,head+aa,coordinate);
      }
      float photoToneAt(vec2 q){
        // Two extra mip levels remove yarn/pixel noise from the warp field.
        // The displayed photograph still samples its ordinary sharp UVs.
        return dot(texture2D(uBrown,q,2.0).rgb,vec3(.2126,.7152,.0722));
      }
      vec2 curvedWireUV(vec2 q){
        vec2 base=q*vec2(2.3,3.45);
        // A cylindrical chart gives regularly spaced surface meridians that
        // bunch slightly at the sides, instead of a screen-space square grid.
        // Its slowly changing axis and girth follow the photographed torso.
        float bodyAxis=.540+.010*sin(q.y*3.4+.6);
        float bodyRadius=.307+.026*smoothstep(.50,.78,q.y)
          -.020*exp(-pow((q.y-.43)/.19,2.0));
        float bodyAcross=(q.x-bodyAxis)/bodyRadius;
        float bodyDome=pow(max(0.0,1.0-bodyAcross*bodyAcross),1.18);
        float bodyArc=clamp(bodyAcross,-.965,.965);
        vec2 bodyChart=vec2(base.x+.055*(asin(bodyArc)-bodyArc)
          -.016*sin(q.y*3.8+.5)*bodyDome,
          base.y-(.108+.018*q.y)*bodyDome);
        float bodyRegion=(1.0-smoothstep(.75,1.22,abs(bodyAcross)))
          *smoothstep(.055,.16,q.y)*(1.0-smoothstep(.77,.90,q.y));
        vec2 chart=mix(base,bodyChart,bodyRegion*.64);
        // Separate smooth sleeve coordinates curve around each bent arm. They
        // blend into the shoulder chart without a hard UV cut or flying piece.
        float leftAxis=.181-.042*exp(-pow((q.y-.46)/.145,2.0))
          +.124*(1.0-smoothstep(.19,.40,q.y));
        float leftRadius=.107+.009*smoothstep(.40,.74,q.y);
        float leftAcross=(q.x-leftAxis)/leftRadius;
        float leftDome=pow(max(0.0,1.0-leftAcross*leftAcross),1.18);
        float leftBend=clamp((leftAxis-.185)*2.3,-.033,.033);
        float leftArc=clamp(leftAcross,-.965,.965);
        vec2 leftChart=vec2(base.x-leftBend+.035*(asin(leftArc)-leftArc)
          +.012*sin(q.y*6.0)*leftDome,
          base.y-.091*leftDome+.035*(1.0-smoothstep(.20,.44,q.y)));
        float leftRegion=(1.0-smoothstep(.72,1.23,abs(leftAcross)))
          *smoothstep(.14,.24,q.y)*(1.0-smoothstep(.71,.83,q.y));
        chart=mix(chart,leftChart,leftRegion*.68);
        float rightAxis=.921-.056*smoothstep(.15,.79,q.y);
        float rightRadius=.072+.010*smoothstep(.34,.73,q.y);
        float rightAcross=(q.x-rightAxis)/rightRadius;
        float rightDome=pow(max(0.0,1.0-rightAcross*rightAcross),1.18);
        float rightBend=clamp((rightAxis-.910)*2.3,-.022,.022);
        float rightArc=clamp(rightAcross,-.965,.965);
        vec2 rightChart=vec2(base.x-rightBend+.029*(asin(rightArc)-rightArc)
          +.007*sin(q.y*5.3+.8)*rightDome,
          base.y-.083*rightDome);
        float rightRegion=(1.0-smoothstep(.72,1.24,abs(rightAcross)))
          *smoothstep(.095,.20,q.y)*(1.0-smoothstep(.72,.83,q.y));
        chart=mix(chart,rightChart,rightRegion*.66);
        // Only broad, actual cloth folds perturb the chart. Widely separated
        // taps suppress individual yarns; the distortion is bounded below one
        // centimetre in model units and leaves an orderly quadrilateral field.
        vec2 broadTap=vec2(16.0,18.0)/uTextureSize;
        float leftTone=photoToneAt(q-vec2(broadTap.x,0.0));
        float rightTone=photoToneAt(q+vec2(broadTap.x,0.0));
        float downTone=photoToneAt(q-vec2(0.0,broadTap.y));
        float upTone=photoToneAt(q+vec2(0.0,broadTap.y));
        vec2 broadGradient=clamp(vec2(rightTone-leftTone,upTone-downTone),vec2(-.08),vec2(.08));
        chart+=broadGradient*.105*max(bodyRegion,max(leftRegion,rightRegion));
        return chart;
      }
      void main(){
        vec4 brown=texture2D(uBrown,vUv);
        if(brown.a<.005||uOpacity<.003)discard;
        // Formation, material replacement and their illuminated frontier all
        // share the external scan plane's world-space Y coordinate, including
        // group scaling/translation and the continuously deformed sleeve/hem.
        float sourceHeight=clamp((uWorldScanTop-vWorldPoint.y)
          /max(uWorldScanTop-uWorldScanBottom,.0001),0.0,1.0);
        float revealAA=max(fwidth(sourceHeight)*1.25,.0010);
        float formation=scanMask(uReveal,sourceHeight,revealAA);
        float worldAA=max(fwidth(vWorldPoint.x)*1.2,.0015);
        float worldReveal=1.0-smoothstep(uWorldRevealX-worldAA,uWorldRevealX+worldAA,vWorldPoint.x);
        if(formation*worldReveal<.002)discard;
        // Regular quadrilateral isolines belong to the same physical UV field
        // as the photo. They are not a luminance/edge detector or image filter.
        vec2 physicalUV=curvedWireUV(vUv);
        vec2 fine=gridAxes(physicalUV,uGrid,.12);
        vec2 mainLines=gridAxes(physicalUV,uGrid/6.0,.23);
        float fineWire=max(fine.x,fine.y);
        float primaryWire=max(mainLines.x,mainLines.y);
        float wire=max(fineWire*.43,primaryWire*.75);
        vec3 surfaceNormal=normalize(cross(dFdx(vViewPoint),dFdy(vViewPoint)));
        if(!gl_FrontFacing)surfaceNormal=-surfaceNormal;
        vec3 viewDirection=normalize(-vViewPoint);
        float surfaceLight=max(dot(surfaceNormal,normalize(vec3(-.63,.79,.89))),0.0);
        float grazing=pow(1.0-max(dot(surfaceNormal,viewDirection),0.0),3.0);
        float photoLuma=dot(brown.rgb,vec3(.2126,.7152,.0722));
        float clothTone=pow(clamp(photoLuma*3.35,0.0,1.0),.66);
        // Actual tonal structure preserves the real collar, pockets, placket,
        // seam ridges and cloth folds beneath the independently generated grid.
        float cavity=smoothstep(.0035,.049,photoLuma);
        vec3 base=vec3(.009,.031,.050)*(.34+clothTone*1.72);
        base*=.76+surfaceLight*.34;
        vec3 ice=vec3(.43,.84,.98);
        float gain=(.20+.57*clothTone+.14*surfaceLight)*mix(.27,1.0,cavity);
        vec3 digital=base+ice*wire*gain*clamp(uWireStrength,0.0,1.0);
        digital+=vec3(.09,.24,.33)*grazing*.24;
        // A coherent scanning current illuminates only real grid strands.
        float head=fract(uTime/6.2)*1.4-.2;
        float envelope=smoothstep(-.18,.0,head)*(1.0-smoothstep(1.0,1.18,head));
        float leading=exp(-pow((sourceHeight-head)/.020,2.0));
        float wake=exp(-pow((sourceHeight-head+.057)/.095,2.0));
        float currentEnergy=(leading*.50+wake*.13)*envelope;
        float formationHead=exp(-pow((sourceHeight-uReveal)/.012,2.0))
          *step(.001,uReveal)*(1.0-step(.999,uReveal));
        digital+=vec3(.60,.91,1.0)*wire*(currentEnergy+formationHead*.42)
          *uWireStrength*mix(.35,1.0,cavity);
        // One mask performs an exact complementary state change on this one
        // surface. Position, alpha boundary, scale, relief and UV never switch.
        float photograph=scanMask(uPhoto,sourceHeight,revealAA);
        vec4 charcoal=texture2D(uCharcoal,vUv),khaki=texture2D(uKhaki,vUv);
        vec4 brownPremult=vec4(brown.rgb*brown.a,brown.a);
        vec4 charcoalPremult=vec4(charcoal.rgb*charcoal.a,charcoal.a);
        vec4 khakiPremult=vec4(khaki.rgb*khaki.a,khaki.a);
        vec4 actual=mix(brownPremult,charcoalPremult,smoothstep(0.0,.5,uColorProgress));
        actual=mix(actual,khakiPremult,smoothstep(.5,1.0,uColorProgress));
        vec3 originalPhoto=actual.rgb/max(actual.a,.00001);
        vec3 color=mix(digital,originalPhoto,photograph);
        float frontier=exp(-pow((sourceHeight-uPhoto)/.0019,2.0))
          *step(.001,uPhoto)*(1.0-step(.999,uPhoto));
        color=mix(color,vec3(.54,.88,.98),frontier*.20);
        float silhouette=mix(brown.a,actual.a,photograph);
        float alpha=silhouette*formation*worldReveal*uOpacity;
        if(alpha<.004)discard;
        gl_FragColor=vec4(color,alpha);
        #include <colorspace_fragment>
        #include <premultiplied_alpha_fragment>
      }
    `,
    transparent:true,premultipliedAlpha:true,depthWrite:true,depthTest:true,
    side:THREE.DoubleSide,toneMapped:false,
  });
  const geometry=new THREE.PlaneGeometry(width,height,240,360);
  geometry.boundingBox=new THREE.Box3(new THREE.Vector3(-1.4,-2.1,-.03),new THREE.Vector3(1.4,1.8,.18));
  geometry.boundingSphere=new THREE.Sphere(new THREE.Vector3(0,-.1,.05),2.5);
  const mesh=new THREE.Mesh(geometry,material);
  mesh.name='87k-vertex photo-registered garment relief';mesh.visible=false;
  mesh.userData.basePositions=geometry.getAttribute('position').array.slice();
  group.add(mesh);
  let loaded=false;
  let state={time:0,opacity:1,reveal:1,photo:0,colorProgress:0,fit:0,length:0,sleeve:0,flat:0,depth:1,wireStrength:1,grid:31,worldRevealX:100,worldScanTop:1.725,worldScanBottom:-1.725};
  function analyticRelief(qx,qy){
    const dome=q=>Math.sqrt(Math.max(0,1-q*q));
    const torso=.087*dome((qx-.555)/.34)*smooth(.065,.22,qy)*(1-smooth(.81,.95,qy));
    const left=.056*dome((qx-(.17+.035*(1-qy)))/.135)*smooth(.13,.23,qy)*(1-smooth(.73,.85,qy));
    const right=.050*dome((qx-(.895-.020*qy))/.104)*smooth(.10,.20,qy)*(1-smooth(.73,.85,qy));
    const shoulder=.037*Math.exp(-(((qy-.79)/.075)**2))*Math.exp(-(((qx-.53)/.31)**4));
    const collar=.031*Math.exp(-(((qy-.856)/.073)**2))*Math.exp(-(((qx-.54)/.195)**4));
    const neck=-.028*Math.exp(-(((qx-.555)/.066)**2))*Math.exp(-(((qy-.857)/.066)**2));
    return Math.max(torso,left,right)+shoulder+collar+neck;
  }
  function localPoint(x,y,lift=.012){
    const body=1-smooth(.60,1.01,Math.abs(x-.10));
    const below=1-smooth(-1.35,.43,y);
    const arms=smooth(.49,.87,Math.abs(x-.06))*(1-smooth(-.98,.65,y));
    const z=analyticRelief(x/width+.5,y/height+.5)*state.depth*(1-state.flat)+lift;
    return new THREE.Vector3(x*(1+state.fit*.045*(.45+.55*body)),y-state.length*.16*body*below-state.sleeve*.13*arms,z);
  }
  const anchorBase={
    fit:[-.53,-.05],length:[.01,-1.42],sleeve:[-.62,-.91],detail:[-.22,.37],
    collar:[.04,1.28],shoulderLeft:[-.77,1.01],shoulderRight:[.73,1.01],
    chestLeft:[-.52,.28],chestRight:[.72,.28],hem:[.61,-1.30],
  };
  const anchors=Object.fromEntries(Object.entries(anchorBase).map(([key,p])=>[key,localPoint(...p)]));
  function update(next={}){
    const photo=next.photo??next.progress??next.imageReveal??state.photo;
    state={
      time:next.time??state.time,opacity:clamp(next.opacity??state.opacity),
      reveal:clamp(next.reveal??state.reveal),photo:clamp(photo),
      colorProgress:clamp(next.colorProgress??state.colorProgress),
      fit:clamp(next.fit??state.fit,-1,1.5),length:clamp(next.length??state.length,-1,1),
      sleeve:clamp(next.sleeve??state.sleeve,-1,1),flat:clamp(next.flat??state.flat),
      depth:clamp(next.depth??state.depth,0,1.25),wireStrength:clamp(next.wireStrength??state.wireStrength),
      grid:clamp(next.grid??state.grid,8,50),worldRevealX:next.worldRevealX??state.worldRevealX,
      worldScanTop:next.worldScanTop??state.worldScanTop,worldScanBottom:next.worldScanBottom??state.worldScanBottom,
    };
    for(const key of ['time','opacity','reveal','photo','fit','length','sleeve','flat','depth','wireStrength','grid','worldRevealX','worldScanTop','worldScanBottom']){
      uniforms['u'+key[0].toUpperCase()+key.slice(1)].value=state[key];
    }
    // Color variants are original source images, and begin only after the
    // brown construction frontier has completed its continuous reveal.
    uniforms.uColorProgress.value=state.photo>.9999?state.colorProgress:0;
    for(const[key,p]of Object.entries(anchorBase))anchors[key].copy(localPoint(...p));
    mesh.visible=loaded&&state.opacity>.001&&state.reveal>.00001;
  }
  const closedContour=[...sourceContour,sourceContour[0]];
  const cumulative=[0];
  for(let i=1;i<closedContour.length;i++)cumulative[i]=cumulative[i-1]+Math.hypot(closedContour[i][0]-closedContour[i-1][0],closedContour[i][1]-closedContour[i-1][1]);
  function sampleContour(count=320){
    count=Math.max(4,Math.round(count));const out=[],total=cumulative.at(-1);let j=1;
    for(let i=0;i<count;i++){
      const distance=total*i/(count-1);while(j<cumulative.length-1&&cumulative[j]<distance)j++;
      const f=(distance-cumulative[j-1])/Math.max(.000001,cumulative[j]-cumulative[j-1]);
      const a=closedContour[j-1],b=closedContour[j];out.push(localPoint(lerp(a[0],b[0],f),lerp(a[1],b[1],f),.015));
    }
    return out;
  }
  const sourceSeams=[
    ['collar-left',[[381,158],[428,204],[499,272],[408,332],[374,267],[381,158]]],
    ['collar-right',[[632,172],[672,235],[705,284],[741,335],[705,306],[676,289]]],
    ['pocket-left',[[310,490],[520,478],[537,684],[521,728],[358,745],[330,718],[310,490]]],
    ['pocket-right',[[680,513],[836,526],[820,713],[801,743],[709,735],[687,708],[680,513]]],
    ['placket',[[518,283],[571,424],[612,617],[619,824],[628,1027],[623,1210],[627,1396]]],
    ['left-cuff',[[181,1114],[223,1091],[306,1074],[357,1091],[409,1158],[342,1217],[249,1263]]],
    ['right-cuff',[[854,1244],[919,1238],[992,1243],[1000,1326],[940,1338],[881,1340]]],
    ['shoulder',[[140,324],[234,266],[319,227],[369,205]]],
  ];
  function sampleConstructionCurves(){
    return sourceSeams.map(([name,points])=>({name,points:points.map(([x,y])=>localPoint((x/1024-.5)*width,(.5-y/1536)*height,.016))}));
  }
  const loader=new THREE.TextureLoader();
  function load(source){
    if(!textureLoads.has(source))textureLoads.set(source,new Promise((resolve,reject)=>{
      loader.load(source,texture=>{
        texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearMipmapLinearFilter;
        texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=true;
        texture.wrapS=texture.wrapT=THREE.ClampToEdgeWrapping;
        texture.anisotropy=4;texture.needsUpdate=true;resolve(texture);
      },undefined,reject);
    }));return textureLoads.get(source);
  }
  const ready=Promise.all([load(hero),load(photoAssets.charcoal??hero),load(photoAssets.khaki??hero)])
    .then(([brown,charcoal,khaki])=>{
      uniforms.uBrown.value=brown;uniforms.uCharcoal.value=charcoal;uniforms.uKhaki.value=khaki;
      uniforms.uTextureSize.value.set(brown.image?.width||1024,brown.image?.height||1536);
      loaded=true;empty.dispose();update();return group;
    });
  const bounds=new THREE.Box3(new THREE.Vector3(-1.15,-1.725,0),new THREE.Vector3(1.15,1.725,.14));
  return{group,mesh,mainMesh:mesh,detailMesh:null,meshes:[mesh],material,uniforms,ready,update,anchors,bounds,
    sampleContour,sampleConstructionCurves,sampleFrontSurface:(x,y)=>localPoint(x,y,0),
    vertexCount:geometry.attributes.position.count,
    get loaded(){return loaded;},
    dispose(){geometry.dispose();material.dispose();if(!loaded)empty.dispose();},
  };
}
