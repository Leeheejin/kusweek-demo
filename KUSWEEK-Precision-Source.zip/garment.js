/* KUSWEEK continuous garment surface. Authored for this demonstration.
 * Units are visual model units; this is not a production cutting pattern.
 * Front faces +Z. All states use this same mesh and its sewn detail surfaces.
 */
export function createGarment(THREE, material) {
  const TAU = Math.PI * 2;
  const clamp = (v, a=0, b=1) => Math.min(b, Math.max(a,v));
  const smooth = (a,b,v) => { const t=clamp((v-a)/(b-a)); return t*t*(3-2*t); };
  const lerp = (a,b,t) => a+(b-a)*t;
  const group = new THREE.Group();
  group.name = 'KUSWEEK — continuous digital garment';
  const surface = material?.surface || material;
  const parts = [];
  const detailParts = [];
  const hardwareParts = [];
  const interiorParts = [];
  const meshes = [];
  const W = .815;

  function patch(fn, nu, nv, flip=false, target=parts) {
    const p=[],uv=[],indices=[];
    for(let j=0;j<=nv;j++) for(let i=0;i<=nu;i++) {
      const s=i/nu,t=j/nv, q=fn(s,t);
      p.push(q[0],q[1],q[2]);
      uv.push(q[3] ?? s,q[4] ?? t);
    }
    for(let j=0;j<nv;j++) for(let i=0;i<nu;i++) {
      const a=j*(nu+1)+i,b=a+1,c=a+nu+1,d=c+1;
      if(flip) indices.push(a,c,b,b,c,d); else indices.push(a,b,c,b,d,c);
    }
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute(p,3));
    geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
    geometry.setIndex(indices); geometry.computeVertexNormals();
    target.push(geometry);
    return geometry;
  }

  const neckTop=(x,back=false)=>{
    const ax=Math.abs(x);
    if(ax<=.255) return 1.36-(back?.02:.22)*Math.sqrt(Math.max(0,1-(ax/.255)**2));
    const q=clamp((ax-.255)/(W-.255));
    return 1.36-.24*q+.019*Math.sin(q*Math.PI);
  };
  const topDepth=(x,back=false)=>{
    const ax=Math.abs(x);
    if(ax<=.255) return (back?.215:.23)*Math.sqrt(Math.max(0,1-(ax/.255)**2));
    const q=clamp((ax-.255)/(W-.255));
    return .175*Math.sin(q*Math.PI);
  };
  const lowerWidth=v=>.765-.040*Math.sin(Math.PI*v)+.050*v;
  const lowerDepth=v=>.213+.039*Math.sin(Math.PI*v)+.062*v;
  const hem=x=>-1.37+.165*Math.pow(clamp(Math.abs(x)/.765),4)
    +.007*Math.sin(9*x+.3)+.0035*Math.sin(19*x-.7);
  const frontWrinkle=(x,y)=>{
    const side=clamp(Math.abs(x)/.78);
    const lower=smooth(.57,-.68,y);
    const ridge=(centre,width)=>Math.exp(-(((x-centre)/width)**2))-.47*Math.exp(-(((x-centre)/(width*2.6))**2));
    // Unequal, gently meandering folds settle below the pockets. Each has a
    // broad trough beside its ridge, instead of a periodic corrugated surface.
    const drape=lower*(
      .033*ridge(-.47+.046*Math.sin(2.1*y+.3),.058)
      +.029*ridge(.51+.036*Math.cos(2.7*y-.4),.066)
      +.019*ridge(-.20+.027*Math.sin(1.9*y+.8),.043)
      +.022*ridge(.245+.022*Math.cos(2.4*y+.7),.048));
    const tensionEnvelope=smooth(.047,.16,Math.abs(x))*(1-smooth(.35,.68,Math.abs(x)));
    const tension=(anchor,width)=>Math.exp(-(((y-anchor+.31*Math.abs(x)+.055*x*x)/width)**2));
    const pull=tensionEnvelope*(.015*tension(.255,.036)-.011*tension(.198,.061)
      +.012*tension(-.435,.041)-.008*tension(-.491,.069));
    const placket=.009*Math.exp(-(((Math.abs(x)-.059)/.021)**2));
    return drape+pull+placket;
  };
  function upperZ(x,v,back=false) {
    const u=clamp(x/W,-1,1), side=Math.abs(u);
    const base=.275*Math.sqrt(Math.max(0,1-u*u));
    const z=lerp(base,topDepth(x,back),v)
      +.245*Math.sin(Math.PI*v)*Math.pow(side,8)
      +.030*Math.sin(Math.PI*v)*(1-side*side);
    const y=lerp(.42,neckTop(x,back),v);
    return z+(back ? .005*Math.sin(13*x+3*y)*Math.sin(3*y) : frontWrinkle(x,y))*(1-v)*(1-Math.pow(side,12));
  }
  function frontZ(x,y) {
    if(y>=.42) return upperZ(x,clamp((y-.42)/(neckTop(x)-.42)));
    const v=clamp((y-hem(x))/(.42-hem(x)));
    return lowerDepth(v)*Math.sqrt(Math.max(0,1-(x/lowerWidth(v))**2))+frontWrinkle(x,y);
  }

  // The front/back torso meet at the side seam. Both sleeves start on the exact
  // curved armhole boundary of the upper torso, rather than intersecting tubes.
  for(const back of [false,true]) {
    const sign=back?-1:1;
    patch((s,t)=>{
      const a=(s-.5)*Math.PI, x=lowerWidth(t)*Math.sin(a);
      let y=lerp(hem(x),.42,t);
      let z=lowerDepth(t)*Math.cos(a);
      const ripples=back?.005*Math.sin(13*x+3*y)*Math.sin(3*y):frontWrinkle(x,y);
      z+=ripples*(1-Math.pow(Math.abs(Math.sin(a)),12));
      return [x,y,sign*z,s*1.75,t*1.87];
    },72,100,back);
    patch((s,t)=>{
      const x=W*Math.sin((s-.5)*Math.PI);
      return [x,lerp(.42,neckTop(x,back),t),sign*upperZ(x,t,back),s*1.75,1.87+t*.94];
    },72,54,back);
  }

  // One softly rolled shoulder bridge on either side of the open neck.
  for(const side of [-1,1]) {
    patch((s,t)=>{
      const x=side*lerp(.255,W,s), z=lerp(-topDepth(x,true),topDepth(x),t);
      const y=lerp(neckTop(x,true),neckTop(x),t)+.012*Math.sin(Math.PI*t)*Math.sin(Math.PI*s);
      return [x,y,z,s*.58,t*.35];
    },32,16,side>0);
  }

  function sleevePoint(side,s,t) {
    const a=s*TAU, ring=(Math.cos(a)+1)/2;
    const orient=smooth(0,.29,t)*1.40;
    const cx=side*(W+.39*(1-Math.exp(-5*t))-.065*t);
    const cy=.77-1.90*t;
    const cap=smooth(0,.26,t);
    const radius=lerp(.35,lerp(.220,.122,clamp(t)),cap);
    const depth=lerp(.245,.112,Math.pow(clamp(t),.65));
    const armholeZ=Math.sign(Math.sin(a))*Math.sin(Math.PI*ring);
    const circularZ=Math.sin(a);
    const ridge=(centre,width)=>Math.exp(-(((t-centre)/width)**2));
    const folds=.010*ridge(.545+.024*Math.cos(a-.4),.029)
      -.006*ridge(.593+.018*Math.cos(a-.2),.048)
      +.006*ridge(.735+.012*Math.cos(a+.7),.025)
      +.004*Math.sin(5*a+.8)*ridge(.885,.057);
    const r=radius+folds;
    const y=cy+Math.cos(orient)*Math.cos(a)*r;
    const x=cx+side*Math.sin(orient)*Math.cos(a)*r;
    const z=depth*lerp(armholeZ,circularZ,smooth(0,.26,t))
      +folds*Math.sin(a)*.72;
    return [x,y,z,s*1.40,t*1.94];
  }
  for(const side of [-1,1]) patch((s,t)=>sleevePoint(side,s,t),72,108,side<0);

  // A raised stand and a continuous folded collar, split only at the real
  // centre-front opening. No disconnected visual panels are introduced.
  const neckPoint=(a)=>{
    const c=Math.cos(a);
    return [.255*Math.sin(a),1.36-.22*Math.max(c,0)-.02*Math.max(-c,0),.23*c];
  };
  // A classic two-leaf turn-down collar. Each front leaf has an actual sharp
  // polygonal point; the back fall remains one smooth arc around the open neck.
  const collarLeaf=(side,s,t)=>{
    const fold=neckPoint(lerp(.165,Math.PI/2,s));
    const ix=fold[0]*1.030,iy=fold[1]+.075,iz=fold[2]*1.026;
    const ox=lerp(.278,.386,s),oy=lerp(1.010,1.295,s),oz=lerp(.320,0,s)+.025*Math.sin(Math.PI*s);
    return[side*lerp(ix,ox,t),lerp(iy,oy,t)+.012*Math.sin(Math.PI*t),lerp(iz,oz,t),s*.43,t*.265];
  };
  const collarBack=(s,t)=>{
    const a=lerp(Math.PI/2,Math.PI*1.5,s),q=neckPoint(a);
    return[lerp(.263,.386,t)*Math.sin(a),q[1]+lerp(.075,-.065,t),lerp(.236,.315,t)*Math.cos(a),s*.79,t*.17];
  };
  patch((s,t)=>{
    const a=lerp(.075,TAU-.075,s),p=neckPoint(a);
    return [p[0]*(1+t*.030),p[1]+t*.075,p[2]*(1+t*.026),s*1.55,t*.075];
  },96,12,false,detailParts);
  for(const side of [-1,1])patch((s,t)=>collarLeaf(side,s,t),38,22,side>0,detailParts);
  patch(collarBack,64,16,true,detailParts);
  // Actual inward-facing collar facing, recessed inside the real opening.
  // The shader receives aInterior=1 only on these inner fabric surfaces.
  patch((s,t)=>{
    const a=s*TAU,q=neckPoint(a),shrink=lerp(.971,.940,t);
    return[q[0]*shrink,q[1]+.065-t*.20,q[2]*shrink,s*1.48,t*.20];
  },96,18,false,interiorParts);

  // Button placket conforms exactly to the continuous front surface.
  patch((s,t)=>{
    const x=(s-.5)*.088,y=lerp(hem(0)+.022,1.155,t);
    return [x,y,frontZ(x,y)+.013+.004*Math.sin(Math.PI*s),s*.088,t*2.57];
  },10,116,false,detailParts);

  const seamCurves=[];
  function seam(points,radius=.0026) {
    if(points.length<2)return;
    const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(p[0],p[1],p[2])));
    const g=new THREE.TubeGeometry(curve,Math.max(20,points.length*2),radius,5,false);
    // Give sewn piping a physical length coordinate as well.
    const uv=g.getAttribute('uv');
    for(let i=0;i<uv.count;i++) uv.setXY(i,uv.getX(i)*curve.getLength(),uv.getY(i)*radius*TAU);
    detailParts.push(g); seamCurves.push(points);
  }
  const curvePoints=(fn,n=48)=>Array.from({length:n+1},(_,i)=>fn(i/n));
  for(const side of [-1,1]){
    seam(curvePoints(s=>collarLeaf(side,s,1),40),.0025);
    seam(curvePoints(t=>collarLeaf(side,0,t),28),.0023);
  }
  seam(curvePoints(s=>collarBack(s,1),64),.0025);
  for(const x of [-.038,.038]) seam(curvePoints(t=>{const y=lerp(hem(x)+.025,1.15,t);return[x,y,frontZ(x,y)+.019];},70),.0020);
  for(const back of [false,true]) {
    const sign=back?-1:1;
    seam(curvePoints(s=>{
      const a=(s-.5)*Math.PI,x=.765*Math.sin(a),y=hem(x)+.020;
      return[x,y,sign*(.213*Math.cos(a)+(back?0:frontWrinkle(x,y))+.003)];
    },80),.0029);
  }

  // Two curved chest pockets: a clean patch pocket and a small pointed flap.
  const pockets=[];
  for(const side of [-1,1]) {
    const pc=side*.397,pw=.344,top=.825,bottom=.302;
    const ppoint=(s,t)=>{
      const x=pc+(s-.5)*pw;
      const round=.052*Math.pow(Math.abs(s-.5)*2,5);
      const y=lerp(bottom+round,top,t);
      const bulge=.013+.017*Math.sin(Math.PI*s)*Math.sin(Math.PI*t);
      return[x,y,frontZ(x,y)+bulge,s*pw,t*.523];
    };
    patch(ppoint,28,34,false,detailParts);
    seam(curvePoints(t=>ppoint(.018,t),28),.0023);
    seam(curvePoints(t=>ppoint(.982,t),28),.0023);
    seam(curvePoints(s=>ppoint(s,.026),32),.0023);
    seam(curvePoints(s=>ppoint(s,.95),32),.0030);
    if(side<0){
      const flap=(s,t)=>{
        const x=pc+(s-.5)*(pw+.012);
        const y=lerp(.858,.705-.045*(1-Math.abs(s*2-1)),t);
        return[x,y,frontZ(x,y)+.032+.014*Math.sin(Math.PI*t),s*.356,t*.16];
      };
      patch(flap,28,12,true,detailParts);
      seam(curvePoints(s=>flap(s,.98),36),.0025);
    }
    pockets.push({side,centre:new THREE.Vector3(pc,.57,frontZ(pc,.57)+.03)});
  }

  // Cuffs follow the same sleeve loft; their rims and openings are visible.
  for(const side of [-1,1]) {
    patch((s,t)=>{
      const q=sleevePoint(side,s,lerp(.923,1.02,t));
      const a=s*TAU;q[0]+=side*.006*Math.cos(a);q[2]+=.006*Math.sin(a);
      return[q[0],q[1],q[2],s*.91,t*.185];
    },72,16,side<0,detailParts);
    patch((s,t)=>{
      const q=sleevePoint(side,s,lerp(.961,1.02,t));
      const a=s*TAU;q[0]-=side*.008*Math.cos(a);q[2]-=.008*Math.sin(a);
      return[q[0],q[1],q[2],s*.80,t*.115];
    },72,14,side>0,interiorParts);
    // A small turned cloth thickness around the genuinely open cuff edge.
    patch((s,t)=>{
      const q=sleevePoint(side,s,1.02),a=s*TAU,delta=lerp(-.008,.006,t);
      q[0]+=side*delta*Math.cos(a);q[2]+=delta*Math.sin(a);
      return[q[0],q[1],q[2],s*.80,t*.014];
    },72,4,side<0,detailParts);
    for(const t of [.931,1.014]) seam(curvePoints(s=>{
      const q=sleevePoint(side,s,t);q[0]+=side*.007*Math.cos(s*TAU);q[2]+=.007*Math.sin(s*TAU);return q;
    },80),.0028);
    // Curved double stitching along the armhole and the sleeve under seam.
    seam(curvePoints(s=>sleevePoint(side,s,.006),88),.0028);
    seam(curvePoints(t=>sleevePoint(side,.48,t*.93),80),.0022);
  }

  // Back yoke seam, shoulder topstitching, and centre-front fastening.
  seam(curvePoints(s=>{ const x=lerp(-.735,.735,s),v=.72;return[x,lerp(.42,neckTop(x,true),v),-upperZ(x,v,true)-.004]; },72),.0025);
  for(const side of [-1,1]) seam(curvePoints(s=>{
    const x=side*lerp(.265,.808,s);
    return[x,neckTop(x)+.003,topDepth(x)+.002];
  },40),.0024);

  function addButton(x,y,r=.022) {
    const z=frontZ(x,y)+.032;
    const disk=new THREE.CylinderGeometry(r,r,.009,24,1);
    disk.rotateX(Math.PI/2);disk.translate(x,y,z);hardwareParts.push(disk);
    const rim=new THREE.TorusGeometry(r*.84,.0022,5,24);
    rim.translate(x,y,z+.006);hardwareParts.push(rim);
  }
  for(const y of [.945,.60,.255,-.09,-.435,-.78,-1.125]) addButton(.001,y);
  addButton(-.397,.737,.017);

  function merged(geos) {
    let count=0,indexCount=0;
    for(const g of geos){count+=g.getAttribute('position').count;indexCount+=g.index?g.index.count:g.getAttribute('position').count;}
    const pos=new Float32Array(count*3),norm=new Float32Array(count*3),uv=new Float32Array(count*2),ind=new Uint32Array(indexCount);
    let offset=0,io=0;
    for(const g of geos){
      const p=g.getAttribute('position'),n=g.getAttribute('normal'),t=g.getAttribute('uv');
      pos.set(p.array,offset*3);norm.set(n.array,offset*3);uv.set(t.array,offset*2);
      if(g.index)for(let j=0;j<g.index.count;j++)ind[io++]=g.index.array[j]+offset;
      else for(let j=0;j<p.count;j++)ind[io++]=j+offset;
      offset+=p.count;g.dispose();
    }
    const g=new THREE.BufferGeometry();
    g.setAttribute('position',new THREE.BufferAttribute(pos,3));
    g.setAttribute('normal',new THREE.BufferAttribute(norm,3));
    g.setAttribute('uv',new THREE.BufferAttribute(uv,2));
    g.setIndex(new THREE.BufferAttribute(ind,1));
    g.computeBoundingBox();g.computeBoundingSphere();
    return g;
  }
  function smoothSewnNormals(geometry) {
    const pos=geometry.getAttribute('position'),normal=geometry.getAttribute('normal');
    const groups=new Map();
    for(let i=0;i<pos.count;i++){
      const key=[pos.getX(i),pos.getY(i),pos.getZ(i)].map(v=>Math.round(v*100000)).join('/');
      let record=groups.get(key);
      if(!record){record={x:0,y:0,z:0,ids:[]};groups.set(key,record);}
      record.x+=normal.getX(i);record.y+=normal.getY(i);record.z+=normal.getZ(i);record.ids.push(i);
    }
    for(const q of groups.values()){
      if(q.ids.length<2)continue;
      const length=Math.hypot(q.x,q.y,q.z);
      if(length<1e-8)continue;
      for(const i of q.ids)normal.setXYZ(i,q.x/length,q.y/length,q.z/length);
    }
    normal.needsUpdate=true;
  }
  function clothMesh(geos,name,mat=surface,weldNormals=false,interior=false) {
    const mesh=new THREE.Mesh(merged(geos),mat);mesh.name=name;
    if(weldNormals)smoothSewnNormals(mesh.geometry);
    mesh.castShadow=true;mesh.receiveShadow=true;
    mesh.userData.basePositions=mesh.geometry.getAttribute('position').array.slice();
    mesh.userData.baseNormals=mesh.geometry.getAttribute('normal').array.slice();
    const base=mesh.userData.basePositions,weights=new Float32Array(base.length/3*7);
    mesh.geometry.setAttribute('aInterior',new THREE.Float32BufferAttribute(new Float32Array(base.length/3).fill(interior?1:0),1));
    for(let i=0;i<base.length/3;i++){
      const x=base[i*3],y=base[i*3+1],z=base[i*3+2];
      const body=1-smooth(.68,1.25,Math.abs(x));
      weights[i*7]=.075*(.48+.52*body);
      weights[i*7+1]=.24*smooth(.35,-1.40,y)*body;
      weights[i*7+2]=.27*smooth(.70,1.05,Math.abs(x))*smooth(.65,-.85,y);
      weights[i*7+3]=.019*Math.exp(-(((Math.abs(x)-.397)/.175)**4))*Math.exp(-(((y-.62)/.28)**4))*smooth(.10,.23,z);
      const d=materialDisplacement(x,y,z);
      weights[i*7+4]=d[0];weights[i*7+5]=d[1];weights[i*7+6]=d[2];
    }
    mesh.userData.morphWeights=weights;
    mesh.geometry.getAttribute('position').setUsage(THREE.DynamicDrawUsage);
    mesh.geometry.getAttribute('normal').setUsage(THREE.DynamicDrawUsage);
    group.add(mesh);meshes.push(mesh);return mesh;
  }
  const mainMesh=clothMesh(parts,'Continuous shirt surface — body, shoulders and sleeves',surface,true);
  const detailMesh=clothMesh(detailParts,'Sewn construction — collar, placket, pockets, cuffs and hems');
  const hardwareMaterial=material?.hardware || surface;
  const hardwareMesh=clothMesh(hardwareParts,'Button fastenings',hardwareMaterial);
  const interiorMesh=clothMesh(interiorParts,'Inner neck facing and open cuff interiors',surface,false,true);

  const anchors={
    fit:new THREE.Vector3(.72,.10,.25),
    length:new THREE.Vector3(.0,hem(0),.22),
    sleeve:new THREE.Vector3(1.17,-.91,.135),
    detail:new THREE.Vector3(-.397,.735,frontZ(-.397,.735)+.04),
    collar:new THREE.Vector3(.02,1.32,.26),
    shoulderLeft:new THREE.Vector3(-.78,1.12,.0),
    shoulderRight:new THREE.Vector3(.78,1.12,.0),
    chestLeft:new THREE.Vector3(-.788,.08,.085),
    chestRight:new THREE.Vector3(.788,.08,.085),
    hem:new THREE.Vector3(.74,-1.35,.13),
  };
  const baseAnchors=Object.fromEntries(Object.entries(anchors).map(([key,v])=>[key,v.clone()]));
  let last='';
  let currentState={fit:0,length:0,sleeve:0,flat:0,detail:1,materialDrape:0};
  function materialDisplacement(x,y,z) {
    const body=1-smooth(.68,1.15,Math.abs(x)),fall=smooth(.52,-1.30,y);
    return[-Math.sign(x)*.005*body*fall,-.016*body*fall,.32*frontWrinkle(x,y)*smooth(.06,.21,z)*body];
  }
  function deform(x,y,z,fit,length,sleeve,flat,detail,materialDrape=0) {
    // One smooth field deforms every attached surface together.
    const bodyWeight=1-smooth(.68,1.25,Math.abs(x));
    const lower=smooth(.35,-1.40,y);
    const sleeveWeight=smooth(.70,1.05,Math.abs(x))*smooth(.65,-.85,y);
    const d=materialDisplacement(x,y,z);
    const ny=y-length*.24*lower*bodyWeight-sleeve*.27*sleeveWeight+materialDrape*d[1];
    const nx=x*(1+fit*.075*(.48+.52*bodyWeight))+materialDrape*d[0];
    // A continuous shallow relief field rolls the pocket welts and eases the
    // cloth underneath them. Attached seams and pocket surfaces move together.
    const pocketRelief=Math.exp(-(((Math.abs(x)-.397)/.175)**4))*Math.exp(-(((y-.62)/.28)**4))*smooth(.10,.23,z);
    const nz=z*(1+fit*.055)+(detail-1)*.019*pocketRelief+materialDrape*d[2];
    return[nx,ny,lerp(nz,Math.sign(nz)*.006,flat)];
  }
  function update({fit=0,length=0,sleeve=0,flat=0,detail=1,materialDrape=0,time=0}={}) {
    fit=clamp(fit,-1,1.5);length=clamp(length,-1,1);sleeve=clamp(sleeve,-1,1);flat=clamp(flat);
    materialDrape=clamp(materialDrape);
    currentState={fit,length,sleeve,flat,detail,materialDrape};
    const key=[fit,length,sleeve,flat,detail,materialDrape].map(v=>v.toFixed(5)).join('/');
    if(key===last)return;
    last=key;
    for(const mesh of meshes){
      const p=mesh.geometry.getAttribute('position'),n=mesh.geometry.getAttribute('normal');
      const base=mesh.userData.basePositions, bn=mesh.userData.baseNormals,weights=mesh.userData.morphWeights;
      for(let i=0;i<p.count;i++){
        const k=i*3,j=i*7;
        const z=base[k+2]*(1+fit*.055)+(detail-1)*weights[j+3]+materialDrape*weights[j+6];
        p.array[k]=base[k]*(1+fit*weights[j])+materialDrape*weights[j+4];
        p.array[k+1]=base[k+1]-length*weights[j+1]-sleeve*weights[j+2]+materialDrape*weights[j+5];
        p.array[k+2]=lerp(z,Math.sign(z)*.006,flat);
        // Inverse-transpose approximation to the gentle deformation field.
        let nx=bn[k]/(1+fit*.075),ny=bn[k+1],nz=bn[k+2]/Math.max(.008,1-flat);
        const d=1/Math.max(.00001,Math.hypot(nx,ny,nz));
        n.array[k]=nx*d;n.array[k+1]=ny*d;n.array[k+2]=nz*d;
      }
      p.needsUpdate=true;n.needsUpdate=true;
      mesh.geometry.computeBoundingBox();mesh.geometry.computeBoundingSphere();
    }
    for(const [key,v]of Object.entries(anchors)){
      const b=baseAnchors[key],q=deform(b.x,b.y,b.z,fit,length,sleeve,flat,detail,materialDrape);v.set(...q);
    }
    detailMesh.visible=true;hardwareMesh.visible=true;
  }
  update();
  const localPoint=q=>{
    const s=currentState;
    return new THREE.Vector3(...deform(q[0],q[1],q[2],s.fit,s.length,s.sleeve,s.flat,s.detail,s.materialDrape));
  };
  function outlinePoints() {
    const out=[];
    const add=(fn,n=40)=>{for(let i=0;i<n;i++){const q=fn(i/n);out.push([q[0],q[1],q[2]+.010]);}};
    add(t=>{const x=.255*t;return[x,neckTop(x),topDepth(x)];},24);
    add(t=>{const x=lerp(.255,W,t);return[x,neckTop(x),topDepth(x)];},40);
    add(t=>sleevePoint(1,0,t*1.02),70);
    add(t=>sleevePoint(1,t*.5,1.02),32);
    add(t=>sleevePoint(1,.5,(1-t)*1.02),70);
    add(t=>{const v=1-t,x=lowerWidth(v);return[x,lerp(hem(x),.42,v),0];},55);
    add(t=>{const a=lerp(Math.PI/2,-Math.PI/2,t),x=.765*Math.sin(a);return[x,hem(x),.213*Math.cos(a)+frontWrinkle(x,hem(x))*(1-Math.pow(Math.abs(Math.sin(a)),12))];},80);
    add(t=>{const x=-lowerWidth(t);return[x,lerp(hem(x),.42,t),0];},55);
    add(t=>sleevePoint(-1,.5,t*1.02),70);
    add(t=>sleevePoint(-1,(1-t)*.5,1.02),32);
    add(t=>sleevePoint(-1,0,(1-t)*1.02),70);
    add(t=>{const x=-lerp(W,.255,t);return[x,neckTop(x),topDepth(x)];},40);
    add(t=>{const x=-.255*(1-t);return[x,neckTop(x),topDepth(x)];},24);
    out.push(out[0].slice());return out;
  }
  const outline=outlinePoints();
  const outlineLengths=[0];
  for(let i=1;i<outline.length;i++)outlineLengths[i]=outlineLengths[i-1]+Math.hypot(...outline[i].map((v,j)=>v-outline[i-1][j]));
  function sampleContour(count=320) {
    const total=outlineLengths.at(-1),out=[];let j=1;
    for(let i=0;i<count;i++){
      const d=total*i/(count-1);while(j<outline.length-1&&outlineLengths[j]<d)j++;
      const t=(d-outlineLengths[j-1])/Math.max(1e-8,outlineLengths[j]-outlineLengths[j-1]);
      out.push(localPoint(outline[j-1].map((v,k)=>lerp(v,outline[j][k],t))));
    }
    return out;
  }
  function sampleConstructionCurves() {
    return seamCurves.map((points,index)=>({name:`sewn-construction-${index}`,points:points.map(localPoint)}));
  }
  const bounds=new THREE.Box3(new THREE.Vector3(-1.5,-1.53,-.36),new THREE.Vector3(1.5,1.53,.49));
  return {group,mainMesh,detailMesh,hardwareMesh,interiorMesh,hardwareMaterial,meshes,update,bounds,anchors,pockets,
    sampleContour,sampleConstructionCurves,
    sampleFrontSurface(x,y){return localPoint([x,y,frontZ(x,y)]);},
    vertexCount:meshes.reduce((sum,m)=>sum+m.geometry.attributes.position.count,0),
    silhouette:sampleContour(320).map(v=>v.toArray()),
    dispose(){for(const mesh of meshes)mesh.geometry.dispose();},
  };
}
