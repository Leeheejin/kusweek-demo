import * as THREE from './vendor/three.module.js';
import {images} from './embedded.js';
import {cadMarkup} from './cad-art.js';

// A single reversible scroll clock. No time-based loops, springs, or independently
// animated cursors: holding scroll always holds the exact composition.
const clamp=(n,a=0,b=1)=>Math.min(b,Math.max(a,n));
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t)};
const mix=(a,b,t)=>a+(b-a)*t;
const win=(p,a,b,c,d)=>smooth(a,b,p)*(1-smooth(c,d,p));
const $=s=>document.querySelector(s);
const stage=$('#stage'),journey=$('#journey'),canvas=$('#world');
const cad=$('#cad');
cad.innerHTML=`<defs><clipPath id="cadSweep"><rect id="cadClip" x="-30" y="-80" width="0" height="1060"/></clipPath><linearGradient id="beamWash" x1="0" x2="1"><stop stop-color="#3cceff" stop-opacity="0"/><stop offset="1" stop-color="#75e8ff" stop-opacity=".11"/></linearGradient><filter id="beamGlow" x="-2000%" width="4100%"><feGaussianBlur stdDeviation="4"/></filter></defs><g id="cadInk" clip-path="url(#cadSweep)">${cadMarkup()}</g><g id="cadBeam"><rect x="-88" y="0" width="88" height="900" fill="url(#beamWash)"/><path d="M0 5V895" stroke="#6fdcff" stroke-width="8" opacity=".22" filter="url(#beamGlow)"/><path d="M0 5V895" stroke="#bef4ff" stroke-width="1.5"/></g>`;
const stages=[
 {a:0,b:.12,num:'01',name:'생각의 시작',eyebrow:'THE POSSIBILITY',title:'생각이 설계가 되고,<br><span>설계가 옷이 됩니다.</span>',description:'아직 말로 다 설명하지 못한 한 벌.<br>가상샘플을 보며, 함께 구체화합니다.',layout:'hero'},
 {a:.12,b:.29,num:'02',name:'취향을 구체화',eyebrow:'MAKE IT YOURS',title:'“조금 더 여유롭게.”<br><span>말이 형태가 됩니다.</span>',description:'AI가 고객의 언어를 핏·기장·소매·디테일로 정리합니다.<br>제안을 보며, 원하는 한 벌에 가까워집니다.',layout:'hero'},
 {a:.29,b:.41,num:'03',name:'시안을 비교',eyebrow:'EXPLORE THE POSSIBILITIES',title:'같은 생각에서,<br><span>다른 가능성으로.</span>',description:'서로 다른 실루엣을 비교하고, 하나의 방향을 함께 정합니다.',layout:'wide'},
 {a:.41,b:.52,num:'04',name:'사양을 정의',eyebrow:'DEFINE THE STANDARD',title:'막연한 취향이,<br><span>분명한 기준으로.</span>',description:'핏과 디테일에 치수를 연결합니다.<br>함께 정한 사양이 설계의 기준이 됩니다.',layout:'hero'},
 {a:.52,b:.72,num:'05',name:'정밀하게 설계',eyebrow:'FROM INTENT TO PRECISION',title:'한 벌을 만드는, <em>정확한 선.</em>',description:'외곽선에서 봉제선, 시접과 치수까지.<br>축적된 CAD 자산과 패턴 전문가의 판단으로.',layout:'cad'},
 {a:.72,b:.83,num:'06',name:'설계에서 샘플로',eyebrow:'ONE DESIGN. CONTINUOUSLY.',title:'설계의 선이,<br><span>한 벌의 형태로.</span>',description:'함께 정한 사양을 바탕으로,<br>가상샘플에서 형태를 검토합니다.',layout:'hero'},
 {a:.83,b:.945,num:'07',name:'소재와 컬러 검토',eyebrow:'GIVE IT CHARACTER',title:'마침내,<br><span>원단의 감각까지.</span>',description:'빛에 드러나는 표면, 자연스럽게 잡히는 주름.<br>컬러와 소재의 방향을 화면에서 먼저 살펴봅니다.',layout:'final'},
 {a:.945,b:1.01,num:'08',name:'제작으로 연결',eyebrow:'THOUGHT. DESIGNED. MADE.',title:'당신의 생각이,<br><span>한 벌의 기준이 되다.</span>',description:'고객과 함께 정한 디자인.<br>실물 검증을 거쳐, 제작으로 이어집니다.',layout:'final'}
];
let width=0,height=0,mobile=false,progress=0,lastChapter=-1,lastP=-10;
let renderer,scene,camera,garments=[],ribbon,ribbonGlow,lightPlane,photoContour=[];

// Derive a clean optical outline from the supplied concept image. This gives
// the CAD handoff the same visible silhouette instead of cutting to a new icon.
function opticalContour(image){
 const c=document.createElement('canvas');c.width=256;c.height=384;
 const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0,256,384);
 const data=ctx.getImageData(0,0,256,384).data,edges=new Map();
 const on=(x,y)=>x>=0&&y>=0&&x<256&&y<384&&data[(y*256+x)*4+3]>210;
 const add=(x,y,xx,yy)=>edges.set(x+','+y,[xx,yy]);
 for(let y=0;y<384;y++)for(let x=0;x<256;x++)if(on(x,y)){
  if(!on(x,y-1))add(x,y,x+1,y);
  if(!on(x+1,y))add(x+1,y,x+1,y+1);
  if(!on(x,y+1))add(x+1,y+1,x,y+1);
  if(!on(x-1,y))add(x,y+1,x,y);
 }
 let longest=[];
 while(edges.size){let start=edges.keys().next().value,key=start,loop=[],guard=0;
  while(edges.has(key)&&guard++<10000){const [x,y]=key.split(',').map(Number);loop.push([x/256,y/384]);const next=edges.get(key);edges.delete(key);key=next.join(',');if(key===start)break;}
  if(loop.length>longest.length)longest=loop;
 }
 const cumulative=[0];for(let i=1;i<=longest.length;i++){const a=longest[i-1],b=longest[i%longest.length];cumulative.push(cumulative.at(-1)+Math.hypot(b[0]-a[0],b[1]-a[1]));}
 const out=[];let index=0;for(let i=0;i<240;i++){const d=cumulative.at(-1)*i/240;while(cumulative[index+1]<d)index++;const a=longest[index],b=longest[(index+1)%longest.length],t=(d-cumulative[index])/(cumulative[index+1]-cumulative[index]);out.push([mix(a[0],b[0],t),mix(a[1],b[1],t)]);}
 return out;
}

const vertex=`
varying vec2 vUv;
uniform float uFit,uLength,uSleeve;
void main(){
 vUv=uv;vec3 p=position;
 float chest=exp(-pow((uv.y-.52)*3.4,2.));
 float sleeve=smoothstep(.20,.38,abs(uv.x-.5));
 p.x*=1.+uFit*.13*chest;
 p.y-=uLength*.065*(1.-smoothstep(.08,.5,uv.y));
 p.y+=uSleeve*.075*sleeve*(1.-smoothstep(.12,.65,uv.y));
 gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);
}`;
const fragment=`
precision highp float;
varying vec2 vUv;
uniform sampler2D uImage,uKhaki,uCharcoal,uSmooth;
uniform float uWire,uReveal,uPhoto,uColor,uOpacity,uGrid,uDetail;
float kwLum(vec3 v){return dot(v,vec3(.299,.587,.114));}
void main(){
 vec2 uv=vUv;vec4 src=texture2D(uImage,uv);
 if(src.a<.025)discard;
 vec3 cloth=src.rgb;
 if(uColor<1.)cloth=mix(cloth,texture2D(uKhaki,uv).rgb,uColor);
 else cloth=mix(texture2D(uKhaki,uv).rgb,texture2D(uCharcoal,uv).rgb,uColor-1.);
 float l=kwLum(src.rgb);
 float sm=kwLum(texture2D(uSmooth,uv).rgb);
 vec2 px=vec2(1./1024.,1./1536.);
 float ax=texture2D(uImage,uv+vec2(px.x*1.5,0.)).a-texture2D(uImage,uv-vec2(px.x*1.5,0.)).a;
 float ay=texture2D(uImage,uv+vec2(0.,px.y*1.5)).a-texture2D(uImage,uv-vec2(0.,px.y*1.5)).a;
 float edge=clamp(length(vec2(ax,ay))*1.5,0.,1.);
 float sx=kwLum(texture2D(uSmooth,uv+vec2(px.x*6.,0.)).rgb)-kwLum(texture2D(uSmooth,uv-vec2(px.x*6.,0.)).rgb);
 float sy=kwLum(texture2D(uSmooth,uv+vec2(0.,px.y*6.)).rgb)-kwLum(texture2D(uSmooth,uv-vec2(0.,px.y*6.)).rgb);
 vec2 g=vec2(uv.x*64.+sm*1.3+sin(uv.y*7.)*.5,uv.y*94.+sm*1.2);
 vec2 fw=max(fwidth(g),vec2(.001));
 vec2 d=abs(fract(g-.5)-.5)/fw;
 float grid=1.-smoothstep(.10,.8,min(d.x,d.y));
 float structure=clamp(length(vec2(sx,sy))*4.,0.,.5);
 float detail=clamp(abs(l-sm)*6.,0.,.45);
 vec3 base=vec3(.009,.036,.058)*(1.+sm*2.);
 vec3 tech=base+vec3(.30,.73,.94)*(grid*(.18+sm*.85)*uGrid+edge*.67+structure*.44+detail*.20*uDetail);
 float y=1.-uv.y;
 float formed=.40+.60*(1.-smoothstep(uReveal-.007,uReveal+.01,y));
 float scan=exp(-pow((y-uReveal)*190.,2.))*step(.001,uReveal)*step(uReveal,.999);
 tech+=vec3(.44,.91,1.)*scan*.9;
 float real=1.-smoothstep(uPhoto-.006,uPhoto+.006,uv.x);
 float photon=exp(-pow((uv.x-uPhoto)*170.,2.))*step(.001,uPhoto)*step(uPhoto,.999);
 vec3 color=mix(tech,cloth,real);
 color+=vec3(.36,.9,1.)*photon*.6;
 gl_FragColor=vec4(color,src.a*uOpacity*formed);
}`;

async function init(){
 try{
  renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));
  scene=new THREE.Scene();camera=new THREE.OrthographicCamera(0,1,1,0,-100,100);camera.position.z=10;
  const loader=new THREE.TextureLoader();
  const [hero,khaki,charcoal]=await Promise.all(['hero','khaki','charcoal'].map(n=>loader.loadAsync(images[n])));
  photoContour=opticalContour(hero.image);
  for(const texture of [hero,khaki,charcoal]){texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;}
  const smoothCanvas=document.createElement('canvas');smoothCanvas.width=512;smoothCanvas.height=768;
  const ctx=smoothCanvas.getContext('2d');ctx.filter='blur(5px)';ctx.drawImage(hero.image,0,0,512,768);
  const blur=new THREE.CanvasTexture(smoothCanvas);
  const geometry=new THREE.PlaneGeometry(1,1,60,90);
  for(let i=0;i<3;i++){
   const material=new THREE.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,transparent:true,depthWrite:false,uniforms:{uImage:{value:hero},uKhaki:{value:khaki},uCharcoal:{value:charcoal},uSmooth:{value:blur},uFit:{value:0},uLength:{value:0},uSleeve:{value:0},uWire:{value:1},uReveal:{value:1},uPhoto:{value:0},uColor:{value:0},uOpacity:{value:1},uGrid:{value:1},uDetail:{value:1}}});
   const mesh=new THREE.Mesh(geometry,material);mesh.renderOrder=i===1?3:2;scene.add(mesh);garments.push(mesh);
  }
  const lineGeom=new THREE.BufferGeometry();lineGeom.setAttribute('position',new THREE.BufferAttribute(new Float32Array(260*3),3));
  ribbon=new THREE.Line(lineGeom,new THREE.LineBasicMaterial({color:0xb9efff,transparent:true,opacity:.9}));scene.add(ribbon);
  ribbonGlow=new THREE.Line(lineGeom.clone(),new THREE.LineBasicMaterial({color:0x297caf,transparent:true,opacity:.35}));scene.add(ribbonGlow);
  const scanMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uOpacity:{value:0}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec2 vUv;uniform float uOpacity;void main(){float d=abs(vUv.y-.5);float a=exp(-d*35.)*.12+exp(-d*600.);float x=smoothstep(0.,.15,vUv.x)*(1.-smoothstep(.85,1.,vUv.x));gl_FragColor=vec4(.43,.85,1.,a*x*uOpacity);}'});
  lightPlane=new THREE.Mesh(new THREE.PlaneGeometry(1,1),scanMat);lightPlane.renderOrder=5;scene.add(lightPlane);
  resize();stage.dataset.ready='true';tick();
 }catch(error){$('#fallback').hidden=false;console.error('KUSWEEK renderer:',error);}
}

function resize(){
 width=stage.clientWidth||innerWidth;height=stage.clientHeight;mobile=width<=900;
 if(renderer){renderer.setSize(width,height,false);camera.right=width;camera.top=height;camera.updateProjectionMatrix();}
 lastP=-10;
}
function place(mesh,x,y,h,opacity,fit=0,length=0,sleeve=0){
 mesh.position.set(x,height-y,0);mesh.scale.set(h*2/3,h,1);mesh.visible=opacity>.001;
 const u=mesh.material.uniforms;u.uOpacity.value=opacity;u.uFit.value=fit;u.uLength.value=length;u.uSleeve.value=sleeve;
 return {x,y,h,w:h*2/3};
}
function label(pin,text,small,side,offsetX,offsetY,opacity){
 if(opacity<.02)return;
 const endX=pin.x+offsetX,endY=pin.y+offsetY;
 let anchor=side==='left'?'right':'left';
 const dom=document.createElement('div');dom.innerHTML=`<small>${small}</small><b>${text}</b>`;
 dom.style.opacity=opacity;dom.style.left=endX+'px';dom.style.top=endY+'px';if(anchor==='right')dom.style.transform='translate(-100%,-100%)';
 $('#callouts').append(dom);
 const tail=side==='left'?-90:90;
 $('#connectors').insertAdjacentHTML('beforeend',`<path opacity="${opacity*.65}" d="M${pin.x},${pin.y}L${endX},${endY}H${endX+tail}"/><circle opacity="${opacity}" cx="${pin.x}" cy="${pin.y}" r="2"/>`);
}
function applyChapter(p){
 const id=stages.findIndex(s=>p>=s.a&&p<s.b),s=stages[Math.max(0,id)];
 if(id!==lastChapter){
  $('#headline').innerHTML=s.title;$('#eyebrow').textContent=s.num+' — '+s.eyebrow;$('#description').innerHTML=s.description;
  $('#chapter-number').textContent=s.num;$('#chapter-name').textContent=s.name;stage.dataset.layout=s.layout;lastChapter=id;
 }
 // Quiet reading rests separated by short dissolves; position isn't reset by a timer.
 let opacity=id===0?1:smooth(s.a,s.a+.012,p);opacity*=1-smooth(s.b-.013,s.b,p);
 $('#copy').style.opacity=opacity;$('#copy').style.transform=`translateY(${(1-opacity)*12}px)`;
 $('#track-fill').style.transform=`scaleX(${p})`;
}
function render(p){
 applyChapter(p);
 const spread=smooth(.272,.312,p)*(1-smooth(.37,.416,p));
 const cadEnter=smooth(.515,.548,p),cadLeave=smooth(.717,.76,p),cadAmount=cadEnter*(1-cadLeave);
 // The sample reaches its final screen position before the material front
 // moves. Translating the garment during a mask sweep can reverse that front.
 const final=smooth(.756,.782,p);
 let centerX=mobile?width*.59:width*.682;
 let centerY=mobile?height*.615:height*.495;
 let modelH=mobile?Math.min(height*.57,width*.92):height*.91;
 // During comparison the entire composition recenters as one stable group.
 centerX=mix(centerX,width*.5,spread);
 centerY=mix(centerY,mobile?height*.57:height*.615,spread);
 modelH=mix(modelH,mobile?width*.47:height*.52,spread);
 centerX=mix(centerX,mobile?width*.5:width*.545,final);
 centerY=mix(centerY,mobile?height*.56:height*.51,final);
 modelH=mix(modelH,mobile?Math.min(height*.56,width*1.05):height*.9,final);
 const fit=smooth(.146,.19,p)-smooth(.398,.43,p)*.6;
 const length=smooth(.19,.225,p)*(1-smooth(.4,.43,p));
 const sleeve=smooth(.23,.265,p)*(1-smooth(.4,.43,p));
 const reveal=mix(.39,1,smooth(0,.095,p));
 const photo=smooth(.785,.85,p);
 const color=1*smooth(.858,.887,p)+1*smooth(.89,.916,p)-2*smooth(.924,.947,p);
 const alpha=(1-smooth(.53,.573,p)) + smooth(.735,.775,p);
 for(let i=0;i<3;i++){
  let dis=i-1;
  const stagger=dis<0?0:.007;
  const collapse=smooth(.373+stagger,.409+stagger,p);
  const localSpread=smooth(.278+Math.abs(dis)*.008,.31+Math.abs(dis)*.008,p)*(1-collapse);
  let x=centerX+dis*width*(mobile?.305:.284)*localSpread;
  let y=centerY-Math.sin(collapse*Math.PI)*height*.06*Math.abs(dis);
  let o=i===1?alpha:localSpread*alpha*.68;
  const h=modelH*(i===1?1:.91);
  place(garments[i],x,y,h,o,fit+(i-1)*.65*spread,length+(i-1)*.65*spread,sleeve);
  const u=garments[i].material.uniforms;u.uReveal.value=reveal;u.uPhoto.value=photo;u.uColor.value=color;u.uGrid.value=mix(1,.7,spread);u.uDetail.value=1;
 }
 // The opening line is an open, descending curve. It settles into a garment
 // scan boundary; its draw range only grows while scrolling down.
 const curveOpacity=(1-smooth(.08,.115,p));
 ribbon.visible=curveOpacity>.001;ribbonGlow.visible=ribbon.visible;
 if(ribbon.visible){
  const position=ribbon.geometry.attributes.position;
  for(let i=0;i<260;i++){
   const v=.04+.92*i/259;
   const xx=centerX+modelH*(.02+.10*v+.01*Math.sin(v*Math.PI))*2/3;
   const yy=centerY+(v-.5)*modelH;
   position.setXYZ(i,xx,height-yy,5);
  }
  position.needsUpdate=true;ribbon.geometry.setDrawRange(0,Math.floor(clamp((reveal-.04)/.92)*260));ribbon.material.opacity=curveOpacity*.9;
  ribbonGlow.geometry.attributes.position.array.set(position.array);ribbonGlow.geometry.attributes.position.needsUpdate=true;ribbonGlow.geometry.setDrawRange(0,ribbon.geometry.drawRange.count);ribbonGlow.position.x=1.2;ribbonGlow.material.opacity=curveOpacity*.18;
 }
 // A broad, crisp sweep is attached to the data being revealed, not an
 // unrelated wandering comet. Its Y only increases through this scan.
 const measureScan=win(p,.417,.43,.495,.515);
 const measureY=mix(centerY-modelH*.42,centerY+modelH*.41,smooth(.423,.503,p));
 lightPlane.visible=measureScan>.001;lightPlane.position.set(centerX,height-measureY,9);lightPlane.scale.set(modelH*.91,65,1);lightPlane.material.uniforms.uOpacity.value=measureScan*.65;
 const drawing=$('#drawing');drawing.style.opacity=cadAmount;
 const slide=mix(35,0,cadEnter)+mix(0,-30,cadLeave);
 const scale=mix(.85,1,cadEnter)*mix(1,.88,cadLeave);
 drawing.style.transform=`translateY(${slide}px) scale(${scale})`;
 // Transfer the intact contour to and from the drafting plane. The outline
 // itself deforms; no pattern islands fly in and no camera cut hides the handoff.
 const bridgeIn=win(p,.499,.515,.563,.58),bridgeOut=win(p,.71,.727,.778,.79);
 const bridgeAlpha=Math.max(bridgeIn,bridgeOut);
 $('#form-bridge').style.opacity=bridgeAlpha;
 if(bridgeAlpha>.001&&photoContour.length){
  const shape=cad.querySelector('[data-layer="outline"] path');
  const length=shape.getTotalLength(),matrix=shape.getScreenCTM();
  const blend=bridgeIn>bridgeOut?smooth(.514,.563,p):1-smooth(.727,.778,p);
  const points=photoContour.map(([u,v],i)=>{
   const q=shape.getPointAtLength(length*i/photoContour.length);
   const tx=matrix.a*q.x+matrix.c*q.y+matrix.e,ty=matrix.b*q.x+matrix.d*q.y+matrix.f;
   return [mix(centerX+(u-.5)*modelH*2/3,tx,blend),mix(centerY+(v-.5)*modelH,ty,blend)];
  });
  const path=points.map((point,i)=>(i?'L':'M')+point[0].toFixed(2)+','+point[1].toFixed(2)).join('')+'Z';
  $('#form-bridge-line').setAttribute('d',path);$('#form-bridge-glow').setAttribute('d',path);
 }
 const ink=smooth(.552,.685,p),sweepX=mix(-30,1250,ink);
 $('#cadClip').setAttribute('width',String(sweepX+30));$('#cadBeam').setAttribute('transform',`translate(${sweepX},0)`);
 $('#cadBeam').style.opacity=String(win(p,.551,.56,.684,.696));
 // Drafting line classes resolve in order behind the same optical front.
 const layerTimes={construction:[.544,.564],outline:[.562,.604],seam:[.606,.638],allowance:[.631,.662],dimension:[.66,.69]};
 for(const [layer,[a,b]] of Object.entries(layerTimes)){
  const group=cad.querySelectorAll(`[data-layer="${layer}"]`);for(const el of group)el.style.opacity=String(smooth(a,b,p)*(layer==='construction'?.42:1));
 }
 $('#draft-phase').textContent=p<.59?'01 / OUTLINE':p<.637?'02 / STITCH LINE':p<.66?'03 / SEAM ALLOWANCE':'04 / DIMENSION & REVIEW';
 // Labels are attached to garment coordinates and are only shown at their
 // corresponding inspection stage. No random telemetry or floating HUD.
 $('#connectors').innerHTML='';$('#callouts').innerHTML='';
 const point=(u,v)=>({x:centerX+(u-.5)*modelH*2/3,y:centerY+(v-.5)*modelH});
 const usable=1-spread;
 const ox=mobile?width*.1:width*.09;
 label(point(.23,.37),'여유 있는 핏','FIT / RELAXED','left',-ox,-10,win(p,.14,.151,.191,.204)*usable);
 label(point(.66,.87),'가볍게 걸치는 기장','LENGTH / OUTER SHIRT','right',ox*.25,-8,win(p,.199,.21,.232,.245)*usable);
 label(point(.87,.67),'소매의 비율 조정','SLEEVE / BALANCE','right',ox*.2,-35,win(p,.233,.243,.271,.28)*usable);
 label(point(.76,.41),'실용적인 포켓 구조','DETAIL / UTILITY','right',ox*.18,-10,win(p,.265,.273,.285,.294)*usable);
 const mAlpha=win(p,.425,.436,.506,.524);
 label(point(.27,.24),'<strong>48</strong> cm','어깨 · 기존 100호 참고','left',-ox,-12,mAlpha*smooth(.427,.442,p));
 label(point(.75,.38),'<strong>114</strong> cm','가슴둘레 · 기존 100호 참고','right',ox*.32,5,mAlpha*smooth(.449,.463,p));
 label(point(.88,.67),'<strong>60</strong> cm','팔길이 · 기존 100호 참고','right',ox*.25,8,mAlpha*smooth(.471,.482,p));
 label(point(.33,.85),'<strong>78</strong> cm','총장 · 기존 100호 참고','left',-ox,18,mAlpha*smooth(.488,.499,p));
 $('#variant-labels').style.opacity=win(p,.306,.319,.365,.38);
 $('#variant-labels').style.top=Math.min(height-(mobile?125:95),centerY+modelH*.48+22)+'px';
 $('#model-caption').style.opacity=(1-spread)*(1-cadAmount)*(1-final)*.8;
 $('#scroll-cue').style.opacity=1-smooth(.015,.043,p);
 const matOpacity=win(p,.841,.862,.94,.955);$('#material-note').style.opacity=matOpacity;
 const matIdx=color<.5?0:color<1.5?1:2;
 $('#material-name').textContent=['Washed cotton.','Muted olive.','Deep charcoal.'][matIdx];
 $('#material-desc').innerHTML=['드라이한 표면. 자연스러운 구김.<br>셔츠의 구조에, 워크웨어의 감각을.','일상에 스며드는 차분한 색.<br>질감은 유지하고, 인상을 바꿉니다.','깊고 정돈된 색의 밀도.<br>같은 디자인의 또 다른 가능성.'][matIdx];
 document.querySelectorAll('.swatches i').forEach((el,i)=>el.style.outlineColor=i===matIdx?'#cbefef88':'transparent');
 stage.dataset.progress=p.toFixed(5);stage.dataset.chapter=String(lastChapter+1);stage.dataset.cadX=sweepX.toFixed(3);stage.dataset.photo=photo.toFixed(3);
 renderer.render(scene,camera);
}
function tick(){
 const total=journey.offsetHeight-height;
 progress=clamp((scrollY-journey.offsetTop)/total);
 // Direct mapping is essential: no autonomous rebound after scrolling stops.
 if(Math.abs(progress-lastP)>.000008){render(progress);lastP=progress;}
 requestAnimationFrame(tick);
}
addEventListener('resize',resize,{passive:true});
init();


