/**
 * Original SVG apparel drafting artwork, viewBox="0 0 1200 900".
 * A visual design study, not validated CAD or a production cutting file.
 * Known size-100 measurements below are finished-garment reference values.
 */
export function cadMarkup(){
  const fmt=n=>Number(n.toFixed(2));
  const p=(d,extra='')=>`<path d="${d}" pathLength="1" ${extra}/>`;
  const text=(x,y,value,extra='')=>`<text x="${x}" y="${y}" ${extra}>${value}</text>`;
  const dot=(x,y,r=2)=>p(`M${x-r} ${y}a${r} ${r} 0 1 0 ${r*2} 0a${r} ${r} 0 1 0 ${-r*2} 0`);
  // Bake stitch dashes into the path itself. The complete compound path can
  // then use stroke-dasharray:1 for drawing without losing the stitch rhythm.
  function stitches(source,dash=4,gap=4){
    const tokens=source.match(/[MLQCZ]|-?\d*\.?\d+/g)||[];
    let i=0,at=[0,0],first=[0,0],points=[];
    const add=q=>{points.push(q);at=q;};
    while(i<tokens.length){
      const command=tokens[i++];
      if(command==='M'){at=[+tokens[i++],+tokens[i++]];first=at.slice();points.push(at);}
      if(command==='L'){const end=[+tokens[i++],+tokens[i++]];const a=at.slice();for(let k=1;k<=16;k++){const t=k/16;add([a[0]+(end[0]-a[0])*t,a[1]+(end[1]-a[1])*t]);}}
      if(command==='Q'){
        const a=at.slice(),b=[+tokens[i++],+tokens[i++]],c=[+tokens[i++],+tokens[i++]];
        for(let k=1;k<=64;k++){const t=k/64,u=1-t;add([u*u*a[0]+2*u*t*b[0]+t*t*c[0],u*u*a[1]+2*u*t*b[1]+t*t*c[1]]);}
      }
      if(command==='C'){
        const a=at.slice(),b=[+tokens[i++],+tokens[i++]],c=[+tokens[i++],+tokens[i++]],d=[+tokens[i++],+tokens[i++]];
        for(let k=1;k<=80;k++){const t=k/80,u=1-t;add([u*u*u*a[0]+3*u*u*t*b[0]+3*u*t*t*c[0]+t*t*t*d[0],u*u*u*a[1]+3*u*u*t*b[1]+3*u*t*t*c[1]+t*t*t*d[1]]);}
      }
      if(command==='Z')add(first.slice());
    }
    let result='',distance=0,previous=points[0];
    const period=dash+gap;
    for(const next of points.slice(1)){
      const length=Math.hypot(next[0]-previous[0],next[1]-previous[1]);
      if(length<1e-8){previous=next;continue;}
      let cursor=0;
      while(cursor<length-1e-7){
        const phase=(distance+cursor)%period;
        const drawing=phase<dash;
        const remaining=(drawing?dash:period)-phase;
        const end=Math.min(length,cursor+Math.max(remaining,.00001));
        if(drawing){
          const a=cursor/length,b=end/length;
          result+=`M${fmt(previous[0]+(next[0]-previous[0])*a)} ${fmt(previous[1]+(next[1]-previous[1])*a)}L${fmt(previous[0]+(next[0]-previous[0])*b)} ${fmt(previous[1]+(next[1]-previous[1])*b)}`;
        }
        cursor=end;
      }
      distance+=length;previous=next;
    }
    return p(result);
  }
  const front='M122 235 C148 231 169 202 170 157 L281 194 C272 231 285 278 331 309 C326 359 318 429 321 484 C320 565 328 645 340 714 Q237 754 122 736 Z';
  const frontAllowance='M111 234 C141 225 159 195 159 144 L294 187 C282 225 295 274 342 303 C337 361 329 430 332 484 C331 566 338 645 352 720 Q238 768 111 745 Z';
  const frontSew='M132 244 C157 237 177 213 180 170 L269 200 C264 241 281 285 321 316 C316 367 308 430 311 484 C310 568 318 643 329 707 Q234 741 132 726 Z';
  const back='M449 173 Q480 173 490 151 L606 190 C601 234 616 280 656 310 C650 366 639 430 641 484 C642 566 650 649 662 716 Q566 749 449 736 Z';
  const backAllowance='M439 162 Q470 164 484 138 L618 183 C612 230 627 274 667 304 C661 368 650 432 652 484 C653 568 660 649 674 722 Q564 763 439 745 Z';
  const backSew='M459 182 Q486 183 496 165 L595 197 C592 243 610 289 646 317 C639 376 629 430 631 484 C632 567 640 645 651 709 Q560 736 459 726 Z';
  const sleeve='M811 322 C818 247 860 179 927 165 C994 152 1047 228 1071 322 C1058 434 1037 552 1018 645 Q934 663 843 646 C829 541 816 427 811 322 Z';
  const sleeveSew='M822 324 C829 251 868 190 929 176 C989 166 1035 235 1060 323 C1047 436 1028 550 1008 636 Q934 651 853 637 C841 534 828 425 822 324 Z';
  const sleeveAllowance='M800 322 C807 242 852 169 925 154 C1000 141 1057 221 1082 321 C1069 436 1047 556 1028 654 Q934 675 833 655 C818 542 805 429 800 322 Z';
  const collar='M797 706 L817 687 C903 701 1026 701 1108 687 L1130 706 L1092 747 C1009 729 908 729 834 747 Z';
  const collarSew='M810 707 L821 697 C907 710 1024 710 1104 698 L1117 707 L1089 736 C1007 719 910 719 839 736 Z';
  const cuff='M813 793 L1080 793 Q1092 793 1092 805 L1092 847 Q1092 859 1080 859 L813 859 Z';
  const cuffSew='M823 803 L1077 803 Q1082 803 1082 808 L1082 844 Q1082 849 1077 849 L823 849 Z';
  const pockets='M184 354 L275 350 L279 445 Q279 464 260 468 L201 469 Q185 469 184 451 Z';
  const outlines=[front,back,sleeve,collar,cuff];
  const patternLabels=[
    text(124,119,'FRONT / 01','class="piece-title"'),text(124,136,'CUT 2 · MIRRORED'),
    text(449,112,'BACK / 02','class="piece-title"'),text(449,129,'CUT 1 ON FOLD'),
    text(832,115,'SLEEVE / 03','class="piece-title"'),text(832,132,'CUT 2 · MIRRORED'),
    text(797,679,'COLLAR / 04','class="piece-title"'),text(813,775,'CUFF / 05','class="piece-title"'),
  ].join('');
  const buttons=[284,351,418,485,552,619,686].map(y=>dot(143,y,2.25)+p(`M138 ${y}L148 ${y}`)).join('');
  const frontNotches=p('M324 330L330 332M323 337L329 339M126 486L137 486M324 486L331 486M178 160L183 168');
  const backNotches=p('M647 333L654 335M646 340L653 342M638 486L650 486M448 488L460 488M498 154L503 162');
  const sleeveNotches=p('M919 168L922 180L929 167M826 260L835 265M1037 257L1029 263M1041 266L1033 272M869 650L874 638L879 649M975 651L980 638L985 649');
  return `<defs>
    <marker id="cad-arrow" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M1 1L7 4L1 7" pathLength="1" fill="none" stroke="#8bdcf4" stroke-width=".85"/></marker>
    <marker id="cad-grain" viewBox="0 0 8 10" refX="4" refY="5" markerWidth="6" markerHeight="8" orient="auto-start-reverse"><path d="M1 2L4 8L7 2" pathLength="1" fill="none" stroke="#77bdd4" stroke-width=".8"/></marker>
    <style>
      .cad-plate{font-family:'IBM Plex Mono',ui-monospace,SFMono-Regular,Consolas,monospace;font-size:9px;letter-spacing:1.15px;fill:#8cb4c5}
      .cad-plate path{vector-effect:non-scaling-stroke;stroke-linecap:round;stroke-linejoin:round}
      .cad-plate .piece-title{font-size:11px;letter-spacing:2.0px;fill:#ddf4fc}
      .cad-plate .tiny{font-size:8px;letter-spacing:.75px}
      .cad-plate .ref{font-size:9px;letter-spacing:.7px;fill:#b4dce9}
      .cad-plate .soft{fill:#587f94}
    </style>
  </defs>
  <g class="cad-plate">
    <g data-layer="construction" fill="none" stroke="#31576c" stroke-width=".55">
      ${p('M63 89L1164 89M63 80L63 98M1164 80L1164 98')}
      ${p('M99 309L365 309M422 310L691 310M790 322L1102 322')}
      ${p('M102 484L363 484M422 484L695 484M805 461L1062 461')}
      ${p('M121 153L121 749M449 148L449 751M941 149L941 663')}
      ${p('M170 149L170 244M281 182L281 320M490 140L490 195M606 180L606 321')}
      ${p('M811 322L1071 322M843 646L1018 645M927 165L927 322')}
      ${p('M449 257Q535 247 624 267M468 258L468 349M481 257L481 349')}
      ${p(pockets,'stroke="#568196" stroke-width=".7"')}
      ${p('M182 370L277 366M184 354L185 370M275 350L277 366')}
      ${p('M987 538L991 639M997 537L1000 637M987 538L997 537')}
      ${p('M865 793L865 859M1059 793L1059 859M813 826L1092 826')}
      ${buttons}
      ${p('M227 538L227 669','stroke="#77bdd4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M548 354L548 646','stroke="#77bdd4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M941 350L941 610','stroke="#77bdd4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
      ${p('M866 719L1067 719','stroke="#77bdd4" marker-start="url(#cad-grain)" marker-end="url(#cad-grain)"')}
    </g>
    <g data-layer="allowance" fill="none" stroke="#347d9c" stroke-width=".65">
      ${[frontAllowance,backAllowance,sleeveAllowance].map(d=>p(d)).join('')}
      ${p('M799 788L1081 788Q1097 788 1097 804L1097 848Q1097 864 1081 864L799 864Z')}
      ${p('M790 707L812 681C906 695 1025 695 1112 681L1138 707L1094 754C1009 736 910 736 831 754Z')}
    </g>
    <g data-layer="outline" fill="none" stroke="#d1effa" stroke-width="1.05">
      ${outlines.map(d=>p(d)).join('')}
      ${frontNotches}${backNotches}${sleeveNotches}
      ${p('M934 700L939 706L944 700M942 795L947 802L952 795')}
    </g>
    <g data-layer="seam" fill="none" stroke="#71c4e1" stroke-width=".65">
      ${[frontSew,backSew,sleeveSew,collarSew,cuffSew].map(d=>stitches(d,4,3.8)).join('')}
      ${stitches('M459 263Q536 254 620 273',3.6,3.2)}
      ${stitches('M180 360L268 357L272 443Q273 458 256 461L202 462Q192 462 191 449L190 375',3.2,3.0)}
      ${stitches('M156 257L156 718',4,4)}
      ${p('M844 826L853 826M1050 826L1068 826M1050 822L1050 830M1068 822L1068 830')}
      ${dot(848,826,2.5)}
    </g>
    <g data-layer="dimension" fill="none" stroke="#78bbd2" stroke-width=".65">
      ${p('M448 173L401 173M448 736L401 736M409 181L409 728','marker-start="url(#cad-arrow)" marker-end="url(#cad-arrow)"')}
      ${p('M934 164L1164 164M1019 646L1164 646M1155 172L1155 638','marker-start="url(#cad-arrow)" marker-end="url(#cad-arrow)"')}
      ${p('M132 795L330 795M132 788L132 802M330 788L330 802')}
      ${p('M464 795L649 795M464 788L464 802M649 788L649 802')}
      ${p('M342 606L369 606L379 618M331 606L342 606','stroke="#417e97"')}
      ${p('M939 174L965 147L1016 147','stroke="#417e97"')}
      ${p('M995 572L1066 569L1103 552','stroke="#417e97"')}
      ${p('M127 257L89 274L89 316','stroke="#417e97"')}
      ${p('M607 190L671 166L703 166','stroke="#417e97"')}
    </g>
    <g data-layer="dimension" stroke="none">
      ${text(63,50,'PATTERN ENGINEERING / SHIRT JACKET','class="piece-title"')}
      ${text(1164,50,'100 · DESIGN STUDY','text-anchor="end" class="ref"')}
      ${patternLabels}
      ${text(236,596,'GRAIN','class="tiny" transform="rotate(-90 236 596)"')}
      ${text(558,493,'GRAIN / LENGTHWISE','class="tiny" transform="rotate(-90 558 493)"')}
      ${text(951,459,'GRAIN / LENGTHWISE','class="tiny" transform="rotate(-90 951 459)"')}
      ${text(393,458,'CB LENGTH 78 cm · GARMENT REFERENCE','text-anchor="middle" class="ref" transform="rotate(-90 393 458)"')}
      ${text(1176,410,'SLEEVE 60 cm · GARMENT REFERENCE','text-anchor="middle" class="ref" transform="rotate(-90 1176 410)"')}
      ${text(122,777,'CENTRE FRONT + BUTTON STAND','class="tiny"')}
      ${text(449,777,'CENTRE BACK / FOLD LINE','class="tiny"')}
      ${text(122,816,'CHEST 114 cm · FULL GIRTH REFERENCE','class="ref"')}
      ${text(449,816,'SHOULDER 48 cm · FULL WIDTH REFERENCE','class="ref"')}
      ${text(353,630,'SA 10 mm','class="tiny"')}
      ${text(353,643,'DESIGN STUDY','class="tiny soft"')}
      ${text(1023,150,'SLEEVE CAP / EASE','class="tiny"')}
      ${text(1098,542,'PLACKET OPENING','class="tiny" text-anchor="end"')}
      ${text(80,321,'CF','class="tiny"')}
      ${text(708,169,'SHOULDER SEAM','class="tiny"')}
      ${text(800,473,'ELBOW LINE','class="tiny" text-anchor="end"')}
      ${text(695,305,'CHEST LINE','class="tiny"')}
      ${text(695,479,'WAIST LINE','class="tiny"')}
      ${text(825,764,'CUT 2 · INTERFACING AS REQUIRED','class="tiny soft"')}
      ${text(813,874,'CUT 2 PAIRS · FOLD / BUTTON / BUTTONHOLE','class="tiny soft"')}
      ${text(63,871,'REFERENCE: REGULAR FIT / SIZE 100 / cm','class="tiny soft"')}
      ${text(63,887,'ILLUSTRATIVE DRAFT GEOMETRY — NOT A VALIDATED PATTERN OR A CUTTING FILE','class="tiny soft"')}
    </g>
  </g>`;
}

