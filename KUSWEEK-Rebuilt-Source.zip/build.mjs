import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
let esbuild;
try{esbuild=await import('esbuild');}catch{esbuild=await import('../qa/node_modules/esbuild/lib/main.js');}
const {build}=esbuild;
const root=fileURLToPath(new URL('.',import.meta.url));
const target=path.resolve(process.argv[2]||path.join(root,'preview.html'));
const images={};for(const n of ['hero','khaki','charcoal'])images[n]='data:image/webp;base64,'+(await fs.readFile(path.join(root,'assets',n+'.webp'))).toString('base64');
await fs.writeFile(path.join(root,'embedded.js'),'export const images='+JSON.stringify(images));
const js=await build({entryPoints:[path.join(root,'app.js')],bundle:true,write:false,minify:true,format:'iife',target:'es2020',legalComments:'inline'});
const [html,css,font]=await Promise.all([fs.readFile(path.join(root,'index.html'),'utf8'),fs.readFile(path.join(root,'style.css'),'utf8'),fs.readFile(path.join(root,'PretendardVariable.woff2'))]);
const out=html.replace('<!-- STYLE -->',()=>'<style>'+css.replace('__FONT__','data:font/woff2;base64,'+font.toString('base64'))+'</style>').replace('<!-- SCRIPT -->',()=>'<script>'+js.outputFiles[0].text+'</script>');
await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,out);console.log('Built '+target+' / '+(Buffer.byteLength(out)/1048576).toFixed(2)+' MiB');
