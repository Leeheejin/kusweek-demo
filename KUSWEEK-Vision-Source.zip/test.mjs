import assert from 'node:assert/strict';import fs from 'node:fs';
import {stateAt,stops,measurements,sizeLabels} from './motion.js';
for(let n=0;n<=2000;n++){const p=n/2000,s=stateAt(p);assert(s.weights.some(w=>w>.15),'blank state at '+p);assert(s.weights.every(w=>w>=0&&w<=1));assert(s.explode>=0&&s.explode<=1);assert(Number.isFinite(s.turn));assert.deepEqual(s,stateAt(p));}
assert.equal(stateAt(-1).p,0);assert.equal(stateAt(2).p,1);assert.equal(stateAt(NaN).p,0);stops.forEach((p,i)=>assert.equal(stateAt(p).chapter,i));
assert.equal(measurements.regular.chest[1],114);assert.equal(measurements.slim.chest[1],109);assert.equal(measurements.regular.shoulder[1],48);assert.equal(measurements.slim.shoulder[1],46.5);assert.equal(measurements.slim.sleeve[8],null);assert.equal(sizeLabels.length,9);
for(const f of Object.values(measurements))for(const a of Object.values(f))assert.equal(a.length,9);
const html=fs.readFileSync('dist/index.html','utf8');
assert(!html.includes('journey-track'));assert(!html.includes('data-jump'));assert(!html.includes('id="workflow"'));assert(!html.match(/\.glb|Hunyuan|TRELLIS|three\.module/i));assert(html.includes('3D 가상샘플로 시작하는 제안형 수주'));assert(html.includes('Kustom'));assert(html.includes('셔켓 적용 시 여유량과 소재를 별도로 검토합니다.'));assert.equal((html.match(/class="sample-card/g)||[]).length,3);assert(!html.match(/<script[^>]+src=/));assert(html.includes('data:font/woff2;base64,'));
console.log('PASS: 2001 continuous and reversible states; source-based measurements; uncertain source value not fabricated; no flat business-stage navigation; standalone assets; three garment concepts; no legacy models.');
