import {clamp,mix,key,progress} from './motion.js';
const TAU=Math.PI*2;
// Newly authored parametric illustration: dimensional shirt surfaces unfold into
// a drafting arrangement. This is a visual explanation, never a cutting pattern.
const definitions=[
 {id:'front-l',label:'FRONT / 앞판',type:'front',side:-1,flat:[-2.05,-1.30],nu:18,nv:34},
 {id:'front-r',label:'FRONT / 앞판',type:'front',side:1,flat:[-.93,-1.30],nu:18,nv:34},
 {id:'back',label:'BACK / 뒤판',type:'back',flat:[.70,-1.30],nu:28,nv:34},
 {id:'sleeve-l',label:'SLEEVE / 소매',type:'sleeve',side:-1,flat:[-2.03,1.55],nu:24,nv:28},
 {id:'sleeve-r',label:'SLEEVE / 소매',type:'sleeve',side:1,flat:[2.17,-1.27],nu:24,nv:28},
 {id:'collar-l',label:'COLLAR / 칼라',type:'collar',side:-1,flat:[-.44,1.60],nu:20,nv:7},
 {id:'collar-r',label:'COLLAR / 칼라',type:'collar',side:1,flat:[.45,1.60],nu:20,nv:7},
 {id:'pocket',label:'POCKET / 포켓',type:'pocket',flat:[1.22,1.53],nu:10,nv:10},
 {id:'cuff',label:'CUFF / 커프스',type:'cuff',flat:[2.10,1.63],nu:14,nv:8}
];
function coordinates(d,u,v,ratio,p){
 let x,y,z,fx,fy;const wrinkle=(Math.sin(v*21+u*6)*.016+Math.sin(v*37-u*11)*.008)*Math.sin(Math.PI*u);
 if(d.type==='front'){
  const top=u<.32?.025+.34*Math.pow(1-u/.32,1.7):.025+.27*(u-.32)/.68,end=2.58-.08*u;
  const width=(.93-.17*Math.exp(-Math.pow((v-.15)/.092,2))-.028*Math.sin(v*Math.PI))*ratio;
  x=d.side*(.025+u*width);y=mix(top,end,v)-1.3;z=.36*Math.sqrt(Math.max(0,1-Math.pow(u*.92,2)))+wrinkle;
  fx=d.flat[0]+u*width;fy=d.flat[1]+mix(top,end,v)*.82;
 }else if(d.type==='back'){
  const q=u*2-1,w=(.94-.17*Math.exp(-Math.pow((v-.15)/.092,2))-.03*Math.sin(v*Math.PI))*ratio;
  const a=Math.abs(q),top=a<.3?.025+.13*Math.pow(1-a/.3,2):.025+.27*(a-.3)/.7;
  x=q*w;y=mix(top,2.55,v)-1.3;z=-.29*Math.sqrt(Math.max(.04,1-q*q*.94))+wrinkle;
  fx=d.flat[0]+q*w*.68;fy=d.flat[1]+mix(top,2.55,v)*.82;
 }else if(d.type==='sleeve'){
  const radius=mix(.29,.19,v),theta=u*TAU;
  x=d.side*(.86+v*.63+Math.cos(theta)*radius);y=.48+v*1.91-Math.cos(theta)*radius*.6-1.3;z=Math.sin(theta)*radius+wrinkle;
  const cap=.36*(1-Math.sin(Math.PI*u));
  const horizontal=d.id==='sleeve-l';
  if(horizontal){fx=d.flat[0]+v*1.03;fy=d.flat[1]+(u-.5)*.62*(1-v*.38)+cap*.15;}
  else{fx=d.flat[0]+(u-.5)*1.1*(1-v*.38);fy=d.flat[1]+mix(cap,2.12,v);}
 }else if(d.type==='collar'){
  x=d.side*mix(mix(.025,.29,u),mix(.27,.51,u),v);
  y=mix(mix(-1.02,-1.30,u),mix(-.72,-1.07,u),v);
  z=mix(mix(.39,-.07,u),mix(.47,.16,u),v)+Math.sin(u*Math.PI)*.018;
  fx=d.flat[0]+(u-.5)*.65;fy=d.flat[1]+v*.30+Math.sin(u*Math.PI)*.07;
 }else if(d.type==='pocket'){
  x=.32+u*.41;y=-.43+v*.47+Math.sin(u*Math.PI)*v*v*.045;z=.36*Math.sqrt(Math.max(.1,1-Math.pow(x/.99,2)))+.035+Math.sin(u*Math.PI)*.02;
  fx=d.flat[0]+(u-.5)*.46;fy=d.flat[1]+v*.40+Math.sin(u*Math.PI)*v*v*.07;
 }else{
  const theta=u*TAU;x=1.49+Math.cos(theta)*.194;y=1.10+v*.19;z=Math.sin(theta)*.194;
  fx=d.flat[0]+(u-.5)*.69;fy=d.flat[1]+v*.26;
 }
 return {assembled:[x,y,z],flat:[fx,fy,0]};
}
export function createAtelier(canvas){
 const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return {resize(){},draw(){}};
 let width=1,height=1,dpr=1;
 function resize(){width=canvas.clientWidth;height=canvas.clientHeight;dpr=Math.min(devicePixelRatio||1,1.6);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);}
 function draw(s,choice,reduced=false){
  if(width!==canvas.clientWidth||height!==canvas.clientHeight)resize();
  const {p,blue,dark}=s,mobile=width<761;
  const bg=[mix(mix(232,35,blue),14,dark),mix(mix(233,71,blue),29,dark),mix(mix(230,146,blue),54,dark)];
  const rgb=(c,a=1)=>`rgba(${c.map(v=>Math.round(v)).join(',')},${a})`;
  const lightInk=blue>.48||dark>.25;
  const ink=lightInk?[208,229,255]:[29,66,127];
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle=rgb(bg);ctx.fillRect(0,0,width,height);
  // The fine field becomes a pattern cutting table with the same scroll motion.
  ctx.lineWidth=.55;ctx.strokeStyle=rgb(ink,.045+blue*.07);
  const gap=mobile?36:58,offset=(p*95)%gap;
  ctx.beginPath();for(let x=-gap;x<width+gap;x+=gap){ctx.moveTo(x+offset,0);ctx.lineTo(x+offset,height);}for(let y=0;y<height;y+=gap){ctx.moveTo(0,y+offset);ctx.lineTo(width,y+offset);}ctx.stroke();
  // Contour field: wide continuous threads, never particles or random flashes.
  ctx.save();ctx.globalAlpha=.18*(1-progress(p,.16,.30))+.08*dark;
  for(let j=0;j<36;j++){ctx.beginPath();for(let i=0;i<=100;i++){const t=i/100,x=width*(.40+t*.82),y=height*(.25+j*.012+Math.sin(t*4.1+p*4+j*.043)*.14);i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.strokeStyle=rgb(ink,.45);ctx.stroke();}ctx.restore();
  let cx=key(p,mobile?[[0,.68],[.18,.21],[.23,.21],[.37,.43],[.55,.50],[.73,.29],[.94,.72]]:[[0,.73],[.18,.49],[.25,.49],[.36,.63],[.55,.70],[.74,.59],[.95,.72]])*width;
  let cy=key(p,mobile?[[0,.79],[.18,.70],[.35,.66],[.55,.50],[.74,.70],[1,.68]]:[[0,.55],[.20,.56],[.37,.55],[.55,.55],[.73,.55],[1,.52]])*height;
  let unit=key(p,mobile?[[0,.12],[.20,.115],[.36,.13],[.55,.074],[.74,.145],[1,.16]]:[[0,.205],[.20,.164],[.36,.178],[.55,.142],[.74,.18],[1,.22]])*height;
  if(mobile)unit=Math.min(unit,width*key(p,[[0,.245],[.18,.17],[.23,.17],[.36,.235],[.55,.14],[.74,.26],[1,.3]]));
  else unit=Math.min(unit,width*key(p,[[0,.145],[.18,.100],[.25,.100],[.36,.132],[.55,.100],[.74,.135],[1,.155]]));
  const turn=reduced?-.12:s.turn,tilt=reduced?0:s.tilt,explode=s.explode;
  const ratio=(choice.chest||114)/114*(choice.fit==='slim'?.98:1);
  function project(point){let [x,y,z]=point;const xr=x*Math.cos(turn)+z*Math.sin(turn),zr=-x*Math.sin(turn)+z*Math.cos(turn);const yr=y*Math.cos(tilt)-zr*Math.sin(tilt),zz=y*Math.sin(tilt)+zr*Math.cos(tilt);const persp=6/(6+zz);return [cx+xr*unit*persp,cy+yr*unit*persp,zz];}
  const opacity=s.mesh;
  function getpoint(d,u,v,index){const c=coordinates(d,u,v,ratio,p),t=clamp(explode+(index-4)*.006*explode*(1-explode));const unfold=[mix(c.assembled[0],c.flat[0],t),mix(c.assembled[1],c.flat[1],t),mix(c.assembled[2],0,t)];const lift=Math.sin(t*Math.PI);unfold[2]+=Math.sin(index*1.7)*lift*.95;unfold[0]+=Math.cos(index*1.1)*lift*.22;unfold[1]+=Math.sin(index*2.2)*lift*.32;return project(unfold);}
  const panels=definitions.filter(d=>!(choice.fit==='slim'&&d.type==='pocket')).map((d,index)=>{
   const points=[];for(let v=0;v<=d.nv;v++){let row=[];for(let u=0;u<=d.nu;u++)row.push(getpoint(d,u/d.nu,v/d.nv,index));points.push(row);}return {d,index,points,z:points[Math.floor(d.nv/2)][Math.floor(d.nu/2)][2]};
  }).sort((a,b)=>b.z-a.z);
  // Nested grading contours expand from the same front panel, not an unrelated icon.
  if(s.grading>.01){const base=definitions[1];for(let size=8;size>=0;size--){const k=(size-1)*.023,pts=[];for(let i=0;i<=40;i++)pts.push(getpoint(base,i/40,0,1));for(let i=1;i<=60;i++)pts.push(getpoint(base,1,i/60,1));for(let i=39;i>=0;i--)pts.push(getpoint(base,i/40,1,1));for(let i=59;i>=0;i--)pts.push(getpoint(base,0,i/60,1));const mid=project([-.48,-.2,0]);ctx.beginPath();pts.forEach((q,i)=>{const x=mid[0]+(q[0]-mid[0])*(1+k),y=mid[1]+(q[1]-mid[1])*(1+k);i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.closePath();ctx.strokeStyle=rgb(ink,s.grading*(size===choice.sizeIndex?.9:.18));ctx.lineWidth=size===choice.sizeIndex?1.4:.5;ctx.stroke();}}
  for(const {d,points,index} of panels){
   if(opacity<.005)continue;
   const silhouette=[];for(let u=0;u<=d.nu;u++)silhouette.push(points[0][u]);for(let v=1;v<=d.nv;v++)silhouette.push(points[v][d.nu]);for(let u=d.nu-1;u>=0;u--)silhouette.push(points[d.nv][u]);for(let v=d.nv-1;v>0;v--)silhouette.push(points[v][0]);
   const path=()=>{ctx.beginPath();silhouette.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.closePath();};
   path();const bounds=points[Math.floor(d.nv/2)][Math.floor(d.nu/2)];const fill=ctx.createLinearGradient(bounds[0]-unit,bounds[1]-unit,bounds[0]+unit,bounds[1]+unit);fill.addColorStop(0,rgb(ink,(.10+explode*.17)*opacity));fill.addColorStop(.48,rgb(ink,(.03+explode*.035)*opacity));fill.addColorStop(1,rgb(ink,(.16+explode*.10)*opacity));ctx.fillStyle=fill;ctx.fill();
   // Fine surface grid with a separate structural seam hierarchy.
   ctx.strokeStyle=rgb(ink,(.24+blue*.16)*opacity*(d.type==='back'?.55:1));ctx.lineWidth=.55;
   ctx.beginPath();for(let v=0;v<=d.nv;v++){for(let u=0;u<=d.nu;u++){const q=points[v][u];u?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]);}}
   for(let u=0;u<=d.nu;u++){for(let v=0;v<=d.nv;v++){const q=points[v][u];v?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]);}}ctx.stroke();
   // Selected diagonal threads accentuate the curvature before the planes flatten.
   if(d.type==='front'||d.type==='back'){ctx.strokeStyle=rgb(ink,.065*opacity);ctx.beginPath();for(let v=0;v<d.nv;v++)for(let u=0;u<d.nu;u++){ctx.moveTo(...points[v][u].slice(0,2));ctx.lineTo(...points[v+1][u+1].slice(0,2));}ctx.stroke();}
   path();ctx.strokeStyle=rgb(ink,(d.type==='back'?.4:.83)*opacity);ctx.lineWidth=1.1;ctx.stroke();
   ctx.setLineDash([2.5,3]);ctx.strokeStyle=rgb(ink,.54*opacity);ctx.lineWidth=.8;ctx.beginPath();for(let v=1;v<d.nv;v++){const q=points[v][1];v===1?ctx.moveTo(q[0],q[1]):ctx.lineTo(q[0],q[1]);}ctx.stroke();ctx.setLineDash([]);
   if(explode>.6){let q=points[d.nv][Math.floor(d.nu/2)];ctx.globalAlpha=progress(explode,.6,.95)*opacity;ctx.fillStyle=rgb(ink,.8);ctx.font=`${mobile?5:8}px Pretendard, sans-serif`;ctx.textAlign='center';ctx.fillText(d.label,q[0],q[1]+(mobile?9:18));ctx.globalAlpha=1;}
   // Pattern notches, anchors and a grainline come forward at the CAD reveal.
   if(explode>.3){ctx.globalAlpha=progress(explode,.3,.9)*opacity;const a=points[3][Math.floor(d.nu/2)],b=points[d.nv-2][Math.floor(d.nu/2)];ctx.strokeStyle=rgb(ink,.7);ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.moveTo(a[0]-3,a[1]+5);ctx.lineTo(a[0],a[1]);ctx.lineTo(a[0]+3,a[1]+5);ctx.stroke();for(let n=0;n<silhouette.length;n+=Math.max(1,Math.floor(silhouette.length/6))){let q=silhouette[n];ctx.strokeRect(q[0]-1.5,q[1]-1.5,3,3);}ctx.globalAlpha=1;}
  }
  // Garment buttons and centre-front: recognisable shirt construction.
  const buttonAlpha=(1-explode)*opacity;
  if(buttonAlpha>.01){ctx.strokeStyle=rgb(ink,.8*buttonAlpha);ctx.lineWidth=1;for(let j=0;j<7;j++){const q=project([.022,-.86+j*.29,.377]);ctx.beginPath();ctx.arc(q[0],q[1],Math.max(1.4,unit*.012),0,TAU);ctx.stroke();}}
  // Construction callouts: fine measurable geometry, with a restrained scan plane.
  const dimOpacity=progress(p,.32,.42)*(1-progress(p,.64,.72));
  if(dimOpacity>.01&&!mobile){ctx.globalAlpha=dimOpacity;ctx.strokeStyle=rgb(ink,.42);ctx.lineWidth=.7;const l=cx-unit*2.60,r=cx+unit*2.76,y=cy-unit*1.65;
   ctx.beginPath();ctx.moveTo(l,y);ctx.lineTo(r,y);ctx.moveTo(l,y-5);ctx.lineTo(l,y+5);ctx.moveTo(r,y-5);ctx.lineTo(r,y+5);ctx.stroke();ctx.fillStyle=rgb(ink,.75);ctx.textAlign='center';ctx.font=`${mobile?5:8}px Pretendard,sans-serif`;ctx.fillText('PATTERN FIELD / '+(95+choice.sizeIndex*5)+' / '+(choice.fit==='regular'?'REGULAR':'SLIM'),(l+r)/2,y-9);ctx.globalAlpha=1;
  }
  if(p>.28&&p<.48){const scan=progress(p,.28,.48),x=width*mix(1.12,-.1,scan);ctx.fillStyle=rgb(ink,.035);ctx.fillRect(x,0,70,height);ctx.strokeStyle=rgb(ink,.40);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,height);ctx.stroke();}
 }
 resize();return {resize,draw};
}
