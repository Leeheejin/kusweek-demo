/* Motion math adapted from revfactory/showreel (MIT).
 * Copyright (c) 2026 Minho Hwang (revfactory). See SHOWREEL-LICENSE.txt.
 * Website adaptation: scroll progress replaces video time; every visual state
 * is a pure function of that progress, so reverse scrolling is deterministic.
 */
export const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
export const lerp=(a,b,p)=>a+(b-a)*p;
export const ease={linear:p=>p,outQuart:p=>1-(1-p)**4,inOutCubic:p=>p<.5?4*p*p*p:1-(-2*p+2)**3/2,inOutSine:p=>-(Math.cos(Math.PI*p)-1)/2};
export const prog=(t,start,duration,e=ease.inOutCubic)=>e(clamp((t-start)/Math.max(.00001,duration)));
export function kf(t,frames){if(t<=frames[0][0])return frames[0][1];for(let i=1;i<frames.length;i++){const [end,value,e]=frames[i],[start,from]=frames[i-1];if(t<=end)return lerp(from,value,(e||ease.inOutCubic)(clamp((t-start)/(end-start))))}return frames.at(-1)[1]}
export const CUES={opening:0,sample:.23,cad:.49,ax:.73,future:1};
export const chapterStops=Object.values(CUES);
export function visualState(p){
 p=clamp(Number.isFinite(p)?p:0);
 const weights=chapterStops.map((stop,i)=>{const left=i? (chapterStops[i-1]+stop)/2:0,right=i<4?(stop+chapterStops[i+1])/2:1;return (i?prog(p,left-.038,.064):1)*(i<4?1-prog(p,right-.038,.064):1)});
 const chapter=weights.indexOf(Math.max(...weights));
 return {p,chapter,weights,
  dark:prog(p,.32,.105)*(1-prog(p,.84,.105)),
  scan:prog(p,.27,.14),
  garment:kf(p,[[0,1],[.29,1],[.435,0],[.82,0],[.94,1],[1,1]]),
  spread:kf(p,[[0,1],[.11,.85],[.23,0],[.80,0],[.96,1],[1,1]]),
  pattern:prog(p,.345,.085)*(1-prog(p,.65,.105)),
  flow:prog(p,.595,.085)*(1-prog(p,.815,.09)),
  draw:prog(p,.345,.19,ease.outQuart),
  heroScale:kf(p,[[0,.93],[.12,1.02],[.28,1.2],[.41,1.02],[.83,.94],[1,.93]]),
  heroTurn:kf(p,[[0,-9],[.12,-4],[.28,5],[.41,0],[.83,-4],[1,-9]])};
}
