/* Scroll interpolation adapted from revfactory/showreel (MIT).
 * Copyright (c) 2026 Minho Hwang. New garment illustration and story by KUSWEEK demo. */
export const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
export const mix=(a,b,t)=>a+(b-a)*t;
export const smooth=t=>t*t*(3-2*t);
export const progress=(v,a,b)=>smooth(clamp((v-a)/(b-a)));
export function key(p,frames){if(p<=frames[0][0])return frames[0][1];for(let i=1;i<frames.length;i++)if(p<=frames[i][0])return mix(frames[i-1][1],frames[i][1],progress(p,frames[i-1][0],frames[i][0]));return frames.at(-1)[1];}
export const stops=[0,.20,.36,.55,.74,.96];
export function stateAt(raw){let p=clamp(Number.isFinite(raw)?raw:0);const spans=[[0,.07,.13,.18],[.13,.18,.29,.34],[.29,.34,.43,.48],[.43,.48,.66,.71],[.66,.71,.84,.90],[.84,.90,1,1.1]];const weights=spans.map(([a,b,c,d],i)=>(i?progress(p,a,b):1)*(1-progress(p,c,d)));const chapter=weights.indexOf(Math.max(...weights));return {p,weights,chapter,blue:progress(p,.305,.34)*(1-progress(p,.655,.69)),dark:progress(p,.86,.90),explode:progress(p,.28,.52)*(1-progress(p,.75,.88)),turn:key(p,[[0,-.42],[.12,.08],[.22,.25],[.34,-.42],[.55,-.10],[.67,.15],[.83,.5],[1,-.26]]),tilt:key(p,[[0,-.04],[.22,.04],[.43,-.25],[.55,-.08],[.75,-.4],[1,0]]),mesh:1-progress(p,.87,.97),grading:progress(p,.48,.57)*(1-progress(p,.61,.67))};}
export const sizeLabels=[95,100,105,110,115,120,125,130,135];
export const measurements={regular:{neck:[39,41,43,45,47,47,48,48,49],chest:[109,114,119,124,129,134,139,144,149],shoulder:[46.5,48,50,52,54,56,56,58,58],sleeve:[59,60,61,62,63,64,64,65,65],length:[77,78,80,81,82,82,83,83,84]},slim:{neck:[39,41,43,45,47,47,48,48,49],chest:[104,109,113,118,123,128,133,138,143],shoulder:[45,46.5,48,49.5,51,53,53,55,55],sleeve:[61.5,63,64,65.3,66.5,67.5,67.5,67.5,null],length:[74,75,77,78,79,79,80,80,81]}};

