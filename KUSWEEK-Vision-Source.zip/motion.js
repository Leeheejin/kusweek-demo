/* Adapted from revfactory/showreel (MIT), Copyright (c) 2026 Minho Hwang.
 * Scroll is the playhead. Pure functions make forward/reverse playback identical. */
export const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const smooth=t=>t*t*(3-2*t);
export const progress=(p,a,b)=>smooth(clamp((p-a)/(b-a)));
export function keyframe(p,frames){for(let i=1;i<frames.length;i++){if(p<=frames[i][0])return lerp(frames[i-1][1],frames[i][1],progress(p,frames[i-1][0],frames[i][0]));}return frames.at(-1)[1];}
export const stops=[0,.2,.4,.6,.8,1];
export function sceneState(raw){const p=clamp(Number.isFinite(raw)?raw:0);const weights=stops.map((s,i)=>(i?progress(p,s-.13,s-.075):1)*(i<5?1-progress(p,s+.07,s+.125):1));const chapter=weights.indexOf(Math.max(...weights));return {p,weights,chapter,dark:1-progress(p,.075,.135)+progress(p,.49,.545)-progress(p,.68,.745)+progress(p,.88,.945),object:{x:keyframe(p,[[0,24],[.2,-3],[.4,-40],[.6,-43],[1,-43]]),y:keyframe(p,[[0,0],[.2,0],[.4,15],[.6,20],[1,20]]),scale:keyframe(p,[[0,1.1],[.2,.95],[.4,.47],[.6,.4],[1,.4]]),rotate:keyframe(p,[[0,-8],[.2,3],[.4,-12],[.6,-4],[1,0]]),opacity:1-progress(p,.29,.36)},pattern:progress(p,.5,.61)};}
