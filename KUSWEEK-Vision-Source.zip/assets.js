export const assets={hero:'./assets/hero.png',sage:'./assets/sage.png',navy:'./assets/navy.png',ivory:'./assets/ivory.png',logo:'./assets/logo.png'};
