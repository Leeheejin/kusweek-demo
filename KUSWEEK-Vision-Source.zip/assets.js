export const assets={ivory:'./assets/ivory.png',navy:'./assets/navy.png',sage:'./assets/sage.png',logo:'./assets/logo.png'};
