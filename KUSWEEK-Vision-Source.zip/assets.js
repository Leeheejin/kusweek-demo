export const assets={hero:'./assets/hero.png',navy:'./assets/navy.png',sage:'./assets/sage.png',logo:'./assets/logo.png'};
