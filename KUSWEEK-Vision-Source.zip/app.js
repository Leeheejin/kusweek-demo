import {assets} from './assets.js';
import {clamp,mix,progress,key,stateAt,stops,sizeLabels,measurements} from './motion.js';
import {createAtelier} from './atelier.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
$$('[data-asset]').forEach(el=>el.src=assets[el.dataset.asset]);
const story=$('#story'),stage=$('.stage'),scenes=$$('.scene'),canvas=$('#atelier'),reduced=matchMedia('(prefers-reduced-motion:reduce)');
const atelier=createAtelier(canvas);
const choice={fit:'regular',color:'브라운',sizeIndex:1,sample:'hero',chest:114};
const captions=['취향에서 시작하는 한 벌','보면서, 함께 구체화하는 디자인','고객의 언어를 설계의 언어로','기존 CAD 자산에 더하는 새로운 조건','제작 가능한 대안으로 돌아오는 제안','완성된 한 벌에서 시작하는 다음 대화'];
let current=0,scheduled=false,raw=0;
function sync(){const data=measurements[choice.fit];choice.chest=data.chest[choice.sizeIndex];$$('[data-fit]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.fit===choice.fit)));$$('[data-color]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.color===choice.color)));$$('[data-fit-value]').forEach(el=>el.textContent=choice.fit==='regular'?'일반핏':'슬림핏');$$('[data-color-value]').forEach(el=>el.textContent=choice.color);$('#size-display').textContent=sizeLabels[choice.sizeIndex];$('[data-size-value]').forEach(el=>el.textContent=sizeLabels[choice.sizeIndex]);for(const k of ['chest','shoulder','sleeve','length'])$('#'+k).textContent=data[k][choice.sizeIndex]??'확인 중';$('#sleeve').title=data.sleeve[choice.sizeIndex]===null?'제공된 원본의 슬림핏 135 소매길이는 재확인이 필요합니다.':'';$('#size-down').disabled=choice.sizeIndex===0;$('#size-up').disabled=choice.sizeIndex===8;schedule();}
$$('[data-fit]').forEach(el=>el.addEventListener('click',()=>{choice.fit=el.dataset.fit;sync();}));$$('[data-color]').forEach(el=>el.addEventListener('click',()=>{choice.color=el.dataset.color;sync();}));$('#size-down').addEventListener('click',()=>{choice.sizeIndex=Math.max(0,choice.sizeIndex-1);sync();});$('#size-up').addEventListener('click',()=>{choice.sizeIndex=Math.min(8,choice.sizeIndex+1);sync();});
function metrics(){return {top:story.getBoundingClientRect().top+scrollY,span:Math.max(1,story.offsetHeight-stage.offsetHeight)};}
function go(p){const {top,span}=metrics();scrollTo({top:top+clamp(p)*span,behavior:reduced.matches?'instant':'smooth'});}
$$('[data-scroll]').forEach(el=>el.addEventListener('click',()=>go(Number(el.dataset.scroll))));$('#next-scene').addEventListener('click',()=>{const n=stops.find(s=>s>raw+.025);if(n===undefined)$('#collection').scrollIntoView({behavior:reduced.matches?'instant':'smooth'});else go(n);});
function render(){scheduled=false;const m=metrics();raw=clamp((scrollY-m.top)/m.span);const actual=stateAt(raw);current=actual.chapter;const s=reduced.matches?stateAt(stops[current]):actual;
 const fg=s.blue>.48||s.dark>.25?'#edf4ff':'#182746';
 stage.style.setProperty('--fg',fg);stage.style.setProperty('--accent',s.blue>.3||s.dark>.3?'#c5d7ff':'#244b9b');stage.dataset.scene=current;$('#scene-caption').textContent=captions[current];
 scenes.forEach((el,i)=>{let weight=reduced.matches?Number(i===current):s.weights[i];el.style.opacity=weight;el.style.visibility=weight>.001?'visible':'hidden';el.inert=i!==current;el.setAttribute('aria-hidden',String(i!==current));const dir=(raw-stops[i]);el.style.transform=reduced.matches?'none':`translate3d(${clamp(dir*90,-22,22)}px,${clamp(-dir*200,-45,45)}px,0)`;});
 $('.proposal-sheet').style.transform=reduced.matches?'none':`perspective(1000px) rotateY(${mix(-22,0,progress(raw,.65,.74))}deg) rotate(${mix(6,-2,progress(raw,.65,.74))}deg) translateY(${mix(90,0,progress(raw,.65,.74))}px)`;
 $('.final-product').style.transform=reduced.matches?'none':`translateX(${mix(80,0,progress(raw,.86,.97))}px) rotate(${mix(-8,0,progress(raw,.86,.98))}deg)`;
 atelier.draw(s,choice,reduced.matches);
}
function schedule(){if(!scheduled){scheduled=true;requestAnimationFrame(render);}}
addEventListener('scroll',schedule,{passive:true});addEventListener('resize',()=>{atelier.resize();schedule();},{passive:true});reduced.addEventListener('change',schedule);
const vision=$('#vision-dialog'),sample=$('#sample-dialog');$$('[data-open="vision"]').forEach(el=>el.addEventListener('click',()=>vision.showModal()));$$('.close-dialog').forEach(el=>el.addEventListener('click',()=>el.closest('dialog').close()));
const sampleNames={hero:'구조가 주는 여유.',sage:'매일의 부드러움.',navy:'한 겹의 새로운 쓰임.'};const sampleCodes={hero:'WORK SHIRT',sage:'EVERYDAY SHIRT',navy:'OUTER SHIRT'};let pendingSample='hero';
$$('[data-sample]').forEach(el=>el.addEventListener('click',()=>{pendingSample=el.dataset.sample;$('#selected-image').src=assets[pendingSample];$('#selected-title').textContent=sampleNames[pendingSample];sample.showModal();}));$('#select-sample').addEventListener('click',()=>{choice.sample=pendingSample;$$('[data-selected-name]').forEach(el=>el.textContent=sampleCodes[pendingSample]);$('.final-product img').src=assets[pendingSample];sample.close();go(.20);});
for(const dialog of [vision,sample])dialog.addEventListener('click',e=>{if(e.target===dialog){const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)dialog.close();}});
sync();render();document.fonts?.ready.then(schedule);Promise.all($$('img').map(el=>el.decode?.().catch(()=>null))).then(schedule);
