import {assets} from './assets.js';
import {clamp,lerp,progress,sceneState,stops} from './motion.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
$$('[data-asset]').forEach(img=>img.src=assets[img.dataset.asset]);
const stage=$('.stage'),story=$('#story'),scenes=$$('.scene'),object=$('.hero-object'),slider=$('#journey-progress');
const reduced=matchMedia('(prefers-reduced-motion: reduce)'),mobile=matchMedia('(max-width: 700px)');
const titles=['발견','요구사항','제안형 수주','AI · CAD','제작 · 승인','다음 제안'];
const threadMessages=['선택한 샘플에서, 모든 대화가 시작됩니다.','고객의 선택 → AI가 정리하는 요구사항','요구사항 → 담당자가 제안하고 고객이 합의','합의 브리프 + 기존 CAD → 검토할 패턴 초안','확정 사양 + 변경 이력 → 실물 검증과 승인','승인 패턴 + 제작 기록 → 다음 제안의 자산'];
let current=-1,raf=false;
const patternParts=$$('.pattern-pieces>g').map((el,i)=>({el,i,transform:el.getAttribute('transform')}));
const outlines=$$('.pattern-pieces>g>path:first-child');outlines.forEach(el=>{el.setAttribute('pathLength','1');el.style.strokeDasharray='1';});
$$('.garment-lines [data-draw]').forEach(el=>{el.setAttribute('pathLength','1');el.style.strokeDasharray='1';});
function render(raw){
 const s=sceneState(raw),p=s.p,soft=reduced.matches;
 const d=clamp(s.dark),cad=progress(p,.47,.56)*(1-progress(p,.67,.73));
 stage.style.setProperty('--stage-bg',`rgb(${lerp(240,20,d)-cad*7} ${lerp(241,21,d)-cad*1} ${lerp(244,23,d)+cad*8})`);
 stage.style.setProperty('--stage-ink',`rgb(${lerp(32,244,d)} ${lerp(35,243,d)} ${lerp(40,239,d)})`);
 stage.style.setProperty('--stage-muted',`rgb(${lerp(140,146,d)} ${lerp(146,154,d)} ${lerp(158,167,d)})`);
 stage.style.setProperty('--stage-accent',d>.5?'#869fc6':'#778aaa');
 stage.style.setProperty('--stage-line',d>.5?'#ffffff25':'#7c88962b');
 stage.style.setProperty('--halo',1-progress(p,.06,.18));stage.style.setProperty('--giant',1-progress(p,.05,.18));stage.style.setProperty('--grid',cad);
 scenes.forEach((el,i)=>{const weight=soft?Number(i===s.chapter):s.weights[i];const offset=clamp((p-stops[i])*10,-1,1);el.style.opacity=weight;el.style.visibility=weight>.001?'visible':'hidden';el.style.transform=soft?'none':`translate3d(0,${offset*-38}px,0)`;el.inert=i!==s.chapter;el.setAttribute('aria-hidden',String(i!==s.chapter));});
 if(current!==s.chapter){current=s.chapter;stage.dataset.scene=current;$('#chapter-count').textContent=String(current+1).padStart(2,'0');$('#thread-message').textContent=threadMessages[current];$$('.journey-track [data-jump]').forEach((el,i)=>el.setAttribute('aria-current',String(i===current)));}
 $('.thread-capsule').style.opacity=soft?Number(current>0):progress(p,.075,.14);
 const x=mobile.matches?lerp(11,-19,progress(p,0,.2)):s.object.x;
 const y=mobile.matches?lerp(0,1,progress(p,0,.2)):s.object.y;
 const scale=mobile.matches?lerp(1,.78,progress(p,0,.2)):s.object.scale;
 object.style.transform=`translate3d(calc(-50% + ${soft?([0,1].includes(current)?(mobile.matches?current===0?11:-19:current===0?24:-3):0):x}vw),calc(-50% + ${soft?0:y}%),0) rotate(${soft?0:s.object.rotate}deg) scale(${soft?mobile.matches?.8:1:scale})`;
 object.style.opacity=soft?Number(current<2):s.object.opacity;
 const drafting=soft?Number(current===1):progress(p,.075,.19);
 $('.garment-lines').style.opacity=drafting*.8;
 $$('.garment-lines [data-draw]').forEach((el,i)=>el.style.strokeDashoffset=soft?0:1-progress(p,.1+i*.006,.22+i*.006));
 $$('.garment-lines .cloth-plane').forEach((el,i)=>{const t=soft?0:progress(p,.20+i*.007,.32+i*.007);el.style.opacity=t*.6;el.style.transform=`translate(${(i%2?1:-1)*t*20}px,${-t*14}px)`;});
 $('.cad-space').style.opacity=soft?Number(current===3):progress(p,.46,.55)*(1-progress(p,.67,.74));
 $('.cad-space').style.transform=soft?'none':`perspective(1300px) rotateY(${lerp(-13,0,progress(p,.48,.61))}deg) rotateX(${lerp(6,0,progress(p,.48,.61))}deg)`;
 $('.giant-type').style.transform=soft?'none':`translateX(${-p*40}%)`;
 const briefEntry=progress(p,.29,.40);$('.brief-stack').style.transform=soft?'none':`translate3d(${(1-briefEntry)*140}px,${(1-briefEntry)*45}px,0) rotateY(${(1-briefEntry)*-12}deg)`;
 $$('.brief-fields>div').forEach((el,i)=>{const t=soft?1:progress(p,.30+i*.01,.37+i*.01);el.style.opacity=t;el.style.transform=`translateX(${(1-t)*30}px)`;});
 $$('.pin').forEach((el,i)=>{const t=soft?1:progress(p,.10+i*.015,.17+i*.015);el.style.opacity=t;el.style.transform=`translateY(${(1-t)*15}px)`;});
 $('.request-panel').style.transform=soft?'none':`translateX(${(1-progress(p,.10,.2))*60}px)`;
 const positions=['translate(60 60)','translate(260 60)','translate(495 60)','translate(710 90)','translate(725 210)','translate(755 310)'];
 const patternSvg=$('#pattern-slot svg');patternSvg.setAttribute('viewBox',mobile.matches?'0 0 720 660':'0 0 1000 440');
 patternParts.forEach(({el,i,transform})=>{const t=soft?1:progress(p,.50+i*.006,.59+i*.006);el.setAttribute('transform',`${mobile.matches?transform:positions[i]} translate(${(i%3-1)*(1-t)*180} ${(i<3?1:-1)*(1-t)*95})`);el.style.opacity=t;});
 outlines.forEach((el,i)=>el.style.strokeDashoffset=soft?0:1-progress(p,.5+i*.01,.59+i*.01));
 $('.cad-visual').style.transform=soft?'none':`perspective(1100px) rotateY(${(1-progress(p,.49,.60))*-12}deg) scale(${lerp(.89,1,progress(p,.49,.60))})`;
 $$('.flow-item').forEach((el,i)=>{const t=soft?1:progress(p,.695+i*.014,.755+i*.014);el.style.opacity=t;el.style.transform=`translateX(${(1-t)*65}px)`;});
 $('.flow-rail').style.transform=`scaleY(${soft?1:progress(p,.71,.82)})`;
 $('.asset-gallery').style.transform=soft?'none':`perspective(1300px) rotateY(${(1-progress(p,.895,.98))*18}deg) translateX(${(1-progress(p,.89,.98))*100}px)`;
 slider.value=Math.round(p*1000);slider.style.setProperty('--fill',`${p*100}%`);slider.setAttribute('aria-valuetext',`${Math.round(p*100)}% · ${titles[current]}`);
}
function metrics(){return {top:scrollY+story.getBoundingClientRect().top-$('.header').offsetHeight,span:Math.max(1,story.offsetHeight-stage.offsetHeight)};}
function go(p,behavior='smooth'){const m=metrics();scrollTo({top:m.top+clamp(p)*m.span,behavior:reduced.matches?'instant':behavior});}
function update(){raf=false;const m=metrics();render((scrollY-m.top)/m.span);$$('[data-reveal]').forEach(el=>{const r=el.getBoundingClientRect();el.style.setProperty('--reveal',reduced.matches?1:progress(innerHeight-r.top,0,innerHeight*.35));});const material=$('.material-story'),r=material.getBoundingClientRect(),q=clamp(-r.top/Math.max(1,material.offsetHeight-innerHeight));$('.macro-image').style.transform=reduced.matches?'none':`translateX(${lerp(7,-3,q)}%) scale(${lerp(1.02,1.3,q)})`;$('.material-copy').style.opacity=reduced.matches?1:progress(innerHeight-r.top,0,innerHeight*.5);}
function schedule(){if(!raf){raf=true;requestAnimationFrame(update);}}
$$('[data-jump]').forEach(b=>b.addEventListener('click',()=>go(stops[Number(b.dataset.jump)])));
slider.addEventListener('input',()=>go(Number(slider.value)/1000,'instant'));
addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});reduced.addEventListener('change',schedule);mobile.addEventListener('change',schedule);
// Choices stay in this document only; they illustrate continuity rather than submit an order.
const choices={fit:'여유 있는 핏',color:'브라운'};
function sync(key,value){choices[key]=value;$$(`[data-sync="${key}"]`).forEach(el=>el.textContent=value);$$(`[data-${key}]`).forEach(el=>el.setAttribute('aria-pressed',String(el.dataset[key]===value)));}
$$('[data-fit]').forEach(b=>b.addEventListener('click',()=>sync('fit',b.dataset.fit)));
$$('[data-color]').forEach(b=>b.addEventListener('click',()=>sync('color',b.dataset.color)));
const workflow=[
 {intro:'고객이 샘플을 보는 순간부터, 제작에 필요한 정보가 쌓이기 시작합니다.',rows:[['고객','유지할 디자인과 바꿀 부분을 선택','핏·길이·칼라·포켓·로고, 착용 장면과 원단의 인상을 함께 기록합니다.'],['AI 보조','요청사항을 브리프로 구조화','필수 기능·제외 요소를 구분하고, 수량·사이즈·예산·납기 등 비어 있는 조건을 확인합니다.'],['영업·기획','제작 가능한 대안으로 제안','소재 후보와 디자인 대안, 제작 조건을 제안하고 고객과 합의할 범위를 정합니다.']],output:'선택한 가상샘플 + 요구사항 브리프 + 미확정 항목 + 고객 합의 이력'},
 {intro:'축적된 CAD와 제조 경험에, 고객의 요구와 AI의 제안을 연결합니다.',rows:[['기획·소싱','원단과 제작 조건을 먼저 검토','원단 후보 2~3종, 질감·두께, 원가와 수량, 로고·라벨 규정을 확인합니다.'],['AI·패턴실','기존 패턴을 활용한 설계 변경안','AI가 브리프와 기존 CAD를 바탕으로 변경 초안을 제안합니다. 패턴실이 치수·여유량·봉제·CAD 파일 호환성을 검토합니다.'],['샘플실·승인자','실물 검증과 명확한 승인 절차','소재 표현·착용감·아우터 봉제 적합성을 실물로 확인하고, 수정 이력과 승인자를 기록합니다.']],output:'검토된 CAD 패턴 + 치수표·BOM·작업지시서 + 샘플 피드백 + 승인 이력'},
 {intro:'완성된 한 벌의 자료가, 다음 생산과 새로운 제안의 자산이 됩니다.',rows:[['생산·품질','승인된 사양을 현장의 기준으로','최종 작업지시와 공정 인계, 재단·봉제·완성검품·납품 확인을 같은 제품 기록에 연결합니다.'],['영업·콘텐츠','룩북과 제안서로 재사용','검증된 디지털 샘플을 룩북·상세페이지·B2B 제안 자료로 활용해 기존 판매·영업 채널을 지원합니다.'],['운영','반복할수록 쌓이는 제작 기준','패턴·원단·변경 이력과 결과물을 재사용할 수 있도록 정리하고, 담당자 교육과 운영 템플릿으로 정착시킵니다.']],output:'생산·검품 기록 + 콘텐츠 자산 + 제안 라이브러리 + 반복 운영 템플릿'}
];
const details={1:{...workflow[0],label:'고객의 요청에서 제안형 수주로',title:'보고 남긴 요구가, 함께 만들 제안으로.'},2:{intro:'고객과 합의한 브리프를 기존 CAD 자산과 연결합니다. 형태만 추정하는 변환을 넘어, 검토 가능한 설계 변경안을 만드는 방향입니다.',rows:[['입력','브리프와 기존 CAD 패턴 연결','선택한 샘플, 치수·핏·포켓·칼라 요청, 원단 후보와 기존 패턴의 CAD 파일 형식을 확인합니다.'],['AI 보조','변경안을 패턴과 사양 초안으로','요구사항을 패턴 변경 포인트로 정리하고, 치수표·봉제 정보·원부자재 목록의 초안을 제안합니다.'],['패턴실','제작할 수 있는 패턴으로 검토','여유량·봉제선·결방향·그레이딩과 파일 호환성을 확인하고, 수정이 필요하면 브리프와 함께 이력을 남깁니다.']],output:'검토된 CAD 패턴 · 치수표 · BOM · 작업지시서 · 수정 이력',label:'합의된 한 벌이 설계로 이어지는 과정',title:'고객의 언어를, 선과 면의 언어로.'},3:{...workflow[1],label:'실물 검증에서 생산·검품까지',title:'수정과 승인까지, 같은 한 벌의 기록으로.'},4:{...workflow[2],label:'완성된 한 벌에서 다음 제안으로',title:'완성된 자료가, 다음 수주의 출발점으로.'}};
const detailDialog=$('#detail-dialog');$$('[data-detail]').forEach(b=>b.addEventListener('click',()=>{const d=details[b.dataset.detail];$('#detail-label').textContent=d.label;$('#detail-title').textContent=d.title;$('#detail-intro').textContent=d.intro;$('#detail-rows').innerHTML=d.rows.map(([owner,title,copy])=>`<div class="detail-row"><span>${owner}</span><div><h3>${title}</h3><p>${copy}</p></div></div>`).join('');$('#detail-output').textContent=d.output;detailDialog.showModal();}));$('#detail-close').addEventListener('click',()=>detailDialog.close());
const dialog=$('#sample-dialog'),names={hero:'Work, softened.',sage:'Everyday ease.',navy:'A lighter layer.'};
$$('[data-sample]').forEach(b=>b.addEventListener('click',()=>{$('#dialog-garment').src=assets[b.dataset.sample];$('#dialog-title').textContent=names[b.dataset.sample];dialog.showModal();}));
$('#dialog-close').addEventListener('click',()=>dialog.close());$('#dialog-continue').addEventListener('click',()=>{dialog.close();go(stops[2]);});
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
render(0);update();Promise.all($$('img').map(img=>img.decode?.().catch(()=>null))).then(schedule);

