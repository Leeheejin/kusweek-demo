import {assets} from './assets.js';
import {clamp,lerp,prog,kf,visualState,chapterStops} from './motion.js';

document.querySelectorAll('[data-asset]').forEach(image=>{image.src=assets[image.dataset.asset];});
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const story=$('#story'),stage=$('.story-stage'),panels=$$('.story-copy'),chapterButtons=$$('[data-chapter]'),slider=$('#story-progress');
const motionQuery=matchMedia('(prefers-reduced-motion: reduce)');
const patternGroups=$$('.pattern-pieces>g').map(el=>({el,base:el.getAttribute('transform')}));
const outlines=$$('.pattern-pieces>g>path:first-child');
outlines.forEach(path=>{path.setAttribute('pathLength','1');path.style.strokeDasharray='1';});
const artwork=$('.garment-art'),ivory=$('.garment-ivory'),navy=$('.garment-navy'),sage=$('.garment-sage');
const pattern=$('.cad-art'),flow=$('.ax-art'),scan=$('.scan-line'),trace=$('.garment-trace');
const initialLabels=['새로운 시작','가상샘플','AI CAD','AX 제작','다음 장'];
let lastChapter=-1,ticking=false,storyProgress=0;

function render(progress){
 const s=visualState(progress),p=s.p,reduced=motionQuery.matches;
 stage.style.setProperty('--dark',s.dark);
 stage.style.setProperty('--scene-bg',`rgb(${lerp(246,9,s.dark)} ${lerp(246,16,s.dark)} ${lerp(244,28,s.dark)})`);
 stage.style.setProperty('--scene-ink',`rgb(${lerp(22,243,s.dark)} ${lerp(27,246,s.dark)} ${lerp(38,252,s.dark)})`);
 stage.style.setProperty('--scene-dim',`rgb(${lerp(100,151,s.dark)} ${lerp(106,174,s.dark)} ${lerp(118,205,s.dark)})`);
 stage.style.setProperty('--scene-line',`rgba(${Math.round(lerp(20,137,s.dark))},${Math.round(lerp(35,172,s.dark))},${Math.round(lerp(60,239,s.dark))},.18)`);
 panels.forEach((el,i)=>{
   const w=reduced?Number(s.chapter===i):s.weights[i];el.style.opacity=w;el.style.visibility=w>.002?'visible':'hidden';el.inert=i!==s.chapter;
   const delta=clamp((p-chapterStops[i])*7,-1,1);
   el.style.transform=reduced?'none':`translate3d(0,${-delta*55}px,0)`;
   const lines=el.querySelectorAll('.line>span');lines.forEach((line,j)=>{line.style.transform=reduced?'none':`translateY(${(1-w)*(delta<0?105:-75)*(1+j*.09)}%)`;});
 });
 if(s.chapter!==lastChapter){lastChapter=s.chapter;stage.dataset.scene=s.chapter;$('#current-chapter').textContent=String(s.chapter+1).padStart(2,'0');$('#scene-label').textContent=initialLabels[s.chapter];chapterButtons.forEach((b,i)=>b.setAttribute('aria-current',String(i===s.chapter)));}
 artwork.style.opacity=reduced?Number([0,1,4].includes(s.chapter)):s.garment;
 const scaling=reduced?1:s.heroScale,turn=reduced?0:s.heroTurn;
 ivory.style.transform=`translate3d(0,${reduced?0:kf(p,[[0,4],[.25,-5],[.45,-10],[1,4]])}%,0) rotate(${turn}deg) scale(${scaling})`;
 navy.style.transform=`translate3d(${-35*s.spread}%,${7+7*s.spread}%,0) rotate(${-22*s.spread}deg) scale(${.74+.05*s.spread})`;
 sage.style.transform=`translate3d(${36*s.spread}%,${9+5*s.spread}%,0) rotate(${19*s.spread}deg) scale(${.72+.05*s.spread})`;
 navy.style.opacity=s.spread*.94;sage.style.opacity=s.spread*.95;
 const wipe=prog(p,.315,.11);
 artwork.style.clipPath=`inset(0 0 ${wipe*100}% 0)`;
 if(p>.8)artwork.style.clipPath='none';
 scan.style.opacity=(p>.272&&p<.44&&!reduced)?Math.sin(prog(p,.272,.168, x=>x)*Math.PI):0;
 scan.style.top=`${lerp(5,94,s.scan)}%`;
 trace.style.opacity=(prog(p,.27,.07)*(1-prog(p,.40,.08)))*.75;
 trace.style.transform=`scale(${scaling}) rotate(${turn}deg)`;
 pattern.style.opacity=reduced?Number(s.chapter===2):s.pattern;
 pattern.style.transform=reduced?'none':`perspective(1100px) rotateY(${lerp(-16,0,prog(p,.34,.15))}deg) translateY(${lerp(50,-20,prog(p,.34,.28))}px) scale(${lerp(.85,1.02,prog(p,.34,.21))})`;
 patternGroups.forEach(({el,base},i)=>{const draw=prog(p,.35+i*.012,.13);const dx=(i%3-1)*(1-draw)*90,dy=(i<3?1:-1)*(1-draw)*70;el.setAttribute('transform',`${base} translate(${dx} ${dy})`);el.style.opacity=draw;});
 outlines.forEach((line,i)=>line.style.strokeDashoffset=1-prog(p,.35+i*.012,.18));
 flow.style.opacity=reduced?Number(s.chapter===3):s.flow;
 flow.style.transform=reduced?'none':`perspective(1200px) rotateY(${lerp(-14,0,prog(p,.6,.14))}deg) rotateX(${lerp(10,0,prog(p,.6,.14))}deg) translateY(${lerp(70,-15,prog(p,.6,.19))}px)`;
 $$('.ax-node').forEach((el,i)=>{const v=prog(p,.60+i*.018,.085);el.style.opacity=v;el.style.transform=reduced?'none':`translate3d(${(1-v)*65}px,${(1-v)*20}px,0)`;});
 $$('.ax-link i').forEach((el,i)=>el.style.transform=`scaleY(${prog(p,.64+i*.034,.09)})`);
 $('.blue-orbit').style.transform=`translate(-50%,-50%) rotate(${reduced?0:p*100-20}deg) scale(${1+s.dark*.2})`;
 $('.story-wordmark').style.transform=reduced?'none':`translateX(${-p*8}%)`;
 slider.value=Math.round(p*1000);slider.setAttribute('aria-valuetext',`${Math.round(p*100)}% · ${initialLabels[s.chapter]}`);slider.style.setProperty('--fill',`${p*100}%`);
}

function metrics(){const header=$('.site-header').offsetHeight;return {top:scrollY+story.getBoundingClientRect().top-header,span:Math.max(1,story.offsetHeight-stage.offsetHeight),header};}
function update(){ticking=false;const m=metrics();storyProgress=clamp((scrollY-m.top)/m.span);render(storyProgress);$$('[data-reveal]').forEach(el=>{const rect=el.getBoundingClientRect();const q=prog(innerHeight-rect.top,0,innerHeight*.48);el.style.setProperty('--reveal',motionQuery.matches?1:q);});}
function schedule(){if(!ticking){ticking=true;requestAnimationFrame(update)}}
function goToProgress(p,behavior='smooth'){const m=metrics();scrollTo({top:m.top+clamp(p)*m.span,behavior:motionQuery.matches?'instant':behavior});}
chapterButtons.forEach((button,i)=>button.addEventListener('click',()=>goToProgress(chapterStops[i])));
$$('[data-jump]').forEach(button=>button.addEventListener('click',()=>goToProgress(Number(button.dataset.jump))));
slider.addEventListener('input',()=>goToProgress(Number(slider.value)/1000,'instant'));
addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});motionQuery.addEventListener?.('change',schedule);
$$('.collection-card').forEach(card=>{card.addEventListener('pointermove',e=>{if(motionQuery.matches||e.pointerType==='touch')return;const r=card.getBoundingClientRect();card.style.setProperty('--tilt-x',`${-(e.clientY-r.top-r.height/2)/r.height*5}deg`);card.style.setProperty('--tilt-y',`${(e.clientX-r.left-r.width/2)/r.width*7}deg`);});card.addEventListener('pointerleave',()=>{card.style.setProperty('--tilt-x','0deg');card.style.setProperty('--tilt-y','0deg');});});
const dialog=$('#vision-dialog');
$$('[data-open-vision]').forEach(button=>button.addEventListener('click',()=>{dialog.showModal();}));
$('#close-vision').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
$('#dialog-to-cad').addEventListener('click',()=>{dialog.close();goToProgress(chapterStops[2]);});
// No WebGL, GLB or physical simulation: these are deliberately art-directed concept scenes.
render(0);update();
document.documentElement.classList.add('motion-ready');
Promise.all($$('img').map(img=>img.decode?.().catch(()=>null))).then(schedule);
